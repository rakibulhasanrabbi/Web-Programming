<?php
/**
 * Migration: Test Preparation Courses System
 * Creates tables: courses, course_content, enrollments, payments
 * Seeds demo data for IELTS, GRE, TOEFL courses
 */

require_once 'c:/xampp/htdocs/Project_2/config/database.php';

echo "=== Abrovia Test Prep Migration ===\n\n";

try {
    // 1. Create courses table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS courses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            slug VARCHAR(100) NOT NULL UNIQUE,
            description TEXT,
            icon VARCHAR(50) DEFAULT NULL,
            price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            currency VARCHAR(10) DEFAULT 'BDT',
            duration_weeks INT DEFAULT 8,
            features TEXT COMMENT 'JSON array of feature strings',
            status ENUM('active','inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "[OK] courses table created\n";

    // 2. Create course_content table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS course_content (
            id INT AUTO_INCREMENT PRIMARY KEY,
            course_id INT NOT NULL,
            type ENUM('material','book','practice_question','viva','recorded_class','live_class','practice_exam') NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            content_url VARCHAR(500) DEFAULT NULL,
            duration_minutes INT DEFAULT NULL,
            sort_order INT DEFAULT 0,
            is_free_preview TINYINT(1) DEFAULT 0,
            status ENUM('active','inactive') DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "[OK] course_content table created\n";

    // 3. Create payments table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            course_id INT NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            currency VARCHAR(10) DEFAULT 'BDT',
            payment_method VARCHAR(50) DEFAULT 'demo',
            transaction_id VARCHAR(100) DEFAULT NULL,
            status ENUM('completed','pending','refunded','failed') DEFAULT 'completed',
            paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "[OK] payments table created\n";

    // 4. Create enrollments table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS enrollments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            course_id INT NOT NULL,
            payment_id INT DEFAULT NULL,
            status ENUM('active','suspended','removed') DEFAULT 'active',
            progress_percent INT DEFAULT 0,
            enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME DEFAULT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
            FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE SET NULL,
            UNIQUE KEY unique_enrollment (user_id, course_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "[OK] enrollments table created\n";

    // ---- SEED COURSES ----
    echo "\n--- Seeding Courses ---\n";

    $courses = [
        [
            'name' => 'IELTS Preparation',
            'slug' => 'ielts',
            'description' => 'Comprehensive English language proficiency test preparation covering all four modules: Listening, Reading, Writing, and Speaking. Achieve Band 7+ with expert mentorship and realistic mock exams.',
            'icon' => '🌍',
            'price' => 15000.00,
            'duration_weeks' => 10,
            'features' => json_encode([
                '40+ Full Mock Tests',
                'Band 8+ Mentorship',
                'Speaking & Writing Reviews',
                'Personalized Study Plan',
                'Live Expert Sessions',
                '24/7 Doubt Resolution'
            ])
        ],
        [
            'name' => 'GRE Preparation',
            'slug' => 'gre',
            'description' => 'Master quantitative reasoning, verbal reasoning, and analytical writing for graduate school admissions. Adaptive learning with 3000+ practice questions and detailed score analytics.',
            'icon' => '📐',
            'price' => 18000.00,
            'duration_weeks' => 12,
            'features' => json_encode([
                '3000+ Practice Questions',
                'Adaptive Learning Algorithm',
                'Detailed Score Analytics',
                'Quant & Verbal Strategies',
                'AWA Essay Reviews',
                'Target Score Guarantee'
            ])
        ],
        [
            'name' => 'TOEFL Preparation',
            'slug' => 'toefl',
            'description' => 'Internet-based test preparation with real exam interface simulation. Master integrated tasks, expert-graded essays, and comprehensive reading/listening strategies for US university admissions.',
            'icon' => '🎧',
            'price' => 12000.00,
            'duration_weeks' => 8,
            'features' => json_encode([
                'Real Exam Interface Simulation',
                'Expert Graded Essays',
                'Integrated Task Strategies',
                'Speaking Response Analysis',
                'Full-Length Practice Tests',
                'Score Prediction Engine'
            ])
        ]
    ];

    $insertCourse = $pdo->prepare("
        INSERT INTO courses (name, slug, description, icon, price, duration_weeks, features)
        VALUES (:name, :slug, :description, :icon, :price, :duration_weeks, :features)
        ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), price=VALUES(price), features=VALUES(features)
    ");

    foreach ($courses as $c) {
        $insertCourse->execute($c);
        echo "[OK] Course: {$c['name']}\n";
    }

    // ---- SEED CONTENT ----
    echo "\n--- Seeding Course Content ---\n";

    // Get course IDs
    $ieltsId = $pdo->query("SELECT id FROM courses WHERE slug='ielts'")->fetchColumn();
    $greId = $pdo->query("SELECT id FROM courses WHERE slug='gre'")->fetchColumn();
    $toeflId = $pdo->query("SELECT id FROM courses WHERE slug='toefl'")->fetchColumn();

    // Clear existing content to avoid duplicates
    $pdo->exec("DELETE FROM course_content WHERE course_id IN ($ieltsId, $greId, $toeflId)");

    $insertContent = $pdo->prepare("
        INSERT INTO course_content (course_id, type, title, description, content_url, duration_minutes, sort_order, is_free_preview)
        VALUES (:course_id, :type, :title, :description, :content_url, :duration_minutes, :sort_order, :is_free_preview)
    ");

    // IELTS Content
    $ieltsContent = [
        ['type'=>'material', 'title'=>'IELTS Overview & Test Format', 'description'=>'Complete guide to the IELTS exam structure, scoring system, and test day procedures.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>1],
        ['type'=>'material', 'title'=>'Listening Module Strategies', 'description'=>'Key techniques for IELTS Listening including note-taking, keyword spotting, and answer prediction.', 'url'=>'#', 'duration'=>null, 'order'=>2, 'free'=>0],
        ['type'=>'material', 'title'=>'Reading Module: Skimming & Scanning', 'description'=>'Advanced reading strategies for Academic and General Training modules.', 'url'=>'#', 'duration'=>null, 'order'=>3, 'free'=>0],
        ['type'=>'material', 'title'=>'Writing Task 1 & Task 2 Templates', 'description'=>'Proven essay templates and graph description frameworks for Band 7+.', 'url'=>'#', 'duration'=>null, 'order'=>4, 'free'=>0],
        ['type'=>'book', 'title'=>'Cambridge IELTS 18 Practice Tests', 'description'=>'Official practice tests with detailed answer explanations and model essays.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>0],
        ['type'=>'book', 'title'=>'IELTS Vocabulary Builder', 'description'=>'2000+ essential academic words organized by topic with usage examples.', 'url'=>'#', 'duration'=>null, 'order'=>2, 'free'=>1],
        ['type'=>'book', 'title'=>'IELTS Writing Masterclass eBook', 'description'=>'Step-by-step guide to crafting high-band essays with 50+ model answers.', 'url'=>'#', 'duration'=>null, 'order'=>3, 'free'=>0],
        ['type'=>'practice_question', 'title'=>'Listening Practice Set 1-10', 'description'=>'10 complete listening practice sets with audio recordings and answer keys.', 'url'=>'#', 'duration'=>40, 'order'=>1, 'free'=>0],
        ['type'=>'practice_question', 'title'=>'Reading Passage Analysis (Academic)', 'description'=>'30 reading passages with True/False/Not Given, matching, and summary completion tasks.', 'url'=>'#', 'duration'=>60, 'order'=>2, 'free'=>0],
        ['type'=>'practice_question', 'title'=>'Writing Task 2 Essay Prompts', 'description'=>'50 essay prompts covering all common IELTS topics with model answers.', 'url'=>'#', 'duration'=>null, 'order'=>3, 'free'=>0],
        ['type'=>'viva', 'title'=>'Speaking Part 1: Introduction Topics', 'description'=>'Practice responding to common Part 1 questions about home, work, studies, and daily life.', 'url'=>'#', 'duration'=>15, 'order'=>1, 'free'=>1],
        ['type'=>'viva', 'title'=>'Speaking Part 2: Cue Card Practice', 'description'=>'20 cue card topics with preparation notes, model answers, and examiner feedback.', 'url'=>'#', 'duration'=>20, 'order'=>2, 'free'=>0],
        ['type'=>'viva', 'title'=>'Speaking Part 3: Discussion Skills', 'description'=>'Advanced discussion techniques for achieving Band 7+ in the interview section.', 'url'=>'#', 'duration'=>25, 'order'=>3, 'free'=>0],
        ['type'=>'recorded_class', 'title'=>'IELTS Masterclass: Listening Skills', 'description'=>'In-depth lecture on mastering the four sections of IELTS Listening.', 'url'=>'#', 'duration'=>90, 'order'=>1, 'free'=>1],
        ['type'=>'recorded_class', 'title'=>'Writing Task 1: Data Interpretation', 'description'=>'Learn to describe charts, graphs, tables, and diagrams effectively.', 'url'=>'#', 'duration'=>75, 'order'=>2, 'free'=>0],
        ['type'=>'recorded_class', 'title'=>'Reading Speed & Comprehension', 'description'=>'Techniques to improve reading speed while maintaining accuracy.', 'url'=>'#', 'duration'=>60, 'order'=>3, 'free'=>0],
        ['type'=>'live_class', 'title'=>'Weekly Speaking Workshop', 'description'=>'Live interactive speaking practice with certified IELTS examiners every Saturday.', 'url'=>'#', 'duration'=>60, 'order'=>1, 'free'=>0],
        ['type'=>'live_class', 'title'=>'Writing Correction Session', 'description'=>'Submit your essays and get live feedback from expert instructors every Wednesday.', 'url'=>'#', 'duration'=>90, 'order'=>2, 'free'=>0],
        ['type'=>'practice_exam', 'title'=>'Full Mock Test 1 (Academic)', 'description'=>'Complete simulated IELTS Academic exam with all four modules timed.', 'url'=>'#', 'duration'=>170, 'order'=>1, 'free'=>0],
        ['type'=>'practice_exam', 'title'=>'Full Mock Test 2 (Academic)', 'description'=>'Second full-length practice exam with detailed score breakdown.', 'url'=>'#', 'duration'=>170, 'order'=>2, 'free'=>0],
        ['type'=>'practice_exam', 'title'=>'Mini Mock: Listening & Reading', 'description'=>'Quick assessment focusing on Listening and Reading modules only.', 'url'=>'#', 'duration'=>90, 'order'=>3, 'free'=>1],
    ];

    foreach ($ieltsContent as $item) {
        $insertContent->execute([
            'course_id' => $ieltsId, 'type' => $item['type'], 'title' => $item['title'],
            'description' => $item['description'], 'content_url' => $item['url'],
            'duration_minutes' => $item['duration'], 'sort_order' => $item['order'], 'is_free_preview' => $item['free']
        ]);
    }
    echo "[OK] IELTS content seeded (" . count($ieltsContent) . " items)\n";

    // GRE Content
    $greContent = [
        ['type'=>'material', 'title'=>'GRE Test Structure & Scoring', 'description'=>'Understanding GRE sections, scoring scale (130-170), and adaptive testing format.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>1],
        ['type'=>'material', 'title'=>'Quantitative Reasoning Formulas', 'description'=>'Complete formula sheet covering arithmetic, algebra, geometry, and data analysis.', 'url'=>'#', 'duration'=>null, 'order'=>2, 'free'=>0],
        ['type'=>'material', 'title'=>'Verbal Reasoning Word Lists', 'description'=>'High-frequency GRE vocabulary with mnemonics, usage, and practice exercises.', 'url'=>'#', 'duration'=>null, 'order'=>3, 'free'=>0],
        ['type'=>'book', 'title'=>'Official GRE Super Power Pack', 'description'=>'Comprehensive preparation guide with strategies, practice questions, and full tests.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>0],
        ['type'=>'book', 'title'=>'GRE Math Bible', 'description'=>'In-depth coverage of all quantitative topics with 500+ solved problems.', 'url'=>'#', 'duration'=>null, 'order'=>2, 'free'=>0],
        ['type'=>'practice_question', 'title'=>'Quant Practice: Algebra & Arithmetic', 'description'=>'500 problems covering algebraic equations, inequalities, and number properties.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>0],
        ['type'=>'practice_question', 'title'=>'Verbal: Text Completion & SE', 'description'=>'300 text completion and sentence equivalence questions with explanations.', 'url'=>'#', 'duration'=>null, 'order'=>2, 'free'=>1],
        ['type'=>'practice_question', 'title'=>'Reading Comprehension Sets', 'description'=>'50 RC passages with analysis of argument structure and inference questions.', 'url'=>'#', 'duration'=>null, 'order'=>3, 'free'=>0],
        ['type'=>'viva', 'title'=>'AWA Issue Essay Practice', 'description'=>'Practice analyzing complex issues with structured argumentation techniques.', 'url'=>'#', 'duration'=>30, 'order'=>1, 'free'=>0],
        ['type'=>'viva', 'title'=>'AWA Argument Essay Practice', 'description'=>'Evaluate arguments for logical fallacies and strengthen your critical analysis.', 'url'=>'#', 'duration'=>30, 'order'=>2, 'free'=>0],
        ['type'=>'recorded_class', 'title'=>'GRE Quant Masterclass: Geometry', 'description'=>'Complete geometry review including circles, triangles, coordinate geometry.', 'url'=>'#', 'duration'=>120, 'order'=>1, 'free'=>1],
        ['type'=>'recorded_class', 'title'=>'Verbal Strategies: RC Deep Dive', 'description'=>'Advanced reading comprehension techniques for scoring 160+.', 'url'=>'#', 'duration'=>90, 'order'=>2, 'free'=>0],
        ['type'=>'live_class', 'title'=>'Weekly Quant Problem Solving', 'description'=>'Live problem-solving session tackling the hardest GRE quant questions.', 'url'=>'#', 'duration'=>90, 'order'=>1, 'free'=>0],
        ['type'=>'practice_exam', 'title'=>'Full-Length GRE Practice Test 1', 'description'=>'Complete adaptive-format GRE simulation with score prediction.', 'url'=>'#', 'duration'=>225, 'order'=>1, 'free'=>0],
        ['type'=>'practice_exam', 'title'=>'Full-Length GRE Practice Test 2', 'description'=>'Second comprehensive GRE test with detailed performance analytics.', 'url'=>'#', 'duration'=>225, 'order'=>2, 'free'=>0],
    ];

    foreach ($greContent as $item) {
        $insertContent->execute([
            'course_id' => $greId, 'type' => $item['type'], 'title' => $item['title'],
            'description' => $item['description'], 'content_url' => $item['url'],
            'duration_minutes' => $item['duration'], 'sort_order' => $item['order'], 'is_free_preview' => $item['free']
        ]);
    }
    echo "[OK] GRE content seeded (" . count($greContent) . " items)\n";

    // TOEFL Content
    $toeflContent = [
        ['type'=>'material', 'title'=>'TOEFL iBT Test Guide', 'description'=>'Complete overview of TOEFL iBT format, scoring, and registration process.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>1],
        ['type'=>'material', 'title'=>'Integrated Task Strategies', 'description'=>'Master the unique integrated speaking and writing tasks of TOEFL.', 'url'=>'#', 'duration'=>null, 'order'=>2, 'free'=>0],
        ['type'=>'material', 'title'=>'Note-Taking Techniques', 'description'=>'Essential note-taking skills for listening and integrated tasks.', 'url'=>'#', 'duration'=>null, 'order'=>3, 'free'=>0],
        ['type'=>'book', 'title'=>'Official TOEFL iBT Tests Vol. 1', 'description'=>'5 authentic TOEFL tests from ETS with answer explanations.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>0],
        ['type'=>'book', 'title'=>'TOEFL Vocabulary Essentials', 'description'=>'Academic vocabulary organized by topic for reading and listening success.', 'url'=>'#', 'duration'=>null, 'order'=>2, 'free'=>1],
        ['type'=>'practice_question', 'title'=>'Reading Section Practice', 'description'=>'25 reading passages with inference, vocabulary, and summary questions.', 'url'=>'#', 'duration'=>null, 'order'=>1, 'free'=>0],
        ['type'=>'practice_question', 'title'=>'Listening Conversation & Lecture Sets', 'description'=>'Audio-based practice covering campus conversations and academic lectures.', 'url'=>'#', 'duration'=>60, 'order'=>2, 'free'=>0],
        ['type'=>'viva', 'title'=>'Speaking Task 1: Independent Response', 'description'=>'Practice giving 45-second responses to personal experience questions.', 'url'=>'#', 'duration'=>15, 'order'=>1, 'free'=>1],
        ['type'=>'viva', 'title'=>'Speaking Tasks 2-4: Integrated Tasks', 'description'=>'Practice reading, listening, then speaking responses with timing drills.', 'url'=>'#', 'duration'=>30, 'order'=>2, 'free'=>0],
        ['type'=>'recorded_class', 'title'=>'TOEFL Speaking Masterclass', 'description'=>'Complete guide to all speaking tasks with response templates.', 'url'=>'#', 'duration'=>80, 'order'=>1, 'free'=>1],
        ['type'=>'recorded_class', 'title'=>'Writing: Integrated Essay Workshop', 'description'=>'Step-by-step approach to writing high-scoring integrated essays.', 'url'=>'#', 'duration'=>70, 'order'=>2, 'free'=>0],
        ['type'=>'live_class', 'title'=>'TOEFL Speaking Practice Lab', 'description'=>'Live speaking practice with real-time feedback from TOEFL instructors.', 'url'=>'#', 'duration'=>60, 'order'=>1, 'free'=>0],
        ['type'=>'practice_exam', 'title'=>'Full TOEFL iBT Simulation 1', 'description'=>'Complete 4-section TOEFL iBT exam simulation with score estimate.', 'url'=>'#', 'duration'=>200, 'order'=>1, 'free'=>0],
        ['type'=>'practice_exam', 'title'=>'Full TOEFL iBT Simulation 2', 'description'=>'Second full-length test with comparative performance tracking.', 'url'=>'#', 'duration'=>200, 'order'=>2, 'free'=>0],
    ];

    foreach ($toeflContent as $item) {
        $insertContent->execute([
            'course_id' => $toeflId, 'type' => $item['type'], 'title' => $item['title'],
            'description' => $item['description'], 'content_url' => $item['url'],
            'duration_minutes' => $item['duration'], 'sort_order' => $item['order'], 'is_free_preview' => $item['free']
        ]);
    }
    echo "[OK] TOEFL content seeded (" . count($toeflContent) . " items)\n";

    echo "\n=== Migration Complete! ===\n";
    echo "Tables created: courses, course_content, payments, enrollments\n";
    echo "Courses seeded: IELTS, GRE, TOEFL\n";
    $totalContent = $pdo->query("SELECT COUNT(*) FROM course_content")->fetchColumn();
    echo "Total content items: $totalContent\n";

} catch (PDOException $e) {
    echo "[ERROR] " . $e->getMessage() . "\n";
    exit(1);
}
