<?php
/**
 * Migration: Add premium status to users
 */

require_once 'c:/xampp/htdocs/Project_2/config/database.php';

echo "=== Abrovia Premium User Upgrade Migration ===\n\n";

try {
    // Add is_premium column if it doesn't exist
    $pdo->exec("
        ALTER TABLE users 
        ADD COLUMN is_premium TINYINT(1) DEFAULT 0 AFTER role
    ");
    echo "[OK] is_premium column added to users table\n";
    echo "=== Migration Complete! ===\n";

} catch (PDOException $e) {
    // Check if column already exists
    if ($e->getCode() == '42S21' || strpos($e->getMessage(), 'Duplicate column') !== false) {
        echo "[OK] is_premium column already exists\n";
    } else {
        echo "[ERROR] " . $e->getMessage() . "\n";
        exit(1);
    }
}
