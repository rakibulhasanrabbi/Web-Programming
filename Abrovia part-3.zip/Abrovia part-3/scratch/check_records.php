<?php
require_once 'c:/xampp/htdocs/Project_2/config/database.php';
echo "--- UNIVERSITY CONTACTS ---\n";
$contacts = $pdo->query("SELECT * FROM university_contacts")->fetchAll(PDO::FETCH_ASSOC);
print_r($contacts);

echo "\n--- PROGRAMS ---\n";
$programs = $pdo->query("SELECT * FROM programs")->fetchAll(PDO::FETCH_ASSOC);
print_r($programs);
