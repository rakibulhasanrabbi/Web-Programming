<?php
/**
 * Migration: Visa Processing System
 * Creates tables: visa_requests
 */

require_once 'c:/xampp/htdocs/Project_2/config/database.php';

echo "=== Abrovia Visa Processing Migration ===\n\n";

try {
    // Create visa_requests table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS visa_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            country VARCHAR(100) NOT NULL,
            passport_number VARCHAR(50) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            phone VARCHAR(50) NOT NULL,
            university_name VARCHAR(255) NOT NULL,
            program_name VARCHAR(255) NOT NULL,
            status ENUM('pending', 'documents_verified', 'submitted_to_embassy', 'approved', 'rejected') DEFAULT 'pending',
            passport_file VARCHAR(255) DEFAULT NULL,
            admission_letter_file VARCHAR(255) DEFAULT NULL,
            bank_statement_file VARCHAR(255) DEFAULT NULL,
            language_score_file VARCHAR(255) DEFAULT NULL,
            info_verified TINYINT(1) DEFAULT 0,
            docs_verified TINYINT(1) DEFAULT 0,
            embassy_submitted TINYINT(1) DEFAULT 0,
            admin_notes TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "[OK] visa_requests table created successfully\n";
    echo "=== Migration Complete! ===\n";

} catch (PDOException $e) {
    echo "[ERROR] " . $e->getMessage() . "\n";
    exit(1);
}
