<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Global Scholarships - Abrovia</title>
    <link rel="stylesheet" href="assets/css/scholarships.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <!-- NAVBAR -->
    <?php require_once 'includes/header.php'; ?>

    <!-- HERO -->
    <section class="hero" id="scholarships-hero" style="background-image: linear-gradient(180deg, rgba(10, 14, 28, 0.5) 0%, rgba(10, 14, 28, 0.95) 100%), url('assets/images/scholarship_award.png'); background-size: cover; background-position: center; padding: 140px 40px 80px;">
        <div class="hero-container">
            <h1 class="hero-title"><em>Global Scholarships</em></h1>
            <p class="hero-desc">Discover fully and partially funded opportunities to support your international education journey. Browse our curated list of prestigious scholarships worldwide.</p>
        </div>
    </section>

    <!-- FILTERS -->
    <section class="filters-section" id="filters-section">
        <div class="filters-container">
            <label class="filter-checkbox" id="filter-funded">
                <input type="checkbox">
                <span class="checkbox-custom"></span>
                Fully Funded Only
            </label>
            <div class="filter-group">
                <span class="filter-label">COUNTRY</span>
                <div class="select-wrapper">
                    <select class="filter-select" id="filter-country">
                        <option>All Countries</option>
                        <option>United Kingdom</option>
                        <option>United States</option>
                        <option>Australia</option>
                        <option>Germany</option>
                        <option>Canada</option>
                    </select>
                    <svg class="select-arrow" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                </div>
            </div>
            <div class="filter-group">
                <span class="filter-label">DEADLINE</span>
                <div class="select-wrapper">
                    <select class="filter-select" id="filter-deadline">
                        <option>Any Time</option>
                        <option>Next 30 Days</option>
                        <option>Next 3 Months</option>
                        <option>Next 6 Months</option>
                    </select>
                    <svg class="select-arrow" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                </div>
            </div>
        </div>
    </section>

    <!-- SCHOLARSHIP CARDS -->
    <section class="results-section" id="results-section">
        <div class="results-container">
            <div class="scholarships-grid">
                <?php
                $scholarships = $pdo->query("SELECT * FROM scholarships ORDER BY created_at DESC")->fetchAll();
                if (empty($scholarships)): ?>
                    <div class="empty-state" style="grid-column: 1/-1; text-align: center; padding: 40px;">
                        <p>No scholarships found.</p>
                    </div>
                <?php else: foreach ($scholarships as $s): 
                    $amount_lower = strtolower($s['amount'] ?? '');
                    $funding_text = $s['amount'] ?: 'Partial Funding';
                    $funding_class = 'orange'; // Partial funding
                    if (strpos($amount_lower, 'full') !== false || strpos($amount_lower, '100%') !== false || strpos($amount_lower, 'complete') !== false) {
                        $funding_class = 'green'; // Full tuition
                        $funding_text = 'Full Tuition';
                    }

                    // Guess country for filtering
                    $country = 'United Kingdom';
                    $text_to_search = strtolower($s['title'] . ' ' . $s['provider'] . ' ' . ($s['description'] ?? ''));
                    if (strpos($text_to_search, 'united states') !== false || strpos($text_to_search, 'usa') !== false || strpos($text_to_search, 'america') !== false || strpos($text_to_search, 'us ') !== false) {
                        $country = 'United States';
                    } elseif (strpos($text_to_search, 'australia') !== false || strpos($text_to_search, 'melbourne') !== false || strpos($text_to_search, 'sydney') !== false) {
                        $country = 'Australia';
                    } elseif (strpos($text_to_search, 'germany') !== false || strpos($text_to_search, 'german') !== false || strpos($text_to_search, 'daad') !== false) {
                        $country = 'Germany';
                    } elseif (strpos($text_to_search, 'canada') !== false || strpos($text_to_search, 'canadian') !== false || strpos($text_to_search, 'toronto') !== false) {
                        $country = 'Canada';
                    }

                    // Determine type label and dot color
                    $title_lower = strtolower($s['title']);
                    $provider_lower = strtolower($s['provider']);
                    if (strpos($title_lower, 'chevening') !== false || strpos($title_lower, 'fulbright') !== false || strpos($title_lower, 'prestige') !== false || strpos($title_lower, 'excellence') !== false) {
                        $type_dot = 'purple';
                        $type_label = 'PRESTIGIOUS';
                    } elseif (strpos($provider_lower, 'university') !== false || strpos($title_lower, 'university') !== false || strpos($provider_lower, 'college') !== false) {
                        $type_dot = 'yellow';
                        $type_label = 'UNIVERSITY SPECIFIC';
                    } else {
                        $type_dot = 'green';
                        $type_label = 'GLOBAL';
                    }

                    $deadline_val = $s['deadline'] ? date('M d, Y', strtotime($s['deadline'])) : 'Varies by Country';
                ?>
                    <div class="scholarship-card" id="scholarship-<?= $s['id'] ?>">
                        <div class="card-top">
                            <div class="card-type">
                                <span class="type-dot <?= $type_dot ?>"></span>
                                <span class="type-label"><?= $type_label ?></span>
                            </div>
                            <span class="funding-badge <?= $funding_class ?>"><?= htmlspecialchars($funding_text) ?></span>
                        </div>
                        <h3 class="card-title"><?= htmlspecialchars($s['title']) ?></h3>
                        <p class="card-location">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            <?= htmlspecialchars($country) ?>
                        </p>
                        <div class="card-bottom">
                            <div class="card-deadline">
                                <span class="deadline-label">DEADLINE</span>
                                <span class="deadline-value"><?= $deadline_val ?></span>
                            </div>
                            <a href="application-form.php?source=scholarship&id=<?= $s['id'] ?>" class="btn-apply-now">Apply Now</a>
                        </div>
                    </div>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <?php require_once 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const fundedCheckbox = document.querySelector('#filter-funded input');
    const countrySelect = document.getElementById('filter-country');
    const scholarshipCards = document.querySelectorAll('.scholarship-card');

    function filterScholarships() {
        const showFullyFundedOnly = fundedCheckbox.checked;
        const selectedCountry = countrySelect.value;

        scholarshipCards.forEach(card => {
            const fundingBadge = card.querySelector('.funding-badge').innerText.toLowerCase();
            const cardCountry = card.querySelector('.card-location').innerText.trim();
            
            let matchesFunded = !showFullyFundedOnly || fundingBadge.includes('full');
            let matchesCountry = selectedCountry === 'All Countries' || cardCountry.includes(selectedCountry);

            if (matchesFunded && matchesCountry) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }

    if (fundedCheckbox) {
        fundedCheckbox.addEventListener('change', filterScholarships);
    }
    if (countrySelect) {
        countrySelect.addEventListener('change', filterScholarships);
    }

    // Redirect handled directly via HTML href links to unified form

    const searchBtns = document.querySelectorAll('.search-btn, #btn-search');
    searchBtns.forEach(btn => {
        if(btn.type === 'submit') return; // Skip if already in a form
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const wrapper = this.closest('.search-bar, .search-container') || this.parentElement;
            if(!wrapper) return;
            const input = wrapper.querySelector('input[type="text"]');
            if(input && input.value) {
                let target = window.location.pathname.includes('university') ? 'university.php' : 'programs.php';
                window.location.href = target + '?q=' + encodeURIComponent(input.value);
            }
        });
    });
});
</script>
</body>
</html>
