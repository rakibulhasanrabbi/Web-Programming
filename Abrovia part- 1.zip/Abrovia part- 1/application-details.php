<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config/database.php';

$userId = $_SESSION['user_id'];
$appId = isset($_GET['id']) ? (int)$_GET['id'] : null;

// Fetch application
if ($appId) {
    $stmt = $pdo->prepare("SELECT * FROM applications WHERE user_id = ? AND id = ?");
    $stmt->execute([$userId, $appId]);
} else {
    $stmt = $pdo->prepare("SELECT * FROM applications WHERE user_id = ? ORDER BY applied_at DESC LIMIT 1");
    $stmt->execute([$userId]);
}
$application = $stmt->fetch(PDO::FETCH_ASSOC);
$hasApplication = $application ? true : false;

// Process file upload / document submit
$upload_success = '';
$upload_error = '';

if ($hasApplication && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'upload_document') {
        $doc_id = intval($_POST['doc_id'] ?? 0);
        if ($doc_id > 0 && !empty($_FILES['doc_file']['name'])) {
            // Verify document belongs to application
            $doc_stmt = $pdo->prepare("SELECT * FROM documents WHERE id = ? AND application_id = ?");
            $doc_stmt->execute([$doc_id, $application['id']]);
            $doc = $doc_stmt->fetch();
            
            if ($doc) {
                if (!is_dir('uploads')) {
                    mkdir('uploads', 0777, true);
                }
                
                $clean_name = preg_replace("/[^a-zA-Z0-9\._-]/", "_", $_FILES['doc_file']['name']);
                $fileName = 'app_' . $application['id'] . '_doc_' . $doc_id . '_' . time() . '_' . $clean_name;
                $destPath = 'uploads/' . $fileName;
                
                if (move_uploaded_file($_FILES['doc_file']['tmp_name'], $destPath)) {
                    $up_stmt = $pdo->prepare("UPDATE documents SET file_path = ?, status = 'under_review', admin_message = NULL WHERE id = ?");
                    $up_stmt->execute([$destPath, $doc_id]);
                    
                    // Create dynamic log in status history for this upload
                    $log_msg = "Uploaded requested credential: " . $doc['name'];
                    $hist_stmt = $pdo->prepare("INSERT INTO status_history (application_id, old_status, new_status, changed_by, comments) VALUES (?, ?, ?, ?, ?)");
                    $hist_stmt->execute([$application['id'], $application['status'], $application['status'], $userId, $log_msg]);

                    // Generate user notification
                    $notif_msg = "You have uploaded document: " . $doc['name'] . " for your " . $application['program_name'] . " application.";
                    $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)")->execute([$userId, $notif_msg]);
                    
                    $upload_success = "Document '{$doc['name']}' uploaded successfully!";
                    
                    // Refresh application state
                    header("Location: application-details.php?id=" . $application['id'] . "&success=" . urlencode($upload_success));
                    exit;
                } else {
                    $upload_error = "Failed to save uploaded file.";
                }
            } else {
                $upload_error = "Invalid document request.";
            }
        }
    } elseif ($_POST['action'] === 'upload_custom_document') {
        $doc_name = trim($_POST['doc_name'] ?? '');
        if (!empty($doc_name) && !empty($_FILES['custom_doc_file']['name'])) {
            if (!is_dir('uploads')) {
                mkdir('uploads', 0777, true);
            }
            
            $clean_name = preg_replace("/[^a-zA-Z0-9\._-]/", "_", $_FILES['custom_doc_file']['name']);
            $fileName = 'app_' . $application['id'] . '_custom_' . time() . '_' . $clean_name;
            $destPath = 'uploads/' . $fileName;
            
            if (move_uploaded_file($_FILES['custom_doc_file']['tmp_name'], $destPath)) {
                $doc_stmt = $pdo->prepare("INSERT INTO documents (application_id, name, file_path, status) VALUES (?, ?, ?, 'under_review')");
                $doc_stmt->execute([$application['id'], $doc_name, $destPath]);
                
                $log_msg = "Uploaded supporting credential: " . $doc_name;
                $pdo->prepare("INSERT INTO status_history (application_id, old_status, new_status, changed_by, comments) VALUES (?, ?, ?, ?, ?)")
                    ->execute([$application['id'], $application['status'], $application['status'], $userId, $log_msg]);
                
                $upload_success = "Supporting document uploaded successfully!";
                header("Location: application-details.php?id=" . $application['id'] . "&success=" . urlencode($upload_success));
                exit;
            } else {
                $upload_error = "Failed to save supporting document.";
            }
        }
    }
}

$success_param = $_GET['success'] ?? '';

// Fetch dynamic Counselor info if assigned
$counselor = null;
if ($hasApplication && $application['counselor_id']) {
    $coun_stmt = $pdo->prepare("SELECT full_name, email FROM users WHERE id = ?");
    $coun_stmt->execute([$application['counselor_id']]);
    $counselor = $coun_stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch requested and uploaded documents
$documents = [];
if ($hasApplication) {
    $doc_stmt = $pdo->prepare("SELECT * FROM documents WHERE application_id = ? ORDER BY uploaded_at DESC");
    $doc_stmt->execute([$application['id']]);
    $documents = $doc_stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch status history logs
$history = [];
if ($hasApplication) {
    $hist_stmt = $pdo->prepare("
        SELECT sh.*, u.full_name as author_name, u.role as author_role 
        FROM status_history sh 
        LEFT JOIN users u ON sh.changed_by = u.id 
        WHERE sh.application_id = ? 
        ORDER BY sh.created_at DESC
    ");
    $hist_stmt->execute([$application['id']]);
    $history = $hist_stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Details - Abrovia</title>
    <link rel="stylesheet" href="assets/css/application-details.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .alert-action-needed {
            background: rgba(239, 68, 68, 0.08);
            border: 1px dashed rgba(239, 68, 68, 0.3);
            border-radius: var(--radius-md);
            padding: 20px 24px;
            margin-bottom: 30px;
            display: flex;
            align-items: flex-start;
            gap: 16px;
            animation: pulse-border-red 2s infinite ease-in-out;
        }
        @keyframes pulse-border-red {
            0% { border-color: rgba(239, 68, 68, 0.3); }
            50% { border-color: rgba(239, 68, 68, 0.7); }
            100% { border-color: rgba(239, 68, 68, 0.3); }
        }
        
        /* Interactive Step Progress Tracker mapped to 5 Stages */
        .journey-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
            position: relative;
            text-align: center;
        }
        .journey-step .step-dot {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #111832;
            border: 2px solid rgba(255,255,255,0.08);
            color: var(--text-muted);
            font-weight: 700;
            font-size: 0.85rem;
            z-index: 2;
            transition: all 0.3s ease;
        }
        .journey-step.completed .step-dot {
            background: var(--accent);
            border-color: var(--accent);
            color: #fff;
            box-shadow: 0 0 12px var(--accent-glow);
        }
        .journey-step.current .step-dot {
            background: #fff;
            border-color: var(--accent);
            color: var(--bg-body);
            box-shadow: 0 0 15px rgba(255,255,255,0.2);
        }
        .journey-step.action-required .step-dot {
            background: var(--danger);
            border-color: var(--danger);
            color: #fff;
            animation: shake 0.5s infinite;
        }
        .journey-line {
            position: absolute;
            top: 18px;
            left: calc(50% + 18px);
            right: calc(-50% + 18px);
            height: 2px;
            background: rgba(255,255,255,0.05);
            z-index: 1;
        }
        .journey-line.filled {
            background: var(--accent);
        }
        
        /* Counselor card styling */
        .counselor-card {
            background: linear-gradient(135deg, rgba(108, 63, 255, 0.08), rgba(17, 24, 50, 0.4));
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 24px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .counselor-avatar {
            width: 52px;
            height: 52px;
            background: var(--accent);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
            color: #fff;
            font-weight: 700;
            box-shadow: 0 4px 15px var(--accent-glow);
        }
        
        /* Dynamic uploads elements */
        .upload-input-wrap {
            position: relative;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        /* Visa Guidance Portal styling */
        .visa-portal-card {
            background: linear-gradient(135deg, #10b98115, #111832);
            border: 1px solid rgba(16, 185, 129, 0.2);
            border-radius: var(--radius-md);
            padding: 28px;
            margin-bottom: 24px;
            box-shadow: 0 8px 30px rgba(16, 185, 129, 0.05);
        }
    </style>
</head>
<body>

    <!-- ========== NAVBAR ========== -->
    <?php require_once 'includes/header.php'; ?>

    <!-- MAIN CONTENT -->
    <main class="page-content">
        <div class="content-container">

            <?php if (!$hasApplication): ?>
            <!-- EMPTY STATE -->
            <div style="text-align: center; padding: 80px 20px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); margin-top: 40px;">
                <div style="width: 80px; height: 80px; background: rgba(108, 63, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 24px; color: var(--accent);">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>
                </div>
                <h2 style="font-size: 1.8rem; font-weight: 700; margin-bottom: 12px; color: var(--text-primary);">No Active Applications</h2>
                <p style="font-size: 0.95rem; color: var(--text-secondary); max-width: 400px; margin: 0 auto 32px; line-height: 1.6;">Track the step-by-step progress of your target universities and programs here.</p>
                <a href="application-form.php" style="display: inline-block; padding: 12px 32px; font-size: 0.95rem; font-weight: 600; color: #fff; background: var(--accent); border-radius: 999px; box-shadow: 0 4px 16px var(--accent-glow); transition: all 0.3s ease; text-decoration: none;">Start New Application</a>
            </div>
            <?php else: 
                $status = $application['status'];
                
                // Map the 8 statuses to 5 visual steps:
                // Step 1: Submitted (All)
                // Step 2: Counselor Review (Processing, Documents Required)
                // Step 3: Forwarded (Submitted to University)
                // Step 4: Decision (Accepted, Rejected, Waitlisted)
                // Step 5: Completed (Completed)
                
                $step1 = 'completed';
                $step2 = 'upcoming';
                $step3 = 'upcoming';
                $step4 = 'upcoming';
                $step5 = 'upcoming';
                
                $line1 = '';
                $line2 = '';
                $line3 = '';
                $line4 = '';

                // Evaluate processing
                if (in_array($status, ['Processing', 'Documents Required', 'Submitted to University', 'Accepted', 'Waitlisted', 'Rejected', 'Completed'])) {
                    $step1 = 'completed';
                    $line1 = 'filled';
                    if ($status === 'Documents Required') {
                        $step2 = 'action-required';
                    } elseif ($status === 'Processing') {
                        $step2 = 'current';
                    } else {
                        $step2 = 'completed';
                    }
                }
                
                // Evaluate forwarded
                if (in_array($status, ['Submitted to University', 'Accepted', 'Waitlisted', 'Rejected', 'Completed'])) {
                    $step2 = 'completed';
                    $line2 = 'filled';
                    if ($status === 'Submitted to University') {
                        $step3 = 'current';
                    } else {
                        $step3 = 'completed';
                    }
                }
                
                // Evaluate decision
                if (in_array($status, ['Accepted', 'Waitlisted', 'Rejected', 'Completed'])) {
                    $step3 = 'completed';
                    $line3 = 'filled';
                    if (in_array($status, ['Accepted', 'Waitlisted', 'Rejected'])) {
                        $step4 = 'current';
                    } else {
                        $step4 = 'completed';
                    }
                }
                
                // Evaluate completed
                if ($status === 'Completed') {
                    $step4 = 'completed';
                    $line4 = 'filled';
                    $step5 = 'completed';
                }
            ?>

            <!-- Back Link -->
            <a href="applications.php" class="back-link" id="back-to-apps">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to My Applications
            </a>

            <!-- Success/Error Feedback Alerts -->
            <?php if ($success_param): ?>
            <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); color: #10b981; padding: 12px 16px; border-radius: 8px; margin-bottom: 24px; font-size: 0.9rem;">
                ✓ <?= htmlspecialchars($success_param) ?>
            </div>
            <?php endif; ?>
            <?php if ($upload_error): ?>
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #ef4444; padding: 12px 16px; border-radius: 8px; margin-bottom: 24px; font-size: 0.9rem;">
                ⚠️ <?= htmlspecialchars($upload_error) ?>
            </div>
            <?php endif; ?>

            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px; flex-wrap: wrap; gap: 20px;">
                <!-- Page Header -->
                <div class="page-header" style="margin-bottom: 0;">
                    <div>
                        <h1 class="page-title"><?php echo htmlspecialchars($application['university_name']); ?></h1>
                        <p class="page-subtitle"><?php echo htmlspecialchars($application['program_name']); ?> • Application ID: #<?= $application['id'] ?></p>
                    </div>
                </div>
                <div class="header-right" style="display: flex; gap: 16px; align-items: center;">
                    <div class="info-box" style="margin-bottom: 0;">
                        <span class="info-label">STATUS</span>
                        <span class="info-value" style="color: var(--accent); text-transform: uppercase;"><?php echo htmlspecialchars($application['status']); ?></span>
                    </div>
                    <a href="application-form.php" style="padding: 10px 20px; font-size: 0.85rem; font-weight: 600; color: #fff; background: var(--bg-card); border: 1px solid var(--border); border-radius: 8px; transition: all 0.3s ease; text-decoration: none;">+ Start New Application</a>
                </div>
            </div>

            <!-- ACTION NEEDED ALERT BOX -->
            <?php if ($status === 'Documents Required'): ?>
            <div class="alert-action-needed">
                <div style="color: var(--danger); font-size: 1.4rem; padding-top: 2px;">⚠️</div>
                <div>
                    <h3 style="color:#ef4444; font-size:1.05rem; font-weight:700; margin-bottom:4px;">Action Required: Additional Credentials Requested</h3>
                    <p style="color: var(--text-secondary); font-size:0.85rem; line-height:1.5; max-width:700px;">
                        Our counselors have updated your application status to **Documents Required**. Please check the requested items in the **Supporting Credentials** panel below and upload them immediately to continue processing.
                    </p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Interactive Study Abroad Journey Tracker -->
            <section class="status-card" id="status-card">
                <h2 class="card-heading">Admission Journey Tracker</h2>
                <div class="status-tracker">
                    
                    <div class="journey-step <?= $step1 ?>">
                        <div class="step-dot">1</div>
                        <div class="journey-line <?= $line1 ?>"></div>
                        <span class="track-label" style="font-weight:600; margin-top:8px;">Submitted</span>
                        <span class="track-date"><?= date('M d', strtotime($application['applied_at'])) ?></span>
                    </div>
                    
                    <div class="journey-step <?= $step2 ?>">
                        <div class="step-dot">2</div>
                        <div class="journey-line <?= $line2 ?>"></div>
                        <span class="track-label" style="font-weight:600; margin-top:8px;">Counselor Review</span>
                        <span class="track-date"><?= $status === 'Documents Required' ? 'Action Required' : ($status === 'Processing' ? 'In Progress' : 'Completed') ?></span>
                    </div>
                    
                    <div class="journey-step <?= $step3 ?>">
                        <div class="step-dot">3</div>
                        <div class="journey-line <?= $line3 ?>"></div>
                        <span class="track-label" style="font-weight:600; margin-top:8px;">Sent to University</span>
                        <span class="track-date"><?= $status === 'Submitted to University' ? 'Evaluating' : (in_array($status, ['Accepted', 'Rejected', 'Waitlisted', 'Completed']) ? 'Completed' : 'Pending') ?></span>
                    </div>
                    
                    <div class="journey-step <?= $step4 ?>">
                        <div class="step-dot">4</div>
                        <div class="journey-line <?= $line4 ?>"></div>
                        <span class="track-label" style="font-weight:600; margin-top:8px;">Admissions Decision</span>
                        <span class="track-date">
                            <?php 
                            if (in_array($status, ['Accepted', 'Completed'])) echo 'Accepted ✓';
                            elseif ($status === 'Rejected') echo 'Declined ✗';
                            elseif ($status === 'Waitlisted') echo 'Waitlisted';
                            else echo 'Pending';
                            ?>
                        </span>
                    </div>
                    
                    <div class="journey-step <?= $step5 ?>">
                        <div class="step-dot">5</div>
                        <span class="track-label" style="font-weight:600; margin-top:8px;">Journey Completed</span>
                        <span class="track-date"><?= $status === 'Completed' ? 'Completed ✓' : 'Visa Phase' ?></span>
                    </div>

                </div>
            </section>

            <!-- STUDY ABROAD VISA & FINALIZATION MODULE -->
            <?php if (in_array($status, ['Accepted', 'Completed'])): ?>
                <div class="visa-portal-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(16, 185, 129, 0.15); padding-bottom:16px; margin-bottom:18px;">
                        <h2 style="font-size:1.25rem; font-weight:700; color:#10b981; display:flex; align-items:center; gap:8px;">
                            🎓 Visa Guidance Portal
                        </h2>
                        <span style="background:rgba(16, 185, 129, 0.1); color:#10b981; border:1px solid rgba(16, 185, 129, 0.3); font-size:0.7rem; font-weight:600; border-radius:4px; padding:3px 8px; text-transform:uppercase;">Offer Received</span>
                    </div>
                    <p style="color:var(--text-secondary); font-size:0.85rem; line-height:1.6; margin-bottom:20px;">
                        Congratulations on receiving your admission offer! You are now in the **Visa & Enrollment Phase**. Please follow the crucial steps below to ensure a smooth transition:
                    </p>
                    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:16px;">
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); padding:16px; border-radius:var(--radius-sm);">
                            <div style="color:#10b981; font-weight:700; font-size:1rem; margin-bottom:4px;">Step 1: Offer Acceptance</div>
                            <p style="color:var(--text-muted); font-size:0.75rem; line-height:1.5;">Confirm and pay the university deposit to secure your seat and receive your CAS / Enrollment Letter.</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); padding:16px; border-radius:var(--radius-sm);">
                            <div style="color:#10b981; font-weight:700; font-size:1rem; margin-bottom:4px;">Step 2: Financial Proof</div>
                            <p style="color:var(--text-muted); font-size:0.75rem; line-height:1.5;">Prepare bank solvency solvency statements showing sufficient funds for tuition and living expenses (e.g. 28 days rule).</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); padding:16px; border-radius:var(--radius-sm);">
                            <div style="color:#10b981; font-weight:700; font-size:1rem; margin-bottom:4px;">Step 3: Visa Submission</div>
                            <p style="color:var(--text-muted); font-size:0.75rem; line-height:1.5;">Complete the online student visa application, submit biometric credentials, and attend embassy interviews.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Assigned Counselor Glass Card -->
            <?php if ($counselor): ?>
                <div class="counselor-card">
                    <div class="counselor-avatar">
                        <?= strtoupper(substr($counselor['full_name'], 0, 1)) ?>
                    </div>
                    <div>
                        <div style="font-size:0.68rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:0.5px;">Your Dedicated Study Abroad Counselor</div>
                        <h4 style="color:#fff; font-size:1rem; font-weight:600; margin:2px 0 4px;"><?= htmlspecialchars($counselor['full_name']) ?></h4>
                        <p style="color:var(--text-secondary); font-size:0.8rem; display:flex; align-items:center; gap:6px;">
                            ✉ <?= htmlspecialchars($counselor['email']) ?> • Available to support you at any stage
                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Bottom Grid: Documents + Timeline -->
            <section class="bottom-grid">
                
                <!-- Supporting Credentials Upload Portal -->
                <div class="docs-card" id="docs-card">
                    <div class="card-header-row">
                        <h2 class="card-heading" style="margin-bottom:0;">Supporting Credentials</h2>
                        <button class="btn-upload" onclick="document.getElementById('custom-upload-section').style.display='block';">+ Add Custom Doc</button>
                    </div>
                    
                    <!-- Custom document upload overlay block -->
                    <div id="custom-upload-section" style="display:none; background:rgba(255,255,255,0.02); border:1px solid var(--border); border-radius:var(--radius-sm); padding:16px; margin-bottom:20px;">
                        <h4 style="font-size:0.85rem; color:#fff; font-weight:600; margin-bottom:10px;">Upload Supporting File</h4>
                        <form action="" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="upload_custom_document">
                            <div class="form-group" style="margin-bottom:12px;">
                                <label class="form-label" style="font-size:0.75rem;">Document Name</label>
                                <input type="text" name="doc_name" class="form-input" placeholder="e.g. CV, Recommendation Letter" required style="padding:8px 12px; font-size:0.8rem;">
                            </div>
                            <div class="form-group" style="margin-bottom:16px;">
                                <label class="form-label" style="font-size:0.75rem;">Select File</label>
                                <input type="file" name="custom_doc_file" required style="font-size:0.8rem;">
                            </div>
                            <div style="display:flex; justify-content:flex-end; gap:8px;">
                                <button type="button" class="btn-cancel" onclick="document.getElementById('custom-upload-section').style.display='none';" style="padding:6px 12px; font-size:0.75rem;">Cancel</button>
                                <button type="submit" class="btn-submit" style="padding:6px 16px; font-size:0.75rem;">Upload File</button>
                            </div>
                        </form>
                    </div>

                    <div class="docs-grid">
                        <?php if (empty($documents)): ?>
                            <div style="grid-column: 1/-1; text-align:center; padding:30px; color:var(--text-muted); font-size:0.85rem; border:1px dashed var(--border); border-radius:var(--radius-sm);">
                                No credentials uploaded yet. Click "+ Add Custom Doc" or respond to required credentials.
                            </div>
                        <?php else: foreach ($documents as $doc): 
                            // Map document statuses
                            $status_class = 'review';
                            $status_label = 'Under Review';
                            if ($doc['status'] === 'verified') {
                                $status_class = 'verified';
                                $status_label = 'Verified ✓';
                            } elseif ($doc['status'] === 'rejected') {
                                $status_class = 'rejected';
                                $status_label = 'Rejected ✗';
                            } elseif ($doc['status'] === 'pending_upload') {
                                $status_class = 'pending';
                                $status_label = 'Pending Upload';
                            }
                        ?>
                            <?php if ($doc['status'] === 'pending_upload' || $doc['status'] === 'rejected'): ?>
                                <!-- Interactive document submission form -->
                                <form action="" method="POST" enctype="multipart/form-data" style="display:contents;">
                                    <input type="hidden" name="action" value="upload_document">
                                    <input type="hidden" name="doc_id" value="<?= $doc['id'] ?>">
                                    <div class="doc-item" style="border-color: <?= $doc['status'] === 'rejected' ? 'rgba(239, 68, 68, 0.4)' : 'rgba(245, 158, 11, 0.4)' ?>; background: rgba(255,255,255,0.01);">
                                        <div class="doc-icon" style="background: <?= $doc['status'] === 'rejected' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(245, 158, 11, 0.1)' ?>; color: <?= $doc['status'] === 'rejected' ? '#ef4444' : '#f59e0b' ?>;">
                                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                        </div>
                                        <div class="doc-info">
                                            <span class="doc-name"><?= htmlspecialchars($doc['name']) ?></span>
                                            <span class="doc-status" style="color: <?= $doc['status'] === 'rejected' ? '#ef4444' : '#f59e0b' ?>;">
                                                ● <?= $status_label ?>
                                            </span>
                                            <?php if (!empty($doc['admin_message'])): ?>
                                                <span style="font-size:0.7rem; color:var(--text-secondary); margin-top:2px; font-style:italic;">Feedback: "<?= htmlspecialchars($doc['admin_message']) ?>"</span>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <input type="file" name="doc_file" required id="file-doc-<?= $doc['id'] ?>" style="display:none;" onchange="this.form.submit()">
                                            <button type="button" onclick="document.getElementById('file-doc-<?= $doc['id'] ?>').click()" style="padding:6px 12px; font-size:0.75rem; border-radius:6px; background:var(--accent); color:#fff; font-weight:600; transition:all 0.2s;">
                                                <?= $doc['status'] === 'rejected' ? 'Re-Upload' : 'Upload' ?>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            <?php else: ?>
                                <!-- Standard document list item -->
                                <div class="doc-item">
                                    <div class="doc-icon">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                                    </div>
                                    <div class="doc-info">
                                        <span class="doc-name"><?= htmlspecialchars($doc['name']) ?></span>
                                        <span class="doc-status <?= $status_class ?>">● <?= $status_label ?></span>
                                    </div>
                                    <?php if (!empty($doc['file_path'])): ?>
                                        <a href="<?= htmlspecialchars($doc['file_path']) ?>" download class="doc-download" aria-label="Download">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; endif; ?>
                    </div>
                </div>

                <!-- Status Journey Audit Log Timeline -->
                <div class="timeline-card" id="timeline-card">
                    <h2 class="card-heading">Application Timeline</h2>
                    <div class="timeline">
                        <?php if (empty($history)): ?>
                            <div style="color:var(--text-muted); font-size:0.8rem; text-align:center; padding:20px;">
                                No status logs recorded yet.
                            </div>
                        <?php else: 
                            $first = true;
                            foreach ($history as $h): 
                        ?>
                            <div class="timeline-item">
                                <div class="tl-dot <?= $first ? 'active' : '' ?>"></div>
                                <?php if ($h !== end($history)): ?>
                                    <div class="tl-line"></div>
                                <?php endif; ?>
                                <div class="tl-content">
                                    <span class="tl-date <?= $first ? 'active' : '' ?>">
                                        <?= date('M d, Y • h:i A', strtotime($h['created_at'])) ?>
                                    </span>
                                    <h4 class="tl-title">
                                        <?php if ($h['old_status'] !== $h['new_status'] && !empty($h['old_status'])): ?>
                                            Status updated to <strong><?= htmlspecialchars($h['new_status']) ?></strong>
                                        <?php else: ?>
                                            <?= htmlspecialchars($h['comments'] ? explode(':', $h['comments'])[0] : 'Activity logged') ?>
                                        <?php endif; ?>
                                    </h4>
                                    
                                    <?php if (!empty($h['comments'])): ?>
                                        <p class="tl-desc" style="background:rgba(255,255,255,0.01); border-left:2px solid var(--accent); padding:4px 8px; border-radius:0 4px 4px 0; margin-top:4px;">
                                            "<?= htmlspecialchars($h['comments']) ?>"
                                        </p>
                                    <?php endif; ?>
                                    
                                    <span style="font-size:0.68rem; color:var(--text-muted); display:block; margin-top:4px;">
                                        By <?= htmlspecialchars($h['author_name']) ?> (<?= ucfirst($h['author_role']) ?>)
                                    </span>
                                </div>
                            </div>
                        <?php 
                            $first = false;
                            endforeach; 
                        endif; 
                        ?>
                    </div>
                </div>
            </section>
            
            <?php endif; ?>

        </div>
    </main>

    <!-- ========== FOOTER ========== -->
    <?php require_once 'includes/footer.php'; ?>

</body>
</html>
