<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';

// Action selector
$action = $_REQUEST['action'] ?? '';

if ($action === 'purchase') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
        exit;
    }

    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Please login to purchase.', 'need_login' => true]);
        exit;
    }

    $userId = $_SESSION['user_id'];
    $courseId = isset($_POST['course_id']) ? intval($_POST['course_id']) : 0;

    if ($courseId <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid course selected.']);
        exit;
    }

    try {
        // Get course details
        $stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ? AND status = 'active'");
        $stmt->execute([$courseId]);
        $course = $stmt->fetch();

        if (!$course) {
            echo json_encode(['success' => false, 'message' => 'Course not found or inactive.']);
            exit;
        }

        // Check if enrollment exists
        $stmt = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?");
        $stmt->execute([$userId, $courseId]);
        $enrollment = $stmt->fetch();

        if ($enrollment) {
            if ($enrollment['status'] === 'active') {
                echo json_encode([
                    'success' => true,
                    'message' => 'You are already enrolled in this course!',
                    'redirect' => 'prep-center.php?course=' . urlencode($course['slug'])
                ]);
                exit;
            } else if ($enrollment['status'] === 'suspended') {
                echo json_encode([
                    'success' => false,
                    'message' => 'Your access to this course has been suspended. Please contact support.'
                ]);
                exit;
            }
            // If status is 'removed', we will allow re-purchase/activation
        }

        // Start Transaction
        $pdo->beginTransaction();

        $txId = 'TXN-' . strtoupper(uniqid());

        // Create payment record
        $stmt = $pdo->prepare("
            INSERT INTO payments (user_id, course_id, amount, currency, payment_method, transaction_id, status)
            VALUES (?, ?, ?, ?, 'demo', ?, 'completed')
        ");
        $stmt->execute([$userId, $courseId, $course['price'], $course['currency'], $txId]);
        $paymentId = $pdo->lastInsertId();

        // Create or update enrollment
        if ($enrollment) {
            $stmt = $pdo->prepare("
                UPDATE enrollments 
                SET payment_id = ?, status = 'active', enrolled_at = CURRENT_TIMESTAMP 
                WHERE user_id = ? AND course_id = ?
            ");
            $stmt->execute([$paymentId, $userId, $courseId]);
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO enrollments (user_id, course_id, payment_id, status)
                VALUES (?, ?, ?, 'active')
            ");
            $stmt->execute([$userId, $courseId, $paymentId]);
        }

        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Payment successful! Redirecting to prep center...',
            'redirect' => 'prep-center.php?course=' . urlencode($course['slug'])
        ]);
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        echo json_encode(['success' => false, 'message' => 'Transaction failed: ' . $e->getMessage()]);
        exit;
    }

} else if ($action === 'check_enrollment') {
    $courseId = isset($_REQUEST['course_id']) ? intval($_REQUEST['course_id']) : 0;
    if (!isset($_SESSION['user_id']) || $courseId <= 0) {
        echo json_encode(['enrolled' => false, 'status' => null]);
        exit;
    }

    $userId = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT status FROM enrollments WHERE user_id = ? AND course_id = ?");
    $stmt->execute([$userId, $courseId]);
    $enrollment = $stmt->fetch();

    if ($enrollment) {
        echo json_encode(['enrolled' => $enrollment['status'] === 'active', 'status' => $enrollment['status']]);
    } else {
        echo json_encode(['enrolled' => false, 'status' => null]);
    }
    exit;

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
    exit;
}
