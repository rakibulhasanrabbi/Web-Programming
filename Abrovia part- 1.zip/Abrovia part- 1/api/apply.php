<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to apply.']);
    exit;
}

$userId = $_SESSION['user_id'];
$universityName = $_POST['university_name'] ?? 'Unknown University';
$programName = $_POST['program_name'] ?? 'Unknown Program';

try {
    $stmt = $pdo->prepare("INSERT INTO applications (user_id, university_name, program_name) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $universityName, $programName]);
    
    echo json_encode(['success' => true, 'message' => 'Application submitted successfully!']);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
