<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to upgrade your account.']);
    exit;
}

$userId = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

if ($action === 'upgrade') {
    try {
        $stmt = $pdo->prepare("UPDATE users SET is_premium = 1 WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Push notification
        $notif_msg = "Congratulations! Your account has been upgraded to Premium. All advanced evaluation tools, predictions, and priority reports are now unlocked.";
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $notif_stmt->execute([$userId, $notif_msg]);

        echo json_encode(['success' => true, 'message' => 'Account upgraded to Premium! Refreshing page...']);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Upgrade failed: ' . $e->getMessage()]);
        exit;
    }
} else if ($action === 'downgrade_demo') {
    try {
        $stmt = $pdo->prepare("UPDATE users SET is_premium = 0 WHERE id = ?");
        $stmt->execute([$userId]);
        echo json_encode(['success' => true, 'message' => 'Account reset to Free.']);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Downgrade failed: ' . $e->getMessage()]);
        exit;
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
    exit;
}
