<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'You must be logged in to join events.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$userId = $_SESSION['user_id'];
$eventId = isset($_POST['event_id']) ? (int)$_POST['event_id'] : 0;

if ($eventId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid event ID.']);
    exit;
}

try {
    // Check if event exists and is not cancelled/completed
    $evtStmt = $pdo->prepare("SELECT status FROM events WHERE id = ?");
    $evtStmt->execute([$eventId]);
    $event = $evtStmt->fetch();
    
    if (!$event) {
        echo json_encode(['success' => false, 'message' => 'Event not found.']);
        exit;
    }
    
    if ($event['status'] === 'cancelled' || $event['status'] === 'completed') {
        echo json_encode(['success' => false, 'message' => 'This event is no longer accepting requests.']);
        exit;
    }

    // Check if already requested
    $chkStmt = $pdo->prepare("SELECT id FROM event_requests WHERE user_id = ? AND event_id = ?");
    $chkStmt->execute([$userId, $eventId]);
    if ($chkStmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'You have already submitted a request for this event.']);
        exit;
    }

    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $additionalInfo = isset($_POST['additional_info']) ? trim($_POST['additional_info']) : '';
    
    if (empty($phone)) {
        echo json_encode(['success' => false, 'message' => 'Phone number is required.']);
        exit;
    }

    // Insert request
    $insStmt = $pdo->prepare("INSERT INTO event_requests (user_id, event_id, phone, additional_info, status) VALUES (?, ?, ?, ?, 'pending')");
    $result = $insStmt->execute([$userId, $eventId, $phone, $additionalInfo]);

    echo json_encode(['success' => $result]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error.']);
}
?>
