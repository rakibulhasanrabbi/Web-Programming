<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to save items.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$action = $_POST['action'] ?? '';

if ($action === 'remove') {
    $id = $_POST['id'] ?? 0;
    $stmt = $pdo->prepare("DELETE FROM saved_items WHERE id = ? AND user_id = ?");
    $result = $stmt->execute([$id, $_SESSION['user_id']]);
    echo json_encode(['success' => $result]);
} else if ($action === 'add') {
    $item_type = $_POST['item_type'] ?? 'program';
    $item_title = $_POST['item_title'] ?? 'Unknown Item';
    $item_url = $_POST['item_url'] ?? '#';

    // Check if already saved
    $stmt = $pdo->prepare("SELECT id FROM saved_items WHERE user_id = ? AND item_title = ?");
    $stmt->execute([$_SESSION['user_id'], $item_title]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => true, 'message' => 'Already saved']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO saved_items (user_id, item_type, item_title, item_url) VALUES (?, ?, ?, ?)");
    $result = $stmt->execute([$_SESSION['user_id'], $item_type, $item_title, $item_url]);
    echo json_encode(['success' => $result]);
} else {
    echo json_encode(['success' => false, 'message' => 'Unknown action.']);
}
?>
