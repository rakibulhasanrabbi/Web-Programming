<?php
// auth/logout.php
session_start();

// Determine redirect location based on role before clearing session
$redirect = '../login.php';
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
    $redirect = '../admin-login.php';
}

// Unset all session variables
$_SESSION = array();

// Destroy the session cookie if it exists
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Redirect to the determined login page
header('Location: ' . $redirect);
exit;
?>
