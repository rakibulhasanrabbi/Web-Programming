<?php
// auth/login_process.php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $_SESSION['login_error'] = 'Both email and password are required.';
        header('Location: ../login.php');
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT id, full_name, password_hash, role, status FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            if ($user['status'] === 'suspended') {
                $_SESSION['login_error'] = 'Your account has been suspended. Please contact support.';
                header('Location: ../login.php');
                exit;
            }
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_role'] = $user['role'];
            
            // Redirect based on role or just to dashboard
            if ($user['role'] === 'admin') {
                header('Location: ../admin.php');
            } else {
                header('Location: ../dashboard.php');
            }
            exit;
        } else {
            $_SESSION['login_error'] = 'Invalid email or password.';
            header('Location: ../login.php');
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['login_error'] = 'Database error: ' . $e->getMessage();
        header('Location: ../login.php');
        exit;
    }
} else {
    header('Location: ../login.php');
    exit;
}
?>
