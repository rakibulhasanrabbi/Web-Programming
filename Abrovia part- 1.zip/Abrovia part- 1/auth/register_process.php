<?php
// auth/register_process.php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['fullName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';

    if (empty($fullName) || empty($email) || empty($password) || empty($confirmPassword)) {
        $_SESSION['register_error'] = 'All fields are required.';
        header('Location: ../signup.php');
        exit;
    }

    if ($password !== $confirmPassword) {
        $_SESSION['register_error'] = 'Passwords do not match.';
        header('Location: ../signup.php');
        exit;
    }

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        $_SESSION['register_error'] = 'Email is already registered.';
        header('Location: ../signup.php');
        exit;
    }

    // Hash the password securely
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)");
        $stmt->execute([$fullName, $email, $hashedPassword]);
        
        $_SESSION['register_success'] = 'Registration successful! Please log in.';
        header('Location: ../login.php');
        exit;
    } catch (PDOException $e) {
        $_SESSION['register_error'] = 'Database error: ' . $e->getMessage();
        header('Location: ../signup.php');
        exit;
    }
} else {
    header('Location: ../signup.php');
    exit;
}
?>
