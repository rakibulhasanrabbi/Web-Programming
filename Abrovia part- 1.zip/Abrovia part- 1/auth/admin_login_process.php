<?php
// auth/admin_login_process.php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $_SESSION['admin_login_error'] = 'Both email and password are required.';
        header('Location: ../admin-login.php');
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT id, full_name, password_hash, role FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            if ($user['role'] !== 'admin') {
                $_SESSION['admin_login_error'] = 'Access denied. Admin privileges required.';
                header('Location: ../admin-login.php');
                exit;
            }
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_role'] = $user['role'];
            header('Location: ../admin/dashboard.php');
            exit;
        } else {
            $_SESSION['admin_login_error'] = 'Invalid email or password.';
            header('Location: ../admin-login.php');
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION['admin_login_error'] = 'A system error occurred. Please try again.';
        header('Location: ../admin-login.php');
        exit;
    }
} else {
    header('Location: ../admin-login.php');
    exit;
}
?>
