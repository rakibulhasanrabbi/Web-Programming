<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config/database.php';

// Fetch user's applications with counselor assignment names
$stmt = $pdo->prepare("
    SELECT a.*, u.full_name AS counselor_name 
    FROM applications a 
    LEFT JOIN users u ON a.counselor_id = u.id 
    WHERE a.user_id = ? 
    ORDER BY a.applied_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$applications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Applications - Abrovia</title>
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Tail-ored Status Badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            font-size: 0.72rem;
            font-weight: 600;
            border-radius: var(--radius-sm);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-new {
            background: rgba(59, 130, 246, 0.1);
            color: #3b82f6;
            border: 1px solid rgba(59, 130, 246, 0.2);
        }
        
        .badge-processing {
            background: rgba(245, 158, 11, 0.1);
            color: #f59e0b;
            border: 1px solid rgba(245, 158, 11, 0.2);
        }
        
        .badge-docs {
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.25);
            animation: pulse-border 2s infinite ease-in-out;
        }

        .badge-uni {
            background: rgba(139, 92, 246, 0.1);
            color: #a78bfa;
            border: 1px solid rgba(139, 92, 246, 0.2);
        }

        .badge-accepted {
            background: rgba(16, 185, 129, 0.1);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }

        .badge-rejected {
            background: rgba(107, 114, 128, 0.1);
            color: #9ca3af;
            border: 1px solid rgba(107, 114, 128, 0.2);
        }

        .badge-waitlist {
            background: rgba(249, 115, 22, 0.1);
            color: #f97316;
            border: 1px solid rgba(249, 115, 22, 0.2);
        }

        .badge-completed {
            background: rgba(20, 184, 166, 0.1);
            color: #14b8a6;
            border: 1px solid rgba(20, 184, 166, 0.2);
        }

        @keyframes pulse-border {
            0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
            70% { box-shadow: 0 0 0 6px rgba(239, 68, 68, 0); }
            100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }

        .counselor-info {
            font-size: 0.8rem;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            gap: 6px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<div class="dashboard-layout">
    <!-- ========== NAVBAR ========== -->
    <?php require_once 'includes/header.php'; ?>

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-top">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item" id="nav-dashboard">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                    Dashboard</a>
                <a href="applications.php" class="nav-item active" id="nav-applications">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                    Applications</a>
                <a href="saved.php" class="nav-item" id="nav-saved">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
                    Saved
                </a>
                <a href="ai-evaluation.php" class="nav-item" id="nav-ai-evaluation">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    AI Evaluation
                </a>
                <a href="profile.php" class="nav-item" id="nav-profile">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    Profile
                </a>
            </nav>
        </div>
        <div class="sidebar-bottom">
            <a href="auth/logout.php" class="nav-item logout-link" style="margin-top: 10px; display: flex; align-items: center; gap: 10px; color: #94a3b8; text-decoration: none; font-size: 14px; padding: 10px; border-radius: 8px; transition: all 0.3s ease;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
            <a href="application-form.php" class="btn-new-app" id="btn-new-application">Start New Application</a>
        </div>
    </aside>

    <!-- MAIN AREA -->
    <div class="main-area">

        <!-- MAIN CONTENT -->
        <main class="main-content" id="main-content">
            <section class="welcome-section">
                <h1 class="welcome-title">My Applications</h1>
                <p class="welcome-desc">Track and manage your study abroad admissions and visa completion journey.</p>
            </section>

            <section class="applications-section">
                <?php if (empty($applications)): ?>
                    <div style="background: var(--bg-card); padding: 50px 30px; border-radius: var(--radius-md); text-align: center; border: 1px solid var(--border);">
                        <div style="width: 60px; height: 60px; background: rgba(108, 63, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: var(--accent);">
                            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                        </div>
                        <p style="color: var(--text-secondary); margin-bottom: 20px;">You haven't submitted any applications yet.</p>
                        <a href="programs.php" class="btn-new-app" style="display: inline-block; padding: 10px 24px; text-decoration: none;">Explore Programs</a>
                    </div>
                <?php else: ?>
                    <div class="programs-grid" style="grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));">
                        <?php foreach ($applications as $app): 
                            // Determine status badge class
                            $badge_class = 'badge-new';
                            $status_str = $app['status'];
                            
                            switch ($status_str) {
                                case 'New':
                                    $badge_class = 'badge-new';
                                    break;
                                case 'Processing':
                                    $badge_class = 'badge-processing';
                                    break;
                                case 'Documents Required':
                                    $badge_class = 'badge-docs';
                                    break;
                                case 'Submitted to University':
                                    $badge_class = 'badge-uni';
                                    break;
                                case 'Accepted':
                                    $badge_class = 'badge-accepted';
                                    break;
                                case 'Rejected':
                                    $badge_class = 'badge-rejected';
                                    break;
                                case 'Waitlisted':
                                    $badge_class = 'badge-waitlist';
                                    break;
                                case 'Completed':
                                    $badge_class = 'badge-completed';
                                    break;
                            }
                        ?>
                            <div class="program-card">
                                <div class="program-content" style="padding: 24px; display:flex; flex-direction:column; justify-content:space-between; height:100%; min-height:220px;">
                                    <div>
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                                            <span class="status-badge <?= $badge_class ?>">
                                                <span style="width:6px; height:6px; border-radius:50%; background:currentColor;"></span>
                                                <?= htmlspecialchars($status_str) ?>
                                            </span>
                                            
                                            <span style="font-size: 0.68rem; color: var(--text-muted); text-transform: uppercase;">
                                                <?= htmlspecialchars($app['source_type']) ?> origin
                                            </span>
                                        </div>
                                        
                                        <h3 class="program-title" style="font-size: 1.15rem; font-weight:700; margin-bottom: 6px; color:#fff; line-height:1.4;">
                                            <?= htmlspecialchars($app['program_name']) ?>
                                        </h3>
                                        
                                        <p class="program-university" style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 12px; font-weight:500;">
                                            🏢 <?= htmlspecialchars($app['university_name']) ?>
                                        </p>
                                        
                                        <!-- Counselor details -->
                                        <div class="counselor-info">
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                            <span>
                                                Counselor: <strong><?= $app['counselor_name'] ? htmlspecialchars($app['counselor_name']) : 'Assigning...' ?></strong>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <div class="program-footer" style="padding-top: 16px; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; margin-top:20px;">
                                        <div>
                                            <span class="deadline-label" style="font-size: 0.72rem; color: var(--text-muted); display:block;">Applied On</span>
                                            <span class="deadline-date" style="font-size: 0.8rem; color: var(--text-primary); font-weight:600;"><?= date('M d, Y', strtotime($app['applied_at'])) ?></span>
                                        </div>
                                        <a href="application-details.php?id=<?= $app['id'] ?>" class="btn-details" style="padding: 10px 20px; border-radius: var(--radius-sm); background: rgba(108, 63, 255, 0.12); color: #c4b5fd; text-decoration: none; font-size: 0.8rem; font-weight: 600; transition: all 0.25s;">Track Journey →</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </main>
        <!-- ========== FOOTER ========== -->
        <?php require_once 'includes/footer.php'; ?>
    </div>
</div>

</body>
</html>
