<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config/database.php';

$error = '';
$success = false;

// 1. Detect application source and pre-fill relevant data
$source = trim($_GET['source'] ?? 'direct');
$source_id = intval($_GET['id'] ?? 0);

$prefilled_university = '';
$prefilled_program = '';
$prefilled_scholarship_id = null;
$source_meta = null; // To display visual preview of the origin card

// Fetch active partner universities for dynamic dropdowns
$universities = [];
try {
    $universities = $pdo->query("SELECT id, university_name, country FROM university_contacts ORDER BY university_name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Silently fall back to manual entry
}

if ($source_id > 0) {
    if ($source === 'program') {
        $stmt = $pdo->prepare("SELECT * FROM programs WHERE id = ?");
        $stmt->execute([$source_id]);
        $prog = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($prog) {
            $prefilled_university = $prog['university'];
            $prefilled_program = $prog['name'];
            $source_meta = [
                'title' => $prog['name'] . ' at ' . $prog['university'],
                'icon' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5"/></svg>',
                'desc' => $prog['degree_level'] . ' Degree • ' . $prog['duration']
            ];
        }
    } elseif ($source === 'university') {
        $stmt = $pdo->prepare("SELECT * FROM university_contacts WHERE id = ?");
        $stmt->execute([$source_id]);
        $uni = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($uni) {
            $prefilled_university = $uni['university_name'];
            $prefilled_program = trim($_GET['program'] ?? '');
            $source_meta = [
                'title' => $uni['university_name'],
                'icon' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
                'desc' => 'Partner Institution • ' . $uni['country']
            ];
            
            // Fetch this university's dynamic active programs
            try {
                $prog_stmt = $pdo->prepare("SELECT name FROM programs WHERE university = ? AND status = 'active' ORDER BY name ASC");
                $prog_stmt->execute([$uni['university_name']]);
                $uni_programs = $prog_stmt->fetchAll(PDO::FETCH_COLUMN);
            } catch (PDOException $e) {}
        }
    } elseif ($source === 'scholarship') {
        $stmt = $pdo->prepare("SELECT * FROM scholarships WHERE id = ?");
        $stmt->execute([$source_id]);
        $sch = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($sch) {
            $prefilled_scholarship_id = $sch['id'];
            // Try to extract university if provider contains university name
            $prefilled_university = $sch['provider'];
            $source_meta = [
                'title' => $sch['title'],
                'icon' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>',
                'desc' => 'Award Amount: ' . ($sch['amount'] ?: 'Varies') . ' • Provider: ' . $sch['provider']
            ];
        }
    }
}

// 2. Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $university = trim($_POST['university_name'] ?? '');
    $program = trim($_POST['program_name'] ?? '');
    $statement = trim($_POST['statement'] ?? '');
    
    // Hidden inputs representing source mapping
    $post_source = trim($_POST['source'] ?? 'direct');
    $post_source_id = intval($_POST['source_id'] ?? 0);
    $post_scholarship_id = intval($_POST['scholarship_id'] ?? 0);
    if ($post_scholarship_id <= 0) $post_scholarship_id = null;

    if (empty($university) || empty($program)) {
        $error = 'Target University and Program of Interest are required.';
    } else {
        try {
            $pdo->beginTransaction();
            $userId = $_SESSION['user_id'];
            
            // Insert Application record
            $stmt = $pdo->prepare("
                INSERT INTO applications 
                (user_id, university_name, program_name, status, source_type, source_id, scholarship_id) 
                VALUES (?, ?, ?, 'New', ?, ?, ?)
            ");
            $stmt->execute([
                $userId, 
                $university, 
                $program, 
                $post_source, 
                $post_source_id ?: null, 
                $post_scholarship_id
            ]);
            $applicationId = $pdo->lastInsertId();
            
            // Insert status history entry
            $hist_stmt = $pdo->prepare("
                INSERT INTO status_history (application_id, old_status, new_status, changed_by, comments) 
                VALUES (?, NULL, 'New', ?, 'Initial application submitted successfully.')
            ");
            $hist_stmt->execute([$applicationId, $userId]);
            
            // Generate notification for student
            $notif_msg = "Your application for " . $program . " at " . $university . " has been submitted successfully (Status: New). Our counselor team will review it shortly.";
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
            $notif_stmt->execute([$userId, $notif_msg]);

            // Save Statement of Purpose if filled as an initial supporting document
            if (!empty($statement)) {
                if (!is_dir('uploads')) {
                    mkdir('uploads', 0777, true);
                }
                $sop_filename = 'sop_' . $applicationId . '_' . time() . '.txt';
                $sop_path = 'uploads/' . $sop_filename;
                file_put_contents($sop_path, "STATEMENT OF PURPOSE:\n\n" . $statement);
                
                $sop_stmt = $pdo->prepare("INSERT INTO documents (application_id, name, file_path, status) VALUES (?, 'Statement of Purpose', ?, 'under_review')");
                $sop_stmt->execute([$applicationId, $sop_path]);
            }

            // Handle Supporting Documents uploads
            if (!empty($_FILES['documents']['name'][0])) {
                if (!is_dir('uploads')) {
                    mkdir('uploads', 0777, true);
                }
                
                foreach ($_FILES['documents']['name'] as $key => $orig_name) {
                    if ($_FILES['documents']['error'][$key] === UPLOAD_ERR_OK) {
                        $tmpName = $_FILES['documents']['tmp_name'][$key];
                        $clean_name = preg_replace("/[^a-zA-Z0-9\._-]/", "_", $orig_name);
                        $fileName = 'app_' . $applicationId . '_' . time() . '_' . $clean_name;
                        $destPath = 'uploads/' . $fileName;
                        
                        if (move_uploaded_file($tmpName, $destPath)) {
                            $doc_stmt = $pdo->prepare("INSERT INTO documents (application_id, name, file_path, status) VALUES (?, ?, ?, 'under_review')");
                            $doc_stmt->execute([$applicationId, $orig_name, $destPath]);
                        }
                    }
                }
            }

            $pdo->commit();
            $success = true;
            
            // Redirect to applications tracking list with success message
            header('Location: applications.php?status=submitted');
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'An error occurred while submitting your application: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Start Study Abroad Application - Abrovia</title>
    <link rel="stylesheet" href="assets/css/application-form.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .source-badge {
            background: rgba(108, 63, 255, 0.15);
            border: 1px solid var(--border-focus);
            border-radius: var(--radius-sm);
            padding: 18px 24px;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 4px 20px rgba(108, 63, 255, 0.1);
        }
        .source-badge-icon {
            width: 44px;
            height: 44px;
            background: var(--accent);
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            flex-shrink: 0;
            box-shadow: 0 0 15px var(--accent-glow);
        }
        .source-badge-title {
            font-size: 1rem;
            font-weight: 600;
            color: #ffffff;
            margin-bottom: 2px;
        }
        .source-badge-desc {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }
        .prefilled-lock-banner {
            font-size: 0.75rem;
            color: var(--green);
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.2);
            padding: 4px 8px;
            border-radius: 4px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-top: 6px;
        }
    </style>
</head>
<body>

    <!-- ========== NAVBAR ========== -->
    <?php require_once 'includes/header.php'; ?>

    <!-- MAIN CONTENT -->
    <main class="page-content">
        <div class="content-container">
            
            <a href="applications.php" class="back-link">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to My Applications
            </a>

            <div class="page-header">
                <h1 class="page-title">Unified Application</h1>
                <p class="page-subtitle">Your credentials, academic details, and documents are securely processed into one simple application dashboard.</p>
            </div>

            <?php if ($error): ?>
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #ef4444; padding: 12px 16px; border-radius: 8px; margin-bottom: 24px; font-size: 0.9rem;">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <!-- Origin Source Summary Badge -->
            <?php if ($source_meta): ?>
                <div class="source-badge">
                    <div class="source-badge-icon">
                        <?= $source_meta['icon'] ?>
                    </div>
                    <div>
                        <div style="font-size: 0.68rem; color: var(--text-muted); text-transform: uppercase; font-weight: 700; letter-spacing: 1px;">Detected Source: <?= ucfirst($source) ?></div>
                        <h4 class="source-badge-title"><?= htmlspecialchars($source_meta['title']) ?></h4>
                        <p class="source-badge-desc"><?= htmlspecialchars($source_meta['desc']) ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="application-form-card">
                <form action="application-form.php?source=<?= htmlspecialchars($source) ?>&id=<?= $source_id ?>" method="POST" enctype="multipart/form-data">
                    
                    <!-- Hidden mapping parameters for SQL preservation -->
                    <input type="hidden" name="source" value="<?= htmlspecialchars($source) ?>">
                    <input type="hidden" name="source_id" value="<?= $source_id ?>">
                    <input type="hidden" name="scholarship_id" value="<?= $prefilled_scholarship_id ?>">

                    <div class="form-group">
                        <label class="form-label" for="university_name">Target University</label>
                        <?php if ($source === 'program' && !empty($prefilled_university)): ?>
                            <input type="text" class="form-input" id="university_name_locked" value="<?= htmlspecialchars($prefilled_university) ?>" readonly style="opacity: 0.75; cursor: not-allowed; background: rgba(255,255,255,0.02);">
                            <input type="hidden" name="university_name" value="<?= htmlspecialchars($prefilled_university) ?>">
                            <span class="prefilled-lock-banner">✓ Automatically pre-filled & locked based on selected program</span>
                        <?php elseif ($source === 'university' && !empty($prefilled_university)): ?>
                            <input type="text" class="form-input" id="university_name_locked" value="<?= htmlspecialchars($prefilled_university) ?>" readonly style="opacity: 0.75; cursor: not-allowed; background: rgba(255,255,255,0.02);">
                            <input type="hidden" name="university_name" value="<?= htmlspecialchars($prefilled_university) ?>">
                            <span class="prefilled-lock-banner">✓ Automatically pre-filled & locked based on selected university</span>
                        <?php else: ?>
                            <select class="form-select" id="university_name" name="university_name" required>
                                <option value="">Select a University...</option>
                                <?php if (!empty($universities)): ?>
                                    <?php foreach ($universities as $uni): ?>
                                        <option value="<?= htmlspecialchars($uni['university_name']) ?>" <?= strtolower($prefilled_university) === strtolower($uni['university_name']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($uni['university_name']) ?> (<?= htmlspecialchars($uni['country']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <!-- Dynamic Fallbacks -->
                                    <option value="Imperial College London" <?= $prefilled_university === 'Imperial College London' ? 'selected' : '' ?>>Imperial College London</option>
                                    <option value="University of Melbourne" <?= $prefilled_university === 'University of Melbourne' ? 'selected' : '' ?>>University of Melbourne</option>
                                    <option value="Technical University of Munich" <?= $prefilled_university === 'Technical University of Munich' ? 'selected' : '' ?>>Technical University of Munich</option>
                                    <option value="University of Toronto" <?= $prefilled_university === 'University of Toronto' ? 'selected' : '' ?>>University of Toronto</option>
                                    <option value="Stanford University" <?= $prefilled_university === 'Stanford University' ? 'selected' : '' ?>>Stanford University</option>
                                <?php endif; ?>
                            </select>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="program_name">Program of Interest</label>
                        <?php if ($source === 'program' && !empty($prefilled_program)): ?>
                            <input type="text" class="form-input" id="program_name_locked" value="<?= htmlspecialchars($prefilled_program) ?>" readonly style="opacity: 0.75; cursor: not-allowed; background: rgba(255,255,255,0.02);">
                            <input type="hidden" name="program_name" value="<?= htmlspecialchars($prefilled_program) ?>">
                            <span class="prefilled-lock-banner">✓ Automatically pre-filled & locked based on selected program</span>
                        <?php elseif ($source === 'university' && !empty($uni_programs)): ?>
                            <select class="form-select" id="program_name" name="program_name" required>
                                <option value="">Choose one of our available programs...</option>
                                <?php foreach ($uni_programs as $name): ?>
                                    <option value="<?= htmlspecialchars($name) ?>"><?= htmlspecialchars($name) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <input type="text" class="form-input" id="program_name" name="program_name" placeholder="e.g., MSc Data Science & AI" value="<?= htmlspecialchars($prefilled_program) ?>" required>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="statement">Statement of Purpose (SOP)</label>
                        <textarea class="form-textarea" id="statement" name="statement" placeholder="Write or paste your Statement of Purpose (SOP) here to submit it as a supporting credential..."></textarea>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Supporting Credentials & Transcripts (PDF, DOCX, JPG)</label>
                        <div class="file-upload-wrapper" onclick="document.getElementById('file-upload-el').click();">
                            <input type="file" id="file-upload-el" class="file-upload-input" name="documents[]" multiple onchange="updateFileLabels(this)">
                            <svg class="file-upload-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                            <p class="file-upload-text" id="upload-label">Drag & drop files or <span>Browse</span></p>
                            <p style="font-size: 0.75rem; color: var(--text-muted); margin-top: 6px;">Please upload Academic transcripts, CV, IELTS/TOEFL scores, or Passport copy (Max 10MB per file)</p>
                        </div>
                        <div id="file-list-preview" style="margin-top: 12px; display: flex; flex-direction: column; gap: 6px;"></div>
                    </div>

                    <div class="form-actions">
                        <a href="applications.php" class="btn-cancel" style="display:inline-block; text-align:center;">Cancel</a>
                        <button type="submit" class="btn-submit">Submit Application</button>
                    </div>

                </form>
            </div>

        </div>
    </main>

    <!-- ========== FOOTER ========== -->
    <?php require_once 'includes/footer.php'; ?>

    <script>
    function updateFileLabels(input) {
        const fileListEl = document.getElementById('file-list-preview');
        const uploadLabel = document.getElementById('upload-label');
        fileListEl.innerHTML = '';
        
        if (input.files.length > 0) {
            uploadLabel.innerHTML = `Selected <span>${input.files.length} file(s)</span>. Click to change.`;
            for (let i = 0; i < input.files.length; i++) {
                const file = input.files[i];
                const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
                
                const item = document.createElement('div');
                item.style.background = 'rgba(255, 255, 255, 0.03)';
                item.style.border = '1px solid var(--border)';
                item.style.borderRadius = 'var(--radius-sm)';
                item.style.padding = '8px 12px';
                item.style.fontSize = '0.85rem';
                item.style.display = 'flex';
                item.style.justifyContent = 'space-between';
                item.style.alignItems = 'center';
                item.innerHTML = `
                    <span style="color: var(--text-primary); font-weight: 500;">📄 ${file.name}</span>
                    <span style="color: var(--text-muted); font-size: 0.75rem;">${sizeMB} MB</span>
                `;
                fileListEl.appendChild(item);
            }
        } else {
            uploadLabel.innerHTML = "Drag & drop files or <span>Browse</span>";
        }
    }
    </script>
</body>
</html>
