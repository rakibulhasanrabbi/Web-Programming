<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config/database.php';

// Check premium status
$isPremium = false;
try {
    $stmt = $pdo->prepare("SELECT is_premium FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $isPremium = (bool) $stmt->fetchColumn();
} catch (Exception $e) {
    // Column may not exist yet
}

// Schema initialization (runs on-demand, self-healing)
try {
    // Check if is_premium column exists in users table
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'is_premium'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE users ADD COLUMN is_premium TINYINT(1) DEFAULT 0");
    }

    // Check if user_profiles table exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_profiles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL UNIQUE,
        cgpa DECIMAL(3,2) DEFAULT NULL,
        ielts DECIMAL(2,1) DEFAULT NULL,
        skills TEXT DEFAULT NULL,
        experience INT DEFAULT 0,
        target_country VARCHAR(100) DEFAULT NULL,
        field_of_study VARCHAR(255) DEFAULT NULL,
        financial_budget VARCHAR(50) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
} catch (Exception $e) {
    // Log or handle schema migration error silently
}

// Handle AJAX Save Profile POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_profile') {
    header('Content-Type: application/json');
    $cgpa = floatval($_POST['cgpa'] ?? 0.0);
    $ielts = floatval($_POST['ielts'] ?? 0.0);
    $skills = trim($_POST['skills'] ?? '');
    $experience = intval($_POST['experience'] ?? 0);
    $target_country = trim($_POST['target_country'] ?? '');
    $field_of_study = trim($_POST['field_of_study'] ?? '');
    $financial_budget = trim($_POST['financial_budget'] ?? '');
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO user_profiles (user_id, cgpa, ielts, skills, experience, target_country, field_of_study, financial_budget)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                cgpa = VALUES(cgpa),
                ielts = VALUES(ielts),
                skills = VALUES(skills),
                experience = VALUES(experience),
                target_country = VALUES(target_country),
                field_of_study = VALUES(field_of_study),
                financial_budget = VALUES(financial_budget)
        ");
        $stmt->execute([$_SESSION['user_id'], $cgpa, $ielts, $skills, $experience, $target_country, $field_of_study, $financial_budget]);
        echo json_encode(['success' => true, 'message' => 'Profile saved successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// Fetch user profile if it exists
$profile = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $profile = $stmt->fetch();
} catch (Exception $e) {
    // Profile doesn't exist or table error
}

// Fallback defaults
if (!$profile) {
    $profile = [
        'cgpa' => 3.50,
        'ielts' => 7.0,
        'skills' => 'Python, SQL, Research Writing',
        'experience' => 1,
        'target_country' => 'USA',
        'field_of_study' => 'Computer Science',
        'financial_budget' => 'Partial scholarship needed'
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Profile Evaluation - Abrovia</title>
    <link rel="stylesheet" href="assets/css/dashboard.css">
    <link rel="stylesheet" href="assets/css/ai-evaluation.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="dashboard-layout">
    <!-- ========== NAVBAR ========== -->
    <?php require_once 'includes/header.php'; ?>

    <!-- SIDEBAR -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-top">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item" id="nav-dashboard">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                    Dashboard</a>
                <a href="applications.php" class="nav-item" id="nav-applications">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                    Applications</a>
                <a href="saved.php" class="nav-item" id="nav-saved">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
                    Saved
                </a>
                <a href="ai-evaluation.php" class="nav-item active" id="nav-ai-evaluation">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    AI Evaluation
                </a>
                <a href="profile.php" class="nav-item" id="nav-profile">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    Profile
                </a>
            </nav>
        </div>
        <div class="sidebar-bottom">
            <a href="auth/logout.php" class="nav-item logout-link" style="margin-top: 10px; display: flex; align-items: center; gap: 10px; color: #94a3b8; text-decoration: none; font-size: 14px; padding: 10px; border-radius: 8px; transition: all 0.3s ease;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
            <a href="application-form.php" class="btn-new-app" id="btn-new-application">Start New Application</a>
        </div>
    </aside>

    <!-- MAIN AREA -->
    <div class="main-area">
        <main class="main-content" id="main-content">
            <div class="eval-container">

                <!-- PAGE HEADER with Premium Button -->
                <header class="eval-header">
                    <div class="eval-header-left">
                        <h1 class="eval-title">AI Profile Evaluation</h1>
                        <p class="eval-subtitle">Real-time evaluation engine powered by advanced scholarship and admission vectors.</p>
                    </div>
                    <div class="eval-header-right">
                        <?php if ($isPremium): ?>
                            <div class="premium-active-badge">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                Premium Active
                            </div>
                        <?php else: ?>
                            <button class="btn-upgrade-top" id="btnUpgradeTop" onclick="openUpgradeModal()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                Upgrade to Premium
                            </button>
                        <?php endif; ?>
                    </div>
                </header>

                <!-- AI STATUS BAR -->
                <div class="ai-status-bar">
                    <div class="ai-status-left">
                        <div class="ai-dot"></div>
                        <div class="ai-status-text">AI Evaluation Engine is <strong>ready to scan</strong></div>
                    </div>
                    <div class="ai-status-right">
                        <span class="model-badge">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                            AbroviaAI-v4.5
                        </span>
                    </div>
                </div>

                <!-- WORKSPACE LAYOUT -->
                <div class="eval-workspace">
                    
                    <!-- LEFT COLUMN: Profile Analyzer Form -->
                    <aside class="eval-form-sidebar">
                        <div class="eval-form-card">
                            <div class="form-card-header">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
                                <h3>Profile Analyzer</h3>
                            </div>
                            <form id="profileEvalForm">
                                <!-- CGPA -->
                                <div class="form-group">
                                    <div class="label-row">
                                        <label for="input_cgpa">CGPA (4.0 Scale)</label>
                                        <span class="val-display" id="cgpa_val"><?php echo number_format($profile['cgpa'], 2); ?></span>
                                    </div>
                                    <div class="input-range-wrap">
                                        <input type="range" id="input_cgpa" name="cgpa" min="2.00" max="4.00" step="0.01" value="<?php echo htmlspecialchars($profile['cgpa']); ?>">
                                    </div>
                                </div>

                                <!-- English Proficiency -->
                                <div class="form-group">
                                    <div class="label-row">
                                        <label for="input_ielts">IELTS Band Score</label>
                                        <span class="val-display" id="ielts_val"><?php echo number_format($profile['ielts'], 1); ?></span>
                                    </div>
                                    <div class="input-range-wrap">
                                        <input type="range" id="input_ielts" name="ielts" min="4.0" max="9.0" step="0.5" value="<?php echo htmlspecialchars($profile['ielts']); ?>">
                                    </div>
                                </div>

                                <!-- Target Country -->
                                <div class="form-group">
                                    <label for="input_country">Target Country</label>
                                    <select id="input_country" name="target_country" class="form-select">
                                        <option value="USA" <?php echo $profile['target_country'] === 'USA' ? 'selected' : ''; ?>>🇺🇸 United States</option>
                                        <option value="Canada" <?php echo $profile['target_country'] === 'Canada' ? 'selected' : ''; ?>>🇨🇦 Canada</option>
                                        <option value="UK" <?php echo $profile['target_country'] === 'UK' ? 'selected' : ''; ?>>🇬🇧 United Kingdom</option>
                                        <option value="Australia" <?php echo $profile['target_country'] === 'Australia' ? 'selected' : ''; ?>>🇦🇺 Australia</option>
                                        <option value="Germany" <?php echo $profile['target_country'] === 'Germany' ? 'selected' : ''; ?>>🇩🇪 Germany</option>
                                    </select>
                                </div>

                                <!-- Field of Study -->
                                <div class="form-group">
                                    <label for="input_field">Field of Study</label>
                                    <select id="input_field" name="field_of_study" class="form-select">
                                        <option value="Computer Science" <?php echo $profile['field_of_study'] === 'Computer Science' ? 'selected' : ''; ?>>Computer Science & IT</option>
                                        <option value="Business" <?php echo $profile['field_of_study'] === 'Business' ? 'selected' : ''; ?>>Business & Management</option>
                                        <option value="Engineering" <?php echo $profile['field_of_study'] === 'Engineering' ? 'selected' : ''; ?>>Engineering (Other)</option>
                                        <option value="Social Sciences" <?php echo $profile['field_of_study'] === 'Social Sciences' ? 'selected' : ''; ?>>Social Sciences & Arts</option>
                                        <option value="Health Sciences" <?php echo $profile['field_of_study'] === 'Health Sciences' ? 'selected' : ''; ?>>Medicine & Health Sciences</option>
                                    </select>
                                </div>

                                <!-- Experience -->
                                <div class="form-group">
                                    <div class="label-row">
                                        <label for="input_experience">Research/Work Exp</label>
                                        <span class="val-display" id="experience_val"><?php echo $profile['experience']; ?> Years</span>
                                    </div>
                                    <div class="input-range-wrap">
                                        <input type="range" id="input_experience" name="experience" min="0" max="10" step="1" value="<?php echo htmlspecialchars($profile['experience']); ?>">
                                    </div>
                                </div>

                                <!-- Budget -->
                                <div class="form-group">
                                    <label for="input_budget">Financial Budget Plan</label>
                                    <select id="input_budget" name="financial_budget" class="form-select">
                                        <option value="Full scholarship needed" <?php echo $profile['financial_budget'] === 'Full scholarship needed' ? 'selected' : ''; ?>>Full Scholarship Needed</option>
                                        <option value="Partial scholarship needed" <?php echo $profile['financial_budget'] === 'Partial scholarship needed' ? 'selected' : ''; ?>>Partial Scholarship / Mid-Budget</option>
                                        <option value="Self-funded" <?php echo $profile['financial_budget'] === 'Self-funded' ? 'selected' : ''; ?>>Self-funded / High-Budget</option>
                                    </select>
                                </div>

                                <!-- Skills -->
                                <div class="form-group">
                                    <label for="input_skills">Technical & Professional Skills</label>
                                    <input type="text" id="input_skills" name="skills" class="form-input" placeholder="e.g. Python, SQL, Research" value="<?php echo htmlspecialchars($profile['skills']); ?>">
                                    
                                    <div class="quick-tags-label">Quick Add Skills:</div>
                                    <div class="quick-skills-tags">
                                        <span class="skill-tag-btn" data-skill="Python">Python</span>
                                        <span class="skill-tag-btn" data-skill="Machine Learning">ML</span>
                                        <span class="skill-tag-btn" data-skill="SQL">SQL</span>
                                        <span class="skill-tag-btn" data-skill="Research Writing">Research</span>
                                        <span class="skill-tag-btn" data-skill="Public Speaking">Public Speaking</span>
                                        <span class="skill-tag-btn" data-skill="Leadership">Leadership</span>
                                        <span class="skill-tag-btn" data-skill="Project Management">Mgmt</span>
                                        <span class="skill-tag-btn" data-skill="Java">Java</span>
                                    </div>
                                </div>

                                <button type="button" class="btn-run-eval" id="btnRunEval">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                    Evaluate Profile
                                </button>
                            </form>
                        </div>
                    </aside>

                    <!-- RIGHT COLUMN: Dashboard Results -->
                    <div class="eval-results-dashboard">
                        
                        <!-- QUICK STATS BAR -->
                        <div class="stats-bar">
                            <div class="stat-item">
                                <div class="stat-icon-wrap purple">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
                                </div>
                                <div class="stat-info">
                                    <span class="stat-label">GPA</span>
                                    <span class="stat-value" id="stat_gpa">0.0<span class="muted">/4.0</span></span>
                                </div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-icon-wrap blue">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>
                                </div>
                                <div class="stat-info">
                                    <span class="stat-label">IELTS</span>
                                    <span class="stat-value" id="stat_ielts">0.0</span>
                                </div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-icon-wrap green">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
                                </div>
                                <div class="stat-info">
                                    <span class="stat-label">SKILLS</span>
                                    <span class="stat-value truncate" id="stat_skills">-</span>
                                </div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-icon-wrap yellow">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
                                </div>
                                <div class="stat-info">
                                    <span class="stat-label">EXPERIENCE</span>
                                    <span class="stat-value" id="stat_experience">0 Years</span>
                                </div>
                            </div>
                        </div>

                        <!-- EVALUATION GRID (Free Sections) -->
                        <div class="eval-main-grid">
                            
                            <!-- Profile Strength Circular Gauge -->
                            <div class="eval-card gauge-card">
                                <p class="card-label-top">Profile Strength</p>
                                <div class="gauge-wrap">
                                    <svg class="gauge-svg" viewBox="0 0 100 100">
                                        <circle class="gauge-bg" cx="50" cy="50" r="40"></circle>
                                        <circle class="gauge-value" id="strengthGauge" cx="50" cy="50" r="40" style="stroke-dashoffset: 251.2;"></circle>
                                    </svg>
                                    <div class="gauge-text">
                                        <span class="gauge-number" id="strengthNumber">0</span>
                                        <span class="gauge-percent">%</span>
                                    </div>
                                </div>
                                <p class="gauge-desc" id="strengthDesc">Evaluating profile...</p>
                            </div>

                            <!-- Key Strengths -->
                            <div class="eval-card list-card">
                                <div class="card-header-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                                    <h3 class="eval-card-title">Key Strengths</h3>
                                </div>
                                <div class="eval-items" id="keyStrengthsContainer">
                                    <!-- Dynamic content -->
                                </div>
                            </div>

                            <!-- Areas for Growth -->
                            <div class="eval-card list-card">
                                <div class="card-header-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                                    <h3 class="eval-card-title">Areas for Growth</h3>
                                </div>
                                <div class="eval-items" id="growthAreasContainer">
                                    <!-- Dynamic content -->
                                </div>
                            </div>
                        </div>

                        <!-- AI TAILORED ADVICE -->
                        <div class="advice-section-wrap">
                            <h2 class="section-title">AI Tailored Advice</h2>
                            <div class="advice-grid" id="adviceContainer">
                                <!-- Dynamic content -->
                            </div>
                        </div>

                        <!-- PREMIUM EVALUATION BLOCKS -->
                        <div id="premiumEvaluationContent">
                            
                            <!-- ADMISSION PREDICTIONS -->
                            <div class="premium-eval-block <?php echo !$isPremium ? 'blurred-block' : ''; ?>">
                                <div class="section-header-row">
                                    <h2 class="section-title">University Admission Predictions</h2>
                                    <?php if ($isPremium): ?>
                                        <span class="premium-tag"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> Premium</span>
                                    <?php endif; ?>
                                </div>
                                <div class="predictions-grid" id="predictionsContainer">
                                    <!-- Dynamic content -->
                                </div>
                                
                                <?php if (!$isPremium): ?>
                                    <div class="lock-overlay">
                                        <div class="lock-icon">🔒</div>
                                        <h4>Detailed University Predictions</h4>
                                        <p>Acceptance chances for top institutions calculated based on academic standings.</p>
                                        <button class="btn-unlock-small" onclick="openUpgradeModal()">Unlock with Premium</button>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- VISA READINESS ANALYSIS -->
                            <div class="premium-eval-block <?php echo !$isPremium ? 'blurred-block' : ''; ?>">
                                <div class="section-header-row">
                                    <h2 class="section-title">Visa Readiness Analysis</h2>
                                    <?php if ($isPremium): ?>
                                        <span class="premium-tag"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> Premium</span>
                                    <?php endif; ?>
                                </div>
                                <div class="visa-readiness-grid" id="visaReadinessContainer">
                                    <!-- Dynamic content -->
                                </div>
                                
                                <?php if (!$isPremium): ?>
                                    <div class="lock-overlay">
                                        <div class="lock-icon">🔒</div>
                                        <h4>Visa Approval & Rejection Probability</h4>
                                        <p>Embassy rejection risk assessments and documentation completeness scoring.</p>
                                        <button class="btn-unlock-small" onclick="openUpgradeModal()">Unlock with Premium</button>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- SCHOLARSHIP MATCHING -->
                            <div class="premium-eval-block <?php echo !$isPremium ? 'blurred-block' : ''; ?>">
                                <div class="section-header-row">
                                    <h2 class="section-title">Scholarship Matching</h2>
                                    <?php if ($isPremium): ?>
                                        <span class="premium-tag"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> Premium</span>
                                    <?php endif; ?>
                                </div>
                                <div class="scholarship-grid" id="scholarshipsContainer">
                                    <!-- Dynamic content -->
                                </div>
                                
                                <?php if (!$isPremium): ?>
                                    <div class="lock-overlay">
                                        <div class="lock-icon">🔒</div>
                                        <h4>Personalized Scholarship Matches</h4>
                                        <p>Ranked scholarship opportunities with eligibility match ratings.</p>
                                        <button class="btn-unlock-small" onclick="openUpgradeModal()">Unlock with Premium</button>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- PROFILE IMPROVEMENT ROADMAP -->
                            <div class="premium-eval-block <?php echo !$isPremium ? 'blurred-block' : ''; ?>">
                                <div class="section-header-row">
                                    <h2 class="section-title">Profile Improvement Roadmap</h2>
                                    <?php if ($isPremium): ?>
                                        <span class="premium-tag"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> Premium</span>
                                    <?php endif; ?>
                                </div>
                                <div class="roadmap-timeline" id="roadmapContainer">
                                    <!-- Dynamic content -->
                                </div>
                                
                                <?php if (!$isPremium): ?>
                                    <div class="lock-overlay">
                                        <div class="lock-icon">🔒</div>
                                        <h4>Tailored Timeline Roadmap</h4>
                                        <p>Step-by-step month-by-month planning to boost your admission probabilities.</p>
                                        <button class="btn-unlock-small" onclick="openUpgradeModal()">Unlock with Premium</button>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <!-- PRIORITY AI EXECUTIVE REPORT -->
                            <div class="premium-eval-block <?php echo !$isPremium ? 'blurred-block' : ''; ?>">
                                <div class="section-header-row">
                                    <h2 class="section-title">Priority AI Executive Report</h2>
                                    <?php if ($isPremium): ?>
                                        <span class="premium-tag"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> Premium</span>
                                    <?php endif; ?>
                                </div>
                                <div class="priority-report-card">
                                    <div class="report-summary-row" id="reportMetricsContainer">
                                        <!-- Dynamic content -->
                                    </div>
                                    <div class="report-narrative" id="reportNarrativeContainer">
                                        <!-- Dynamic content -->
                                    </div>
                                </div>
                                
                                <?php if (!$isPremium): ?>
                                    <div class="lock-overlay">
                                        <div class="lock-icon">🔒</div>
                                        <h4>Priority AI Executive Assessment</h4>
                                        <p>Full executive overview showing global applicant percentile rankings.</p>
                                        <button class="btn-unlock-small" onclick="openUpgradeModal()">Unlock with Premium</button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                        </div>

                        <!-- PREMIUM GATE (Free Only, Large Banner) -->
                        <?php if (!$isPremium): ?>
                            <section class="premium-gate-section" style="margin-top: 20px;">
                                <div class="premium-gate-card">
                                    <div class="gate-glow"></div>
                                    <div class="gate-icon">
                                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                    </div>
                                    <h2 class="gate-title">Unlock Full AI Profile Evaluation</h2>
                                    <p class="gate-desc">Gain lifetime access to detailed admission chances, specific visa reject risks, customized timelines, and priority AI reports.</p>
                                    <button class="btn-upgrade-gate" onclick="openUpgradeModal()">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                        Upgrade to Premium Now
                                    </button>
                                    <p class="gate-note">Demo mode — no real payment will be charged.</p>
                                </div>
                            </section>
                        <?php endif; ?>

                    </div>
                </div>

            </div>
        </main>
        <!-- ========== FOOTER ========== -->
        <?php require_once 'includes/footer.php'; ?>
    </div>
</div>

<!-- ORBITAL SCANNER MODAL -->
<div class="ai-modal-overlay" id="aiModalOverlay">
    <div class="ai-modal">
        <div class="ai-thinking">
            <div class="thinking-orb">
                <div class="orb-ring orb-ring-1"></div>
                <div class="orb-ring orb-ring-2"></div>
                <div class="orb-ring orb-ring-3"></div>
                <div class="orb-core"></div>
            </div>
            <h3 class="thinking-text" id="thinkingText">Initializing Evaluation...</h3>
            <p class="thinking-subtext" id="thinkingSubtext">Connecting to Abrovia Admission model...</p>
        </div>
        <div class="ai-progress" id="aiProgressList">
            <div class="progress-step" id="step_1">
                <div class="step-indicator"></div>
                <div class="step-text">Parsing academic records</div>
            </div>
            <div class="progress-step" id="step_2">
                <div class="step-indicator"></div>
                <div class="step-text">Evaluating language proficiency</div>
            </div>
            <div class="progress-step" id="step_3">
                <div class="step-indicator"></div>
                <div class="step-text">Simulating immigration & visa solvency</div>
            </div>
            <div class="progress-step" id="step_4">
                <div class="step-indicator"></div>
                <div class="step-text">Scanning university acceptance indexes</div>
            </div>
            <div class="progress-step" id="step_5">
                <div class="step-indicator"></div>
                <div class="step-text">Finalizing custom roadmap recommendations</div>
            </div>
        </div>
    </div>
</div>

<!-- UPGRADE MODAL -->
<div class="upgrade-overlay" id="upgradeOverlay">
    <div class="upgrade-modal">
        <button class="modal-close" onclick="closeUpgradeModal()">&times;</button>
        <div class="upgrade-modal-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        </div>
        <h2 class="upgrade-title">Unlock Premium Evaluation</h2>
        <p class="upgrade-desc">Get detailed university admission chances, embassy visa risk reports, and scholarship match scores.</p>
        <div class="upgrade-price-row">
            <span class="upgrade-price">৳2,500</span>
            <span class="upgrade-period">/ lifetime access</span>
        </div>
        <button class="btn-confirm-upgrade" id="btnConfirmUpgrade">
            <span id="upgradeText">Activate Premium Now</span>
        </button>
        <p class="upgrade-note">Demo mode — no real charges.</p>
    </div>
</div>

<script>
// Toggle elements
const rangeCgpa = document.getElementById('input_cgpa');
const valCgpa = document.getElementById('cgpa_val');
const rangeIelts = document.getElementById('input_ielts');
const valIelts = document.getElementById('ielts_val');
const rangeExp = document.getElementById('input_experience');
const valExp = document.getElementById('experience_val');
const skillsInput = document.getElementById('input_skills');

// Sync inputs
rangeCgpa.addEventListener('input', (e) => {
    valCgpa.innerText = parseFloat(e.target.value).toFixed(2);
});
rangeIelts.addEventListener('input', (e) => {
    valIelts.innerText = parseFloat(e.target.value).toFixed(1);
});
rangeExp.addEventListener('input', (e) => {
    valExp.innerText = e.target.value + (e.target.value === '1' ? ' Year' : ' Years');
});

// Quick Skills tag click
const skillTags = document.querySelectorAll('.skill-tag-btn');
skillTags.forEach(tag => {
    // Initialize active states based on input value
    const skillName = tag.getAttribute('data-skill');
    if (skillsInput.value.toLowerCase().includes(skillName.toLowerCase())) {
        tag.classList.add('active');
    }

    tag.addEventListener('click', () => {
        let currentSkills = skillsInput.value.split(',').map(s => s.trim()).filter(s => s !== "");
        const idx = currentSkills.findIndex(s => s.toLowerCase() === skillName.toLowerCase());
        
        if (idx > -1) {
            currentSkills.splice(idx, 1);
            tag.classList.remove('active');
        } else {
            currentSkills.push(skillName);
            tag.classList.add('active');
        }
        
        skillsInput.value = currentSkills.join(', ');
    });
});

// Watch direct text inputs on skills
skillsInput.addEventListener('input', (e) => {
    const val = e.target.value.toLowerCase();
    skillTags.forEach(tag => {
        const skillName = tag.getAttribute('data-skill').toLowerCase();
        if (val.includes(skillName)) {
            tag.classList.add('active');
        } else {
            tag.classList.remove('active');
        }
    });
});

// Evaluation logic
function calculateEvaluation(animate = true) {
    const cgpa = parseFloat(rangeCgpa.value);
    const ielts = parseFloat(rangeIelts.value);
    const country = document.getElementById('input_country').value;
    const field = document.getElementById('input_field').value;
    const exp = parseInt(rangeExp.value);
    const budget = document.getElementById('input_budget').value;
    const skills = skillsInput.value;
    const skillsArr = skills.split(',').map(s => s.trim()).filter(s => s !== "");

    // 1. Calculate Profile Score (25 to 100)
    let score = Math.round((cgpa / 4.0) * 45 + (ielts / 9.0) * 25 + Math.min(exp * 4, 18) + Math.min(skillsArr.length * 2.0, 12));
    
    // Budget adjustment for scholarship compatibility
    if (budget === 'Full scholarship needed') {
        if (cgpa < 3.5 || ielts < 6.5) {
            score -= 5;
        }
    }
    score = Math.max(25, Math.min(100, score));

    // Update circular gauge with count up
    const gauge = document.getElementById('strengthGauge');
    const scoreNumEl = document.getElementById('strengthNumber');
    const scoreDesc = document.getElementById('strengthDesc');

    // Radius = 40, Circumference = 2 * PI * 40 = 251.2
    const targetOffset = 251.2 - (251.2 * score) / 100;
    
    if (animate) {
        let currentNum = 0;
        const interval = setInterval(() => {
            if (currentNum >= score) {
                clearInterval(interval);
                scoreNumEl.innerText = score;
            } else {
                currentNum += 2;
                if (currentNum > score) currentNum = score;
                scoreNumEl.innerText = currentNum;
            }
        }, 15);
        gauge.style.strokeDashoffset = targetOffset;
    } else {
        scoreNumEl.innerText = score;
        gauge.style.strokeDashoffset = targetOffset;
    }

    // Set score description
    if (score >= 85) {
        scoreDesc.innerText = "Outstanding profile. Competitive for elite Ivy League or top 20 global institutions with scholarship potential.";
        gauge.style.stroke = "var(--emerald)";
    } else if (score >= 70) {
        scoreDesc.innerText = "Competitive profile. Very strong candidates for top 100 international colleges with partial funding options.";
        gauge.style.stroke = "var(--accent)";
    } else if (score >= 50) {
        scoreDesc.innerText = "Good baseline profile. Suitable for top 250 universities globally. Focus on standardized test improvements.";
        gauge.style.stroke = "var(--amber)";
    } else {
        scoreDesc.innerText = "Needs enhancement. Consider retaking language certifications and adding research or work tenure to qualify.";
        gauge.style.stroke = "var(--rose)";
    }

    // Sync Stats Bar
    document.getElementById('stat_gpa').innerHTML = `${cgpa.toFixed(2)}<span class="muted">/4.0</span>`;
    document.getElementById('stat_ielts').innerText = ielts.toFixed(1);
    document.getElementById('stat_experience').innerText = exp + (exp === 1 ? ' Year' : ' Years');
    
    let displaySkills = skillsArr.slice(0, 2).join(', ');
    if (skillsArr.length > 2) displaySkills += '...';
    document.getElementById('stat_skills').innerText = displaySkills || 'None';

    // 2. Strengths and Growth Areas
    const strengthsCont = document.getElementById('keyStrengthsContainer');
    const growthCont = document.getElementById('growthAreasContainer');
    strengthsCont.innerHTML = '';
    growthCont.innerHTML = '';

    // Push Strengths
    let strengthsCount = 0;
    if (cgpa >= 3.6) {
        strengthsCont.innerHTML += `
            <div class="eval-item-box success-bg">
                <div class="item-header">
                    <span class="check-circle">✓</span>
                    <h4 class="item-title">Excellent GPA Record</h4>
                </div>
                <p class="item-desc">A GPA of ${cgpa.toFixed(2)} demonstrates high academic rigor and discipline.</p>
            </div>
        `;
        strengthsCount++;
    }
    if (ielts >= 7.0) {
        strengthsCont.innerHTML += `
            <div class="eval-item-box success-bg">
                <div class="item-header">
                    <span class="check-circle">✓</span>
                    <h4 class="item-title">Elite Language Score</h4>
                </div>
                <p class="item-desc">Band ${ielts.toFixed(1)} exceeds average admissions prerequisites worldwide.</p>
            </div>
        `;
        strengthsCount++;
    }
    if (exp >= 2) {
        strengthsCont.innerHTML += `
            <div class="eval-item-box success-bg">
                <div class="item-header">
                    <span class="check-circle">✓</span>
                    <h4 class="item-title">Substantial Practical Tenure</h4>
                </div>
                <p class="item-desc">${exp} years of work/research exposure adds deep credibility to SOP statements.</p>
            </div>
        `;
        strengthsCount++;
    }
    if (skillsArr.length >= 3) {
        strengthsCont.innerHTML += `
            <div class="eval-item-box success-bg">
                <div class="item-header">
                    <span class="check-circle">✓</span>
                    <h4 class="item-title">Technical Skill Versatility</h4>
                </div>
                <p class="item-desc">Quantifiable skills like ${skillsArr.slice(0, 3).join(', ')} align with program outcomes.</p>
            </div>
        `;
        strengthsCount++;
    }
    if (strengthsCount === 0) {
        strengthsCont.innerHTML = `
            <div class="eval-item-box success-bg">
                <div class="item-header">
                    <span class="check-circle">✓</span>
                    <h4 class="item-title">Motivated Applicant Profile</h4>
                </div>
                <p class="item-desc">Your target program matches study goals in ${country}. Ready for counseling step.</p>
            </div>
        `;
    }

    // Push Growth Areas
    let growthCount = 0;
    if (cgpa < 3.4) {
        growthCont.innerHTML += `
            <div class="eval-item-box warning-bg">
                <div class="item-header">
                    <span class="info-circle">!</span>
                    <h4 class="item-title">GPA Threshold Offset</h4>
                </div>
                <p class="item-desc">CGPA of ${cgpa.toFixed(2)} is below some elite cutoffs. High GRE/GMAT can offset.</p>
            </div>
        `;
        growthCount++;
    }
    if (ielts < 7.5) {
        growthCont.innerHTML += `
            <div class="eval-item-box warning-bg">
                <div class="item-header">
                    <span class="info-circle">!</span>
                    <h4 class="item-title">IELTS Band Enhancement</h4>
                </div>
                <p class="item-desc">A band score of ${ielts.toFixed(1)} limits full scholarship selection. Aim for 7.5+.</p>
            </div>
        `;
        growthCount++;
    }
    if (exp < 2) {
        growthCont.innerHTML += `
            <div class="eval-item-box warning-bg">
                <div class="item-header">
                    <span class="info-circle">!</span>
                    <h4 class="item-title">Academic/Work Portfolio Gap</h4>
                </div>
                <p class="item-desc">Prior internship tenure is limited. Bolstering projects increases CV depth.</p>
            </div>
        `;
        growthCount++;
    }
    if (skillsArr.length < 3) {
        growthCont.innerHTML += `
            <div class="eval-item-box warning-bg">
                <div class="item-header">
                    <span class="info-circle">!</span>
                    <h4 class="item-title">Skill Set Quantification</h4>
                </div>
                <p class="item-desc">Add specialized certifications to prove core competencies to admissions committees.</p>
            </div>
        `;
        growthCount++;
    }
    if (growthCount === 0) {
        growthCont.innerHTML = `
            <div class="eval-item-box success-bg" style="background: rgba(34, 197, 94, 0.02); border-color: rgba(34,197,94,0.05);">
                <div class="item-header">
                    <span class="check-circle" style="background:#10b981;">✓</span>
                    <h4 class="item-title">No Major Profile Gaps</h4>
                </div>
                <p class="item-desc">Profile matches maximum requirements. Ready to file university applications.</p>
            </div>
        `;
    }

    // 3. AI Tailored Advice Cards
    const adviceCont = document.getElementById('adviceContainer');
    adviceCont.innerHTML = '';
    
    // Advice card 1 (Test Prep recommendation)
    if (ielts < 7.5) {
        adviceCont.innerHTML += `
            <div class="advice-card">
                <div class="advice-icon purple-light">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                </div>
                <h3 class="advice-title">Retake IELTS for 7.5+</h3>
                <p class="advice-desc">Reaching a 7.5 or 8.0 band opens key merit funding packages in ${country}.</p>
                <a href="test-prep.php" class="advice-link">View Prep Center →</a>
            </div>
        `;
    } else {
        adviceCont.innerHTML += `
            <div class="advice-card">
                <div class="advice-icon purple-light">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                </div>
                <h3 class="advice-title">Consider GRE Standardized Test</h3>
                <p class="advice-desc">A target GRE of 320+ complements your IELTS and secures elite admissions.</p>
                <a href="test-prep.php" class="advice-link">GRE Classes →</a>
            </div>
        `;
    }

    // Advice card 2 (Portfolio recommendation)
    if (exp < 2) {
        adviceCont.innerHTML += `
            <div class="advice-card">
                <div class="advice-icon blue-light">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21a9 9 0 0 0 9-9c0-1.49-.36-2.9-1-4.14M12 3a9 9 0 0 1 9 9"/><path d="M21 3L3 21"/></svg>
                </div>
                <h3 class="advice-title">Publish Conference Papers</h3>
                <p class="advice-desc">Work with a professor to draft a short workshop paper. It significantly impacts STEM applications.</p>
                <a href="visa-guide.php" class="advice-link">Guide Details →</a>
            </div>
        `;
    } else {
        adviceCont.innerHTML += `
            <div class="advice-card">
                <div class="advice-icon blue-light">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21a9 9 0 0 0 9-9c0-1.49-.36-2.9-1-4.14M12 3a9 9 0 0 1 9 9"/><path d="M21 3L3 21"/></svg>
                </div>
                <h3 class="advice-title">Highlight Leadership Roles</h3>
                <p class="advice-desc">Structure your SOP around how you directed teams during your ${exp} years of career experience.</p>
                <a href="visa-guide.php" class="advice-link">View Guidelines →</a>
            </div>
        `;
    }

    // Advice card 3 (Skills)
    adviceCont.innerHTML += `
        <div class="advice-card">
            <div class="advice-icon green-light">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>
            </div>
            <h3 class="advice-title">Acquire Certification</h3>
            <p class="advice-desc">Complete professional certifications in ${field}-related frameworks like SQL or Data Analytics.</p>
            <a href="test-prep.php" class="advice-link">Explore Courses →</a>
        </div>
    `;

    // 4. University Predictions (Premium check)
    const predictionsCont = document.getElementById('predictionsContainer');
    if (predictionsCont) {
        predictionsCont.innerHTML = '';
        let uniList = [];
        
        if (country === 'USA') {
            uniList = [
                { name: 'MIT (Massachusetts Institute of Technology)', reqGpa: 3.9, reqIelts: 7.5, tier: 'reach' },
                { name: 'Stanford University', reqGpa: 3.8, reqIelts: 7.5, tier: 'reach' },
                { name: 'New York University (NYU)', reqGpa: 3.2, reqIelts: 6.5, tier: 'target' },
                { name: 'San Jose State University (SJSU)', reqGpa: 2.8, reqIelts: 6.0, tier: 'safety' }
            ];
        } else if (country === 'Canada') {
            uniList = [
                { name: 'University of Toronto', reqGpa: 3.7, reqIelts: 7.5, tier: 'reach' },
                { name: 'University of British Columbia (UBC)', reqGpa: 3.6, reqIelts: 7.0, tier: 'reach' },
                { name: 'University of Waterloo', reqGpa: 3.3, reqIelts: 6.5, tier: 'target' },
                { name: 'York University', reqGpa: 2.8, reqIelts: 6.0, tier: 'safety' }
            ];
        } else if (country === 'UK') {
            uniList = [
                { name: 'University of Oxford', reqGpa: 3.8, reqIelts: 7.5, tier: 'reach' },
                { name: 'Imperial College London', reqGpa: 3.7, reqIelts: 7.0, tier: 'reach' },
                { name: 'University of Manchester', reqGpa: 3.2, reqIelts: 6.5, tier: 'target' },
                { name: 'Coventry University', reqGpa: 2.5, reqIelts: 6.0, tier: 'safety' }
            ];
        } else if (country === 'Australia') {
            uniList = [
                { name: 'University of Melbourne', reqGpa: 3.6, reqIelts: 7.0, tier: 'reach' },
                { name: 'Australian National University (ANU)', reqGpa: 3.5, reqIelts: 6.5, tier: 'reach' },
                { name: 'Monash University', reqGpa: 3.0, reqIelts: 6.5, tier: 'target' },
                { name: 'University of Wollongong', reqGpa: 2.5, reqIelts: 6.0, tier: 'safety' }
            ];
        } else { // Germany
            uniList = [
                { name: 'Technical University of Munich (TUM)', reqGpa: 3.5, reqIelts: 6.5, tier: 'reach' },
                { name: 'LMU Munich', reqGpa: 3.5, reqIelts: 6.5, tier: 'reach' },
                { name: 'RWTH Aachen University', reqGpa: 3.2, reqIelts: 6.0, tier: 'target' },
                { name: 'Berlin Institute of Technology', reqGpa: 2.8, reqIelts: 6.0, tier: 'safety' }
            ];
        }

        uniList.forEach(uni => {
            let uOdds = 0;
            if (uni.tier === 'reach') {
                uOdds = Math.round(score * 0.7 + (cgpa >= uni.reqGpa ? 15 : 0) + (ielts >= uni.reqIelts ? 10 : 0) - 15);
                uOdds = Math.max(15, Math.min(88, uOdds));
            } else if (uni.tier === 'target') {
                uOdds = Math.round(score * 0.85 + (cgpa >= uni.reqGpa ? 10 : 0));
                uOdds = Math.max(35, Math.min(94, uOdds));
            } else {
                uOdds = Math.round(score * 1.05 + 10);
                uOdds = Math.max(55, Math.min(98, uOdds));
            }

            let chanceClass = 'medium';
            if (uOdds >= 75) chanceClass = 'very-high';
            else if (uOdds >= 60) chanceClass = 'high';
            else if (uOdds >= 45) chanceClass = 'medium';
            else chanceClass = 'low';

            predictionsCont.innerHTML += `
                <div class="prediction-card">
                    <div class="pred-header">
                        <span class="pred-uni">${uni.name}</span>
                        <span class="pred-chance ${chanceClass}">${uOdds}% Chance</span>
                    </div>
                    <div class="pred-bar-track">
                        <div class="pred-bar-fill ${chanceClass}" style="width: ${uOdds}%"></div>
                    </div>
                    <p class="pred-note">${uni.tier === 'reach' ? 'Ambitious target' : uni.tier === 'target' ? 'Realistic match' : 'Safety institution'}. GPA criteria: ${uni.reqGpa}+ / IELTS required: ${uni.reqIelts}.</p>
                </div>
            `;
        });
    }

    // 5. Visa Readiness Analysis
    const visaCont = document.getElementById('visaReadinessContainer');
    if (visaCont) {
        visaCont.innerHTML = '';
        const targetCountries = ['USA', 'UK', 'Canada'];
        
        targetCountries.forEach(vCountry => {
            let vScore = 55;
            if (ielts >= 7.0) vScore += 15;
            if (cgpa >= 3.5) vScore += 10;
            if (exp >= 2) vScore += 5;
            
            if (budget === 'Self-funded') vScore += 15;
            else if (budget === 'Partial scholarship needed') vScore += 10;
            else vScore -= 10; // solvency checks are stricter for full funding seekers

            vScore = Math.max(30, Math.min(95, vScore));
            
            const solvencyDone = (budget === 'Self-funded' || (budget === 'Partial scholarship needed' && cgpa >= 3.2)) ? 'done' : 'pending';
            const langDone = (ielts >= 6.5) ? 'done' : 'pending';
            const acadDone = (cgpa >= 3.0) ? 'done' : 'pending';

            visaCont.innerHTML += `
                <div class="visa-ready-card">
                    <div class="visa-ready-header">
                        <span class="visa-country-flag">${vCountry === 'USA' ? '🇺🇸' : vCountry === 'UK' ? '🇬🇧' : '🇨🇦'}</span>
                        <h4>${vCountry === 'USA' ? 'USA (F-1 Student Visa)' : vCountry === 'UK' ? 'UK (Student Visa Route)' : 'Canada (Study Permit)'}</h4>
                    </div>
                    <div class="visa-meter-row">
                        <span class="visa-meter-label">Approval Odds</span>
                        <div class="visa-meter-track"><div class="visa-meter-fill" style="width: ${vScore}%"></div></div>
                        <span class="visa-meter-val">${vScore}%</span>
                    </div>
                    <ul class="visa-checklist">
                        <li class="done">Valid Passport (6+ Months)</li>
                        <li class="${acadDone}">Academic Transcript verification</li>
                        <li class="${langDone}">Language Competency scores (Min 6.5)</li>
                        <li class="${solvencyDone}">Financial Solvency / Funding documents</li>
                    </ul>
                </div>
            `;
        });
    }

    // 6. Scholarship Matching
    const scholarshipsCont = document.getElementById('scholarshipsContainer');
    if (scholarshipsCont) {
        scholarshipsCont.innerHTML = '';
        let listSchols = [];

        if (country === 'USA') {
            listSchols = [
                { name: 'Fulbright Foreign Student Program', amount: 'Full Funding + Monthly Stipend', match: Math.round(score * 0.95) },
                { name: 'Hubert H. Humphrey Fellowship', amount: 'Full Funding + Travel Allowance', match: Math.round(score * 0.9) },
                { name: 'Abrovia USA Merit Scholarship', amount: 'Partial Tuition Waiver ($15,000)', match: Math.round(score * 1.0) }
            ];
        } else if (country === 'Canada') {
            listSchols = [
                { name: 'Vanier Canada Graduate Scholarship', amount: '$50,000 per year (Full Funding)', match: Math.round(score * 0.94) },
                { name: 'Lester B. Pearson Scholarship', amount: 'Full Tuition + Books + Residence', match: Math.round(score * 0.88) },
                { name: 'Ontario Graduate Scholarship (OGS)', amount: '$15,000 per academic year', match: Math.round(score * 0.98) }
            ];
        } else if (country === 'UK') {
            listSchols = [
                { name: 'Commonwealth Shared Scholarship', amount: 'Full Tuition + Airfare + Living Stipend', match: Math.round(score * 0.96) },
                { name: 'Chevening Scholarship (UK Govt)', amount: 'Full Tuition + Monthly Allowance', match: Math.round(score * 0.92) },
                { name: 'Great Scholarships (UK)', amount: '£10,000 Tuition Waiver', match: Math.round(score * 1.0) }
            ];
        } else if (country === 'Australia') {
            listSchols = [
                { name: 'Australia Awards Scholarship', amount: 'Full Tuition + Health Cover + Living Stipend', match: Math.round(score * 0.94) },
                { name: 'Destination Australia Program', amount: '$15,000 per year assistance', match: Math.round(score * 1.0) },
                { name: 'Melbourne Research Scholarship', amount: 'Full Tuition Offset + Stipend', match: Math.round(score * 0.9) }
            ];
        } else { // Germany
            listSchols = [
                { name: 'DAAD Graduate Scholarships', amount: '€934/month + Travel Grant', match: Math.round(score * 0.96) },
                { name: 'Deutschlandstipendium National', amount: '€300 per month funding', match: Math.round(score * 1.0) },
                { name: 'Heinrich Böll Scholarships', amount: '€861/month stipend', match: Math.round(score * 0.9) }
            ];
        }

        listSchols.forEach(schol => {
            const matchPct = Math.max(45, Math.min(99, schol.match));
            scholarshipsCont.innerHTML += `
                <div class="scholarship-card">
                    <div class="schol-match-bar"><div class="schol-match-fill" style="width: ${matchPct}%"></div></div>
                    <h4 class="schol-name">${schol.name}</h4>
                    <p class="schol-meta">${schol.amount} • Deadline: Oct-Dec 2026</p>
                    <span class="schol-match-pct">${matchPct}% Match</span>
                </div>
            `;
        });
    }

    // 7. Profile Improvement Roadmap
    const roadmapCont = document.getElementById('roadmapContainer');
    if (roadmapCont) {
        roadmapCont.innerHTML = `
            <div class="roadmap-item">
                <div class="roadmap-dot active"></div>
                <div class="roadmap-content">
                    <div class="roadmap-header">
                        <h4>Month 1-2: Research Foundation & Academic Target</h4>
                        <span class="impact-badge high-impact">High Impact</span>
                    </div>
                    <p>Establish relationships with 2-3 academic professors in ${field}. Secure research roles or draft short publications to boost quantitative depth. Target GRE/GMAT classes if GPA is below 3.5.</p>
                </div>
            </div>
            <div class="roadmap-item">
                <div class="roadmap-dot"></div>
                <div class="roadmap-content">
                    <div class="roadmap-header">
                        <h4>Month 3-4: Standardized Exams & Skills Acquisition</h4>
                        <span class="impact-badge medium-impact">Medium Impact</span>
                    </div>
                    <p>${ielts < 7.5 ? 'Retake English assessment. Dedicate time to IELTS Writing/Speaking to touch a 7.5+ band.' : 'Your IELTS score of ' + ielts.toFixed(1) + ' is solid. Concentrate on acquiring certified skill tags like Python, Machine Learning, or Analytics.'}</p>
                </div>
            </div>
            <div class="roadmap-item">
                <div class="roadmap-dot"></div>
                <div class="roadmap-content">
                    <div class="roadmap-header">
                        <h4>Month 5-6: Application Submission & Financial Planning</h4>
                        <span class="impact-badge high-impact">High Impact</span>
                    </div>
                    <p>Draft Statement of Purpose (SOP) tailored for ${country} institutions. Secure strong Letters of Recommendation (LOR) from research supervisors. Finalize financial records showing ${budget === 'Self-funded' ? 'solvency' : 'scholarship candidacy'}.</p>
                </div>
            </div>
        `;
    }

    // 8. Priority Report
    const reportMetricsCont = document.getElementById('reportMetricsContainer');
    const reportNarrativeCont = document.getElementById('reportNarrativeContainer');
    if (reportMetricsCont && reportNarrativeCont) {
        const percentile = Math.max(1, Math.round(100 - (score * 0.82 + cgpa * 3.5)));
        const sopRating = Math.max(4, Math.round(score / 11 + (exp >= 1 ? 1 : 0)));
        const resRating = Math.max(3, Math.round(score / 12 + exp * 0.5));
        const finRating = budget === 'Self-funded' ? 9 : budget === 'Partial scholarship needed' ? 7 : 5;

        reportMetricsCont.innerHTML = `
            <div class="report-metric">
                <span class="report-metric-val">Top ${percentile}%</span>
                <span class="report-metric-lbl">Global Applicant Percentile</span>
            </div>
            <div class="report-metric">
                <span class="report-metric-val">${sopRating} / 10</span>
                <span class="report-metric-lbl">SOP Fit Index</span>
            </div>
            <div class="report-metric">
                <span class="report-metric-val">${resRating} / 10</span>
                <span class="report-metric-lbl">Research Profile Rating</span>
            </div>
            <div class="report-metric">
                <span class="report-metric-val">${finRating} / 10</span>
                <span class="report-metric-lbl">Funding Viability Index</span>
            </div>
        `;

        reportNarrativeCont.innerHTML = `
            <h4>AI Assessment Narrative</h4>
            <p>Your custom vector profile places you in the <strong>top ${percentile}%</strong> of international students apply for ${field} programs in ${country}. Your principal strength is an academic GPA of ${cgpa.toFixed(2)} paired with language certification of ${ielts.toFixed(1)}. Due to the selected ${budget} requirements, we recommend prioritizing target colleges over ambitious reach universities. Focusing on adding certifications in skills like Python and SQL will maximize your profiles marketability before embassy visa interviews.</p>
        `;
    }
}

// Perform initial evaluation instantly
calculateEvaluation(false);

// Evaluate Button Event Trigger
document.getElementById('btnRunEval').addEventListener('click', () => {
    // Open loading modal overlay
    const overlay = document.getElementById('aiModalOverlay');
    overlay.classList.add('active');
    
    // progress steps selectors
    const step1 = document.getElementById('step_1');
    const step2 = document.getElementById('step_2');
    const step3 = document.getElementById('step_3');
    const step4 = document.getElementById('step_4');
    const step5 = document.getElementById('step_5');
    
    // reset steps classes
    const allSteps = document.querySelectorAll('.progress-step');
    allSteps.forEach(s => s.classList.remove('active', 'done'));

    const thinkingText = document.getElementById('thinkingText');
    const thinkingSub = document.getElementById('thinkingSubtext');

    // Run simulator timeline
    thinkingText.innerText = "Analyzing credentials...";
    thinkingSub.innerText = "Processing CGPA and language scores...";
    
    // Step 1 active
    step1.classList.add('active');
    
    setTimeout(() => {
        step1.classList.remove('active');
        step1.classList.add('done');
        step2.classList.add('active');
        thinkingText.innerText = "Evaluating IELTS metrics...";
        thinkingSub.innerText = "Calculating language competency indicators...";
    }, 600);

    setTimeout(() => {
        step2.classList.remove('active');
        step2.classList.add('done');
        step3.classList.add('active');
        thinkingText.innerText = "Simulating visa readiness...";
        thinkingSub.innerText = "Checking embassy risk parameters for " + document.getElementById('input_country').value + "...";
    }, 1200);

    setTimeout(() => {
        step3.classList.remove('active');
        step3.classList.add('done');
        step4.classList.add('active');
        thinkingText.innerText = "Scanning university tables...";
        thinkingSub.innerText = "Matching profile index against admission benchmarks...";
    }, 1800);

    setTimeout(() => {
        step4.classList.remove('active');
        step4.classList.add('done');
        step5.classList.add('active');
        thinkingText.innerText = "Synthesizing recommendations...";
        thinkingSub.innerText = "Compiling tailored roadmaps and scholarship lists...";
    }, 2400);

    // Save profile to db via AJAX POST in parallel
    const formData = new FormData(document.getElementById('profileEvalForm'));
    formData.append('action', 'save_profile');

    fetch('ai-evaluation.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        // Complete last step
        setTimeout(() => {
            step5.classList.remove('active');
            step5.classList.add('done');
            
            // Close loading modal
            overlay.classList.remove('active');
            
            // Execute calculations with cool gauge count-up animations
            calculateEvaluation(true);
            
            // Show custom toast notification
            showToast("Evaluation Complete", "AI profile recommendations updated successfully.", "success");
        }, 3000);
    })
    .catch(err => {
        setTimeout(() => {
            overlay.classList.remove('active');
            alert("An error occurred during DB persistence: " + err);
        }, 3000);
    });
});

// Toast Helper
function showToast(title, message, type) {
    const toast = document.createElement('div');
    toast.className = 'eval-toast';
    
    const iconClass = type === 'success' ? 'toast-success' : 'toast-error';
    const checkIcon = type === 'success' ? '✓' : '!';
    
    toast.innerHTML = `
        <div class="eval-toast-icon ${iconClass}">${checkIcon}</div>
        <div class="eval-toast-content">
            <div class="eval-toast-title">${title}</div>
            <div class="eval-toast-message">${message}</div>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('closing');
        setTimeout(() => toast.remove(), 400);
    }, 4000);
}

// Upgrade Modal Handling
function openUpgradeModal() {
    document.getElementById('upgradeOverlay').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeUpgradeModal() {
    document.getElementById('upgradeOverlay').classList.remove('active');
    document.body.style.overflow = '';
}

document.getElementById('upgradeOverlay').addEventListener('click', function(e) {
    if (e.target === this) closeUpgradeModal();
});

document.getElementById('btnConfirmUpgrade').addEventListener('click', function() {
    this.disabled = true;
    document.getElementById('upgradeText').innerText = 'Processing Payment...';

    const fd = new FormData();
    fd.append('action', 'upgrade');

    fetch('api/upgrade.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            document.getElementById('upgradeText').innerText = 'Activated ✓';
            this.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
            setTimeout(() => location.reload(), 1000);
        } else {
            alert(data.message);
            this.disabled = false;
            document.getElementById('upgradeText').innerText = 'Activate Premium';
        }
    })
    .catch(() => {
        alert('An error occurred during upgrade.');
        this.disabled = false;
        document.getElementById('upgradeText').innerText = 'Activate Premium';
    });
});
</script>
</body>
</html>
