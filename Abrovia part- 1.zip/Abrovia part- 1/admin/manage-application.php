<?php
$current_admin_page = 'applications';
require_once 'includes/auth_check.php';

$appId = intval($_GET['id'] ?? 0);
if ($appId <= 0) {
    header('Location: manage-applications.php');
    exit;
}

// Fetch application details
$stmt = $pdo->prepare("
    SELECT a.*, u.full_name as student_name, u.email as student_email, c.full_name as counselor_name
    FROM applications a
    JOIN users u ON a.user_id = u.id
    LEFT JOIN users c ON a.counselor_id = c.id
    WHERE a.id = ?
");
$stmt->execute([$appId]);
$application = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$application) {
    header('Location: manage-applications.php');
    exit;
}

// Fetch dynamic counselors list for dropdown
$counselors = $pdo->query("SELECT id, full_name FROM users WHERE role IN ('counselor', 'admin') ORDER BY full_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch supporting documents
$doc_stmt = $pdo->prepare("SELECT * FROM documents WHERE application_id = ? ORDER BY uploaded_at DESC");
$doc_stmt->execute([$appId]);
$documents = $doc_stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch internal counseling notes
$notes_stmt = $pdo->prepare("
    SELECT n.*, u.full_name as author_name, u.role as author_role 
    FROM notes n 
    JOIN users u ON n.author_id = u.id 
    WHERE n.application_id = ? 
    ORDER n.created_at DESC
");
try {
    $notes_stmt->execute();
    $notes = $notes_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Fallback if ORDER fails, use created_at
    $notes_stmt = $pdo->prepare("
        SELECT n.*, u.full_name as author_name, u.role as author_role 
        FROM notes n 
        JOIN users u ON n.author_id = u.id 
        WHERE n.application_id = ? 
        ORDER BY n.created_at DESC
    ");
    $notes_stmt->execute([$appId]);
    $notes = $notes_stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch status history timeline
$hist_stmt = $pdo->prepare("
    SELECT sh.*, u.full_name as changer_name, u.role as changer_role
    FROM status_history sh
    JOIN users u ON sh.changed_by = u.id
    WHERE sh.application_id = ?
    ORDER BY sh.created_at DESC
");
$hist_stmt->execute([$appId]);
$history = $hist_stmt->fetchAll(PDO::FETCH_ASSOC);

$status = $application['status'];

// Map the 8 statuses to 5 high-level pipeline steps for counselor review
$step1 = 'completed';
$step2 = 'upcoming';
$step3 = 'upcoming';
$step4 = 'upcoming';
$step5 = 'upcoming';

$line1 = '';
$line2 = '';
$line3 = '';
$line4 = '';

if (in_array($status, ['Processing', 'Documents Required', 'Submitted to University', 'Accepted', 'Waitlisted', 'Rejected', 'Completed'])) {
    $line1 = 'filled';
    if ($status === 'Documents Required') {
        $step2 = 'action-required';
    } elseif ($status === 'Processing') {
        $step2 = 'current';
    } else {
        $step2 = 'completed';
    }
}
if (in_array($status, ['Submitted to University', 'Accepted', 'Waitlisted', 'Rejected', 'Completed'])) {
    $step2 = 'completed';
    $line2 = 'filled';
    if ($status === 'Submitted to University') {
        $step3 = 'current';
    } else {
        $step3 = 'completed';
    }
}
if (in_array($status, ['Accepted', 'Waitlisted', 'Rejected', 'Completed'])) {
    $step3 = 'completed';
    $line3 = 'filled';
    if (in_array($status, ['Accepted', 'Waitlisted', 'Rejected'])) {
        $step4 = 'current';
    } else {
        $step4 = 'completed';
    }
}
if ($status === 'Completed') {
    $step4 = 'completed';
    $line4 = 'filled';
    $step5 = 'completed';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Application Details - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .admin-main { padding: 40px; }
        .back-btn-row { margin-bottom: 24px; }
        .back-btn-row a {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.85rem;
            color: var(--text-secondary);
            text-decoration: none;
            transition: color 0.25s;
        }
        .back-btn-row a:hover { color: #fff; }

        /* Dynamic Progress Timeline */
        .pipeline-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 30px 40px;
            margin-bottom: 24px;
        }
        .pipeline-tracker {
            display: flex;
            align-items: flex-start;
        }
        .pipeline-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
            position: relative;
            text-align: center;
        }
        .pipeline-step .step-dot {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--bg-input);
            border: 2px solid var(--border);
            color: var(--text-muted);
            font-weight: 700;
            font-size: 0.9rem;
            z-index: 2;
            transition: all 0.3s ease;
        }
        .pipeline-step.completed .step-dot {
            background: var(--accent);
            border-color: var(--accent);
            color: #fff;
            box-shadow: 0 0 12px var(--accent-glow);
        }
        .pipeline-step.current .step-dot {
            background: #fff;
            border-color: var(--accent);
            color: var(--bg-body);
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.15);
        }
        .pipeline-step.action-required .step-dot {
            background: #ef4444;
            border-color: #ef4444;
            color: #fff;
            box-shadow: 0 0 12px rgba(239, 68, 68, 0.4);
        }
        .pipeline-line {
            position: absolute;
            top: 19px;
            left: calc(50% + 19px);
            right: calc(-50% + 19px);
            height: 2px;
            background: rgba(255, 255, 255, 0.05);
            z-index: 1;
        }
        .pipeline-line.filled { background: var(--accent); }
        .step-label { font-size: 0.8rem; font-weight: 600; color: var(--text-muted); margin-top: 8px; }
        .pipeline-step.completed .step-label { color: #fff; }
        .pipeline-step.current .step-label { color: var(--accent); }
        .pipeline-step.action-required .step-label { color: #ef4444; }

        /* Two columns grid */
        .manage-grid {
            display: grid;
            grid-template-columns: 1fr 360px;
            gap: 24px;
            align-items: start;
        }
        .panel-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            padding: 24px;
            margin-bottom: 24px;
        }
        .panel-title {
            font-size: 1rem;
            font-weight: 700;
            color: #fff;
            margin-bottom: 16px;
            padding-bottom: 8px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Counselor quick step forms */
        .step-processor {
            background: linear-gradient(135deg, rgba(108,63,255,0.08), rgba(17, 24, 50, 0.4));
            border: 1px solid var(--border-focus);
            padding: 28px;
            border-radius: var(--radius-md);
            margin-bottom: 24px;
        }
        .processor-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
        .processor-title { font-size: 1.1rem; font-weight: 700; color: #fff; }
        .processor-desc { font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; margin-bottom: 20px; }

        /* Tabs elements */
        .tabs-header { display: flex; gap: 8px; border-bottom: 1px solid var(--border); margin-bottom: 20px; }
        .tab-btn {
            padding: 8px 16px;
            font-size: 0.85rem;
            color: var(--text-muted);
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.2s;
        }
        .tab-btn:hover, .tab-btn.active { color: #fff; }
        .tab-btn.active { border-bottom-color: var(--accent); color: #fff; font-weight: 600; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }

        .note-card {
            background: rgba(255,255,255,0.01);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 12px 16px;
            margin-bottom: 10px;
            font-size: 0.82rem;
        }

        /* Document items */
        .doc-item-review {
            background: rgba(255,255,255,0.01);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 14px 18px;
            margin-bottom: 12px;
        }
        .btn-doc-action {
            padding: 5px 12px;
            font-size: 0.72rem;
            font-weight: 600;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-doc-verify { background: rgba(16, 185, 129, 0.15); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.25); }
        .btn-doc-verify:hover { background: #10b981; color: #fff; }
        .btn-doc-reject { background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.25); }
        .btn-doc-reject:hover { background: #ef4444; color: #fff; }
    </style>
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    
    <main class="admin-main">
        <div class="back-btn-row">
            <a href="manage-applications.php">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to User Applications List
            </a>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
            <div>
                <h1 class="page-title" style="font-size:1.8rem;"><?= htmlspecialchars($application['student_name']) ?></h1>
                <p class="page-subtitle">✉ <?= htmlspecialchars($application['student_email']) ?> • <?= htmlspecialchars($application['program_name']) ?> at <?= htmlspecialchars($application['university_name']) ?></p>
            </div>
            
            <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); padding:8px 16px; border-radius:4px; text-align:center;">
                <span style="font-size:0.65rem; color:var(--text-muted); text-transform:uppercase; display:block;">Stage Status</span>
                <strong style="color:var(--accent); font-size:0.9rem; text-transform:uppercase;"><?= htmlspecialchars($status) ?></strong>
            </div>
        </div>

        <!-- 1. Realtime Pipeline Tracker at the top -->
        <section class="pipeline-card">
            <div class="pipeline-tracker">
                <div class="pipeline-step <?= $step1 ?>">
                    <div class="step-dot">1</div>
                    <div class="pipeline-line <?= $line1 ?>"></div>
                    <span class="step-label">Application Submitted</span>
                </div>
                <div class="pipeline-step <?= $step2 ?>">
                    <div class="step-dot">2</div>
                    <div class="pipeline-line <?= $line2 ?>"></div>
                    <span class="step-label">Credential Verification</span>
                </div>
                <div class="pipeline-step <?= $step3 ?>">
                    <div class="step-dot">3</div>
                    <div class="pipeline-line <?= $line3 ?>"></div>
                    <span class="step-label">Sent to University</span>
                </div>
                <div class="pipeline-step <?= $step4 ?>">
                    <div class="step-dot">4</div>
                    <div class="pipeline-line <?= $line4 ?>"></div>
                    <span class="step-label">University Decision</span>
                </div>
                <div class="pipeline-step <?= $step5 ?>">
                    <div class="step-dot">5</div>
                    <span class="step-label">Journey Completed</span>
                </div>
            </div>
        </section>

        <!-- 2. Step Processor Panel (Counsler Guide) -->
        <section class="step-processor" id="counselor-quick-actions">
            
            <?php if ($status === 'New'): ?>
                <!-- Step 1 Actions -->
                <div class="processor-header">
                    <h3 class="processor-title">Step 1: Initial Profile & Counselor Assignment</h3>
                    <span class="status-badge badge-new">New Application</span>
                </div>
                <p class="processor-desc">
                    We've received the student's application. Please review the details, assign a dedicated Study Abroad Counselor, and mark the step completed to shift the application into processing state.
                </p>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <form id="step1-form" style="display:flex; gap:12px; align-items:center; flex:1;">
                        <input type="hidden" name="action" value="assign_counselor">
                        <input type="hidden" name="id" value="<?= $appId ?>">
                        <select name="counselor_id" class="filter-select" style="min-width:200px;" required>
                            <option value="">-- Choose Counselor --</option>
                            <?php foreach ($counselors as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= $application['counselor_id'] == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="button" class="btn btn-primary" onclick="ajaxStepSubmit('step1-form', 'Counselor assigned! Application review will now begin.')">Assign Counselor</button>
                    </form>
                    
                    <button class="btn btn-primary" style="background:#10b981;" onclick="quickStatusChange('Processing', 'Application review started by counselor.')">✓ Start Processing & Mark Step Done</button>
                </div>

            <?php elseif ($status === 'Processing' || $status === 'Documents Required'): ?>
                <!-- Step 2 Actions -->
                <div class="processor-header">
                    <h3 class="processor-title">Step 2: Supporting Credentials Verification</h3>
                    <span class="status-badge <?= $status === 'Documents Required' ? 'badge-docs' : 'badge-processing' ?>">
                        <?= $status === 'Documents Required' ? 'Action Needed (Student)' : 'Under Review' ?>
                    </span>
                </div>
                <p class="processor-desc">
                    Review all transcripts and documents uploaded by the student in the **Documents Review** tab below. If any key certificate is missing, dispatch a Document Request to the student. If everything is verified, mark the credentials verification step completed to forward their profile to the target university admissions team.
                </p>
                <div style="display:flex; gap:16px; flex-wrap:wrap; align-items:center;">
                    <!-- Request document toggle -->
                    <button class="btn btn-outline" onclick="document.getElementById('quick-doc-req').style.display='block';">📨 Request Specific Document</button>
                    
                    <!-- Complete step -->
                    <button class="btn btn-primary" style="background:#10b981;" onclick="quickStatusChange('Submitted to University', 'Academic profile and supporting credentials verified. Application officially forwarded to University Admissions Board.')">✓ Mark Credentials Verified & Forward to University</button>
                </div>

                <!-- Hidden quick doc request form -->
                <div id="quick-doc-req" style="display:none; background:rgba(0,0,0,0.2); padding:16px; border-radius:6px; border:1px solid var(--border); margin-top:16px;">
                    <form id="step2-doc-form">
                        <input type="hidden" name="action" value="request_doc">
                        <input type="hidden" name="id" value="<?= $appId ?>">
                        <div class="form-group" style="margin-bottom:10px;">
                            <label class="form-label" style="font-size:0.75rem;">Requested Document Name</label>
                            <input type="text" name="doc_name" class="form-input" placeholder="e.g. TOEFL Certificate, Recommendation Letter" required style="padding:6px 12px; font-size:0.8rem;">
                        </div>
                        <div class="form-group" style="margin-bottom:12px;">
                            <label class="form-label" style="font-size:0.75rem;">Instructions for Student</label>
                            <textarea name="description" class="form-textarea" placeholder="Provide instructions on what details need to be uploaded..." style="min-height:50px; padding:8px; font-size:0.8rem;"></textarea>
                        </div>
                        <div style="display:flex; justify-content:flex-end; gap:8px;">
                            <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('quick-doc-req').style.display='none';">Cancel</button>
                            <button type="button" class="btn btn-primary btn-sm" onclick="ajaxStepSubmit('step2-doc-form', 'Document requested! Application status shifted to Documents Required.')">Send Request</button>
                        </div>
                    </form>
                </div>

            <?php elseif ($status === 'Submitted to University'): ?>
                <!-- Step 3 Actions -->
                <div class="processor-header">
                    <h3 class="processor-title">Step 3: University Offer Evaluation</h3>
                    <span class="status-badge badge-uni">Sent to University</span>
                </div>
                <p class="processor-desc">
                    The student's package is currently under evaluation by the University Admissions team. Once their official evaluation response (admissions decision letter) is received, register the outcome:
                </p>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <button class="btn btn-primary" style="background:#10b981;" onclick="promptStatusChange('Accepted', 'Congratulations! The University Admissions Board has accepted your profile. Offer letter issued.')">✓ Student Accepted Offer</button>
                    
                    <button class="btn btn-primary" style="background:#f97316;" onclick="promptStatusChange('Waitlisted', 'University has placed your application on the Waitlist. Further screening is scheduled.')">⌛ Student Waitlisted</button>
                    
                    <button class="btn btn-danger" onclick="promptStatusChange('Rejected', 'Admissions Board has declined the application based on academic quota constraints.')">✗ Student Declined / Rejected</button>
                </div>

            <?php elseif (in_array($status, ['Accepted', 'Waitlisted'])): ?>
                <!-- Step 4 Actions -->
                <div class="processor-header">
                    <h3 class="processor-title">Step 4: Visa Support & Final Enrollment</h3>
                    <span class="status-badge badge-accepted">Admitted Offer Received</span>
                </div>
                <p class="processor-desc">
                    Admissions decision completed! The student has received their offer. Please guide them in preparing visa funds, police clearance, health clearance, and securing their CAS certificate. Once all visa approvals and pre-travel tasks are complete, mark the journey completed!
                </p>
                <button class="btn btn-primary" style="background:#10b981; width:100%;" onclick="quickStatusChange('Completed', 'Student visa finalized and pre-travel orientation completed. Study abroad journey finalized successfully!')">✓ Finalize Visa & Mark Journey Completed</button>

            <?php elseif ($status === 'Completed'): ?>
                <!-- Step 5 Actions -->
                <div class="processor-header">
                    <h3 class="processor-title">Step 5: Enrollment Finalized successfully!</h3>
                    <span class="status-badge badge-completed">Journey Completed ✓</span>
                </div>
                <p class="processor-desc" style="margin-bottom:0;">
                    🎉 **Study Abroad Journey Successfully Completed!** The student has successfully secured their student visa, finished all university pre-requisites, and is ready to travel. No further counseling actions are required.
                </p>
            <?php endif; ?>

        </section>

        <!-- 3. Bottom Grid: Reviews, Notes, Timeline History -->
        <div class="manage-grid">
            
            <div class="panel-card" style="min-height:500px;">
                <div class="tabs-header">
                    <div class="tab-btn active" onclick="switchTab('tab-docs')">📂 Transcripts & Uploads (<?= count($documents) ?>)</div>
                    <div class="tab-btn" onclick="switchTab('tab-notes')">📝 Counseling Notes (<?= count($notes) ?>)</div>
                    <div class="tab-btn" onclick="switchTab('tab-history')">🕒 Status Audit Log (<?= count($history) ?>)</div>
                </div>

                <!-- Tab 1: Documents Upload Review -->
                <div class="tab-content active" id="tab-docs">
                    <?php if (empty($documents)): ?>
                        <div style="text-align:center; padding:40px; color:var(--text-muted); font-size:0.85rem; border:1px dashed var(--border); border-radius:6px;">
                            No files uploaded yet.
                        </div>
                    <?php else: foreach ($documents as $doc): 
                        $statusColor = '#f59e0b';
                        if ($doc['status'] === 'verified') $statusColor = '#10b981';
                        elseif ($doc['status'] === 'rejected') $statusColor = '#ef4444';
                    ?>
                        <div class="doc-item-review">
                            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                                <div>
                                    <strong style="font-size:0.85rem; color:#fff; display:block;">📄 <?= htmlspecialchars($doc['name']) ?></strong>
                                    <span style="font-size:0.75rem; color:<?= $statusColor ?>; font-weight:600;">● Status: <?= strtoupper($doc['status']) ?></span>
                                    <?php if ($doc['status'] === 'rejected' && $doc['admin_message']): ?>
                                        <div style="font-size:0.75rem; color:#f87171; margin-top:4px;">Feedback: "<?= htmlspecialchars($doc['admin_message']) ?>"</div>
                                    <?php endif; ?>
                                </div>
                                <div style="display:flex; gap:8px;">
                                    <?php if (!empty($doc['file_path'])): ?>
                                        <a href="../<?= htmlspecialchars($doc['file_path']) ?>" download class="btn btn-outline btn-sm" style="font-size:0.7rem; padding:4px 8px; text-decoration:none;">Download File</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <?php if ($doc['status'] === 'under_review'): ?>
                                <div style="margin-top:10px; display:flex; gap:8px; border-top:1px solid rgba(255,255,255,0.03); padding-top:10px;">
                                    <button class="btn-doc-action btn-doc-verify" onclick="reviewDocument(<?= $doc['id'] ?>, 'verified')">Approve Document ✓</button>
                                    <button class="btn-doc-action btn-doc-reject" onclick="reviewDocument(<?= $doc['id'] ?>, 'rejected')">Reject with Feedback ✗</button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; endif; ?>
                </div>

                <!-- Tab 2: Counselor Notes -->
                <div class="tab-content" id="tab-notes">
                    <form id="notes-form" style="margin-bottom:20px; display:flex; gap:10px;">
                        <input type="hidden" name="action" value="add_note">
                        <input type="hidden" name="id" value="<?= $appId ?>">
                        <textarea name="note_text" class="form-textarea" required placeholder="Add private counseling comments/meeting notes..." style="flex:1; min-height:50px; padding:10px; font-size:0.8rem;"></textarea>
                        <button type="button" class="btn btn-primary" onclick="ajaxStepSubmit('notes-form', 'Counseling log saved!')" style="align-self:flex-end;">Save Note</button>
                    </form>
                    
                    <div style="display:flex; flex-direction:column; gap:10px;">
                        <?php if (empty($notes)): ?>
                            <div style="color:var(--text-muted); font-size:0.85rem; text-align:center; padding:20px;">No counselor notes added yet.</div>
                        <?php else: foreach ($notes as $n): ?>
                            <div class="note-card">
                                <p style="color:var(--text-secondary); line-height:1.5;">"<?= htmlspecialchars($n['note_text']) ?>"</p>
                                <span style="font-size:0.7rem; color:var(--text-muted); display:block; margin-top:4px;">
                                    By <strong><?= htmlspecialchars($n['author_name']) ?></strong> (<?= strtoupper($n['author_role']) ?>) • <?= date('M d, Y • h:i A', strtotime($n['created_at'])) ?>
                                </span>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>

                <!-- Tab 3: Timeline status audit trail -->
                <div class="tab-content" id="tab-history">
                    <div style="display:flex; flex-direction:column; gap:12px;">
                        <?php if (empty($history)): ?>
                            <div style="color:var(--text-muted); font-size:0.85rem; text-align:center; padding:20px;">No transitions logged yet.</div>
                        <?php else: foreach ($history as $h): ?>
                            <div style="background:rgba(255,255,255,0.01); border-left:3px solid var(--accent); padding:10px 14px; border-radius:0 4px 4px 0; font-size:0.8rem;">
                                <div style="font-weight:600; color:#fff;">Transition: <?= htmlspecialchars($h['old_status'] ?: 'New') ?> ➔ <?= htmlspecialchars($h['new_status']) ?></div>
                                <?php if ($h['comments']): ?>
                                    <p style="color:var(--text-muted); font-size:0.78rem; margin:2px 0 4px;">"<?= htmlspecialchars($h['comments']) ?>"</p>
                                <?php endif; ?>
                                <span style="font-size:0.68rem; color:var(--text-muted); display:block;">
                                    By <?= htmlspecialchars($h['changer_name']) ?> (<?= ucfirst($h['changer_role']) ?>) • <?= date('M d, Y • h:i A', strtotime($h['created_at'])) ?>
                                </span>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>

            </div>

            <!-- Profile Sidebar panel -->
            <div class="panel-card" style="padding:20px;">
                <h3 class="panel-title" style="margin-bottom:12px;">👤 Student Details</h3>
                <div style="display:flex; flex-direction:column; gap:12px; font-size:0.82rem;">
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.68rem; text-transform:uppercase;">Student Name</span>
                        <strong style="color:#fff;"><?= htmlspecialchars($application['student_name']) ?></strong>
                    </div>
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.68rem; text-transform:uppercase;">Email</span>
                        <span style="color:var(--text-secondary);"><?= htmlspecialchars($application['student_email']) ?></span>
                    </div>
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.68rem; text-transform:uppercase;">Assigned Counselor</span>
                        <strong style="color:#c4b5fd;">👤 <?= $application['counselor_name'] ?: 'Unassigned' ?></strong>
                    </div>
                    <div style="border-top:1px solid rgba(255,255,255,0.04); padding-top:12px; margin-top:6px;">
                        <span style="color:var(--text-muted); display:block; font-size:0.68rem; text-transform:uppercase;">Program of Interest</span>
                        <strong style="color:#fff;"><?= htmlspecialchars($application['program_name']) ?></strong>
                    </div>
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.68rem; text-transform:uppercase;">Target University</span>
                        <strong style="color:#fff;"><?= htmlspecialchars($application['university_name']) ?></strong>
                    </div>
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.68rem; text-transform:uppercase;">Source / Origin</span>
                        <strong style="color:#fff; text-transform:capitalize;"><?= htmlspecialchars($application['source_type']) ?> page</strong>
                    </div>
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.68rem; text-transform:uppercase;">Visa Phase Status</span>
                        <strong style="color:#2dd4bf; text-transform:uppercase;"><?= htmlspecialchars($application['visa_status']) ?></strong>
                    </div>
                </div>
            </div>

        </div>

    </main>
</div>

<script>
function switchTab(tabId) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    
    // Show active tab
    document.getElementById(tabId).classList.add('active');
    
    // Highlight active button
    event.currentTarget.classList.add('active');
}

function ajaxStepSubmit(formId, successMsg) {
    const form = document.getElementById(formId);
    const fd = new FormData(form);
    
    fetch('api/applications.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            alert(successMsg);
            location.reload();
        } else {
            alert(d.message);
        }
    })
    .catch(err => {
        alert('An error occurred during transaction processing.');
    });
}

function quickStatusChange(newStatus, commentText) {
    const fd = new FormData();
    fd.append('action', 'update_status');
    fd.append('id', <?= $appId ?>);
    fd.append('status', newStatus);
    fd.append('comments', commentText);
    
    fetch('api/applications.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            alert('Application status successfully transition completed!');
            location.reload();
        } else {
            alert(d.message);
        }
    });
}

function promptStatusChange(newStatus, defaultComment) {
    const userComments = prompt("Enter decision remarks for student notifications:", defaultComment);
    if (userComments === null) return; // cancel
    if (userComments.trim() === '') {
        alert("A remark comments entry is required.");
        return;
    }
    
    quickStatusChange(newStatus, userComments);
}

function reviewDocument(docId, docStatus) {
    let feedback = '';
    if (docStatus === 'rejected') {
        feedback = prompt('Please enter rejection feedback reason for the student:');
        if (feedback === null) return;
        if (feedback.trim() === '') {
            alert('A feedback comments description is required.');
            return;
        }
    }
    
    const fd = new FormData();
    fd.append('action', 'update_doc_status');
    fd.append('doc_id', docId);
    fd.append('status', docStatus);
    fd.append('feedback', feedback);
    
    fetch('api/applications.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert('Credential review updated successfully!');
            location.reload();
        } else {
            alert(d.message);
        }
    });
}
</script>
</body>
</html>
