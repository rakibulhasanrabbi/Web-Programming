<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth_check.php';

$action = $_REQUEST['action'] ?? '';

if ($action === 'list') {
    try {
        $stmt = $pdo->query("
            SELECT c.*, 
                (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) as enrolled_count,
                (SELECT COALESCE(SUM(amount), 0) FROM payments WHERE course_id = c.id AND status = 'completed') as total_revenue
            FROM courses c 
            ORDER BY c.id ASC
        ");
        $courses = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $courses]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'create') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
        exit;
    }

    $name = $_POST['name'] ?? '';
    $slug = $_POST['slug'] ?? '';
    $description = $_POST['description'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    $duration = intval($_POST['duration_weeks'] ?? 8);
    $status = $_POST['status'] ?? 'active';
    $featuresRaw = $_POST['features'] ?? '';

    // Convert comma-separated or newline-separated features to JSON array
    $features = array_filter(array_map('trim', explode("\n", str_replace("\r", "", $featuresRaw))));
    $featuresJson = json_encode(array_values($features));

    if (empty($name) || empty($slug)) {
        echo json_encode(['success' => false, 'message' => 'Course name and URL slug are required.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO courses (name, slug, description, price, duration_weeks, features, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$name, $slug, $description, $price, $duration, $featuresJson, $status]);
        echo json_encode(['success' => true, 'message' => 'Course created successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to create course: ' . $e->getMessage()]);
    }
    exit;

} else if ($action === 'update') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
        exit;
    }

    $id = intval($_POST['id'] ?? 0);
    $name = $_POST['name'] ?? '';
    $slug = $_POST['slug'] ?? '';
    $description = $_POST['description'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    $duration = intval($_POST['duration_weeks'] ?? 8);
    $status = $_POST['status'] ?? 'active';
    $featuresRaw = $_POST['features'] ?? '';

    $features = array_filter(array_map('trim', explode("\n", str_replace("\r", "", $featuresRaw))));
    $featuresJson = json_encode(array_values($features));

    if ($id <= 0 || empty($name) || empty($slug)) {
        echo json_encode(['success' => false, 'message' => 'Course ID, name, and URL slug are required.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            UPDATE courses 
            SET name = ?, slug = ?, description = ?, price = ?, duration_weeks = ?, features = ?, status = ?
            WHERE id = ?
        ");
        $stmt->execute([$name, $slug, $description, $price, $duration, $featuresJson, $status, $id]);
        echo json_encode(['success' => true, 'message' => 'Course updated successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to update course: ' . $e->getMessage()]);
    }
    exit;

} else if ($action === 'delete') {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid ID.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("UPDATE courses SET status = 'inactive' WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true, 'message' => 'Course set to inactive successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to deactivate course: ' . $e->getMessage()]);
    }
    exit;

} else if ($action === 'list_enrollments') {
    $courseId = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
    $search = $_GET['search'] ?? '';

    try {
        $sql = "
            SELECT e.*, u.full_name, u.email, c.name as course_name, p.amount, p.status as payment_status, p.paid_at
            FROM enrollments e
            JOIN users u ON e.user_id = u.id  
            JOIN courses c ON e.course_id = c.id
            LEFT JOIN payments p ON e.payment_id = p.id
            WHERE 1=1
        ";
        $params = [];

        if ($courseId > 0) {
            $sql .= " AND e.course_id = ?";
            $params[] = $courseId;
        }

        if (!empty($search)) {
            $sql .= " AND (u.full_name LIKE ? OR u.email LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        $sql .= " ORDER BY e.enrolled_at DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $enrollments = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $enrollments]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'update_enrollment') {
    $enrollmentId = intval($_POST['enrollment_id'] ?? 0);
    $status = $_POST['status'] ?? '';

    if ($enrollmentId <= 0 || !in_array($status, ['active', 'suspended', 'removed'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid parameters.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("UPDATE enrollments SET status = ? WHERE id = ?");
        $stmt->execute([$status, $enrollmentId]);
        echo json_encode(['success' => true, 'message' => 'Student enrollment status updated!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'list_payments') {
    $courseId = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

    try {
        $sql = "
            SELECT p.*, u.full_name, u.email, c.name as course_name
            FROM payments p
            JOIN users u ON p.user_id = u.id
            JOIN courses c ON p.course_id = c.id
            WHERE 1=1
        ";
        $params = [];

        if ($courseId > 0) {
            $sql .= " AND p.course_id = ?";
            $params[] = $courseId;
        }

        $sql .= " ORDER BY p.paid_at DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $payments = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $payments]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'list_content') {
    $courseId = intval($_GET['course_id'] ?? 0);
    if ($courseId <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid Course ID.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT * FROM course_content 
            WHERE course_id = ? 
            ORDER BY type ASC, sort_order ASC
        ");
        $stmt->execute([$courseId]);
        $content = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $content]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'add_content') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
        exit;
    }

    $courseId = intval($_POST['course_id'] ?? 0);
    $type = $_POST['type'] ?? '';
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $url = $_POST['content_url'] ?? '#';
    $duration = !empty($_POST['duration_minutes']) ? intval($_POST['duration_minutes']) : null;
    $sortOrder = intval($_POST['sort_order'] ?? 0);
    $isFree = intval($_POST['is_free_preview'] ?? 0);

    if ($courseId <= 0 || empty($type) || empty($title)) {
        echo json_encode(['success' => false, 'message' => 'Course ID, title and content type are required.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO course_content (course_id, type, title, description, content_url, duration_minutes, sort_order, is_free_preview)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$courseId, $type, $title, $description, $url, $duration, $sortOrder, $isFree]);
        echo json_encode(['success' => true, 'message' => 'Content item added successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to add content item: ' . $e->getMessage()]);
    }
    exit;

} else if ($action === 'update_content') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
        exit;
    }

    $id = intval($_POST['id'] ?? 0);
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $url = $_POST['content_url'] ?? '#';
    $duration = !empty($_POST['duration_minutes']) ? intval($_POST['duration_minutes']) : null;
    $sortOrder = intval($_POST['sort_order'] ?? 0);
    $isFree = intval($_POST['is_free_preview'] ?? 0);
    $status = $_POST['status'] ?? 'active';

    if ($id <= 0 || empty($title)) {
        echo json_encode(['success' => false, 'message' => 'Content ID and title are required.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            UPDATE course_content 
            SET title = ?, description = ?, content_url = ?, duration_minutes = ?, sort_order = ?, is_free_preview = ?, status = ?
            WHERE id = ?
        ");
        $stmt->execute([$title, $description, $url, $duration, $sortOrder, $isFree, $status, $id]);
        echo json_encode(['success' => true, 'message' => 'Content item updated successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to update content item: ' . $e->getMessage()]);
    }
    exit;

} else if ($action === 'delete_content') {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid ID.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM course_content WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true, 'message' => 'Content item deleted successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Failed to delete content: ' . $e->getMessage()]);
    }
    exit;

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action requested.']);
    exit;
}
