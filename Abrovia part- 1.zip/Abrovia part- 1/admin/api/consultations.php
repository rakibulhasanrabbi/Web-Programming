<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';
if ($action === 'update_status') {
    $stmt = $pdo->prepare("UPDATE consultation_requests SET status=? WHERE id=?");
    $result = $stmt->execute([$_POST['status'], $_POST['id']]);
    if ($result) {
        $msgs = ['accepted'=>'Your consultation request has been accepted. We will contact you soon.','rejected'=>'Your consultation request has been declined.','completed'=>'Your consultation has been completed. Thank you!'];
        $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)")->execute([$_POST['user_id'], $msgs[$_POST['status']] ?? 'Consultation status updated.']);
    }
    echo json_encode(['success'=>$result]);
} else { echo json_encode(['success'=>false,'message'=>'Invalid action']); }
