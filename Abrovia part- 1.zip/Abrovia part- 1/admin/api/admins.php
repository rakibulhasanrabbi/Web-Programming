<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';
if ($action === 'add') {
    $hash = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, 'admin')");
    try { echo json_encode(['success'=>$stmt->execute([$_POST['full_name'],$_POST['email'],$hash])]); }
    catch(PDOException $e) { echo json_encode(['success'=>false,'message'=>'Email already exists.']); }
} elseif ($action === 'delete') {
    if ($_POST['id'] == $_SESSION['user_id']) { echo json_encode(['success'=>false,'message'=>'Cannot remove yourself.']); exit; }
    echo json_encode(['success'=>$pdo->prepare("DELETE FROM users WHERE id=? AND role='admin'")->execute([$_POST['id']])]);
} else { echo json_encode(['success'=>false,'message'=>'Invalid action']); }
