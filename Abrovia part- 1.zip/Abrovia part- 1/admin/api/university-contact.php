<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';
if ($action === 'add') {
    $stmt = $pdo->prepare("INSERT INTO university_contacts (university_name,country,contact_email,contact_phone,website,notes) VALUES (?,?,?,?,?,?)");
    echo json_encode(['success'=>$stmt->execute([$_POST['university_name'],$_POST['country'],$_POST['contact_email'],$_POST['contact_phone'],$_POST['website'],$_POST['notes']])]);
} elseif ($action === 'edit') {
    $stmt = $pdo->prepare("UPDATE university_contacts SET university_name=?,country=?,contact_email=?,contact_phone=?,website=?,notes=? WHERE id=?");
    echo json_encode(['success'=>$stmt->execute([$_POST['university_name'],$_POST['country'],$_POST['contact_email'],$_POST['contact_phone'],$_POST['website'],$_POST['notes'],$_POST['id']])]);
} elseif ($action === 'delete') {
    echo json_encode(['success'=>$pdo->prepare("DELETE FROM university_contacts WHERE id=?")->execute([$_POST['id']])]);
} elseif ($action === 'send_application') {
    $application_id = intval($_POST['application_id'] ?? 0);
    $contact_id = intval($_POST['university_contact_id'] ?? 0);
    $cover_letter = $_POST['cover_letter'] ?? '';
    
    if ($application_id <= 0 || $contact_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Please select a valid application.']);
        exit;
    }
    
    try {
        $pdo->beginTransaction();
        
        // 1. Fetch application info
        $app_stmt = $pdo->prepare("SELECT a.*, u.full_name as student_name FROM applications a JOIN users u ON a.user_id = u.id WHERE a.id = ?");
        $app_stmt->execute([$application_id]);
        $app = $app_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$app) {
            echo json_encode(['success' => false, 'message' => 'Student application not found.']);
            $pdo->rollBack();
            exit;
        }
        
        // 2. Fetch contact info
        $c_stmt = $pdo->prepare("SELECT * FROM university_contacts WHERE id = ?");
        $c_stmt->execute([$contact_id]);
        $contact = $c_stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$contact) {
            echo json_encode(['success' => false, 'message' => 'University partner contact not found.']);
            $pdo->rollBack();
            exit;
        }
        
        // 3. Update application status to 'in_progress'
        $update_stmt = $pdo->prepare("UPDATE applications SET status = 'in_progress' WHERE id = ?");
        $update_stmt->execute([$application_id]);
        
        // 4. Create a notification for the student
        $notif_msg = "Your application for " . $app['program_name'] . " has been officially forwarded to " . $contact['university_name'] . " (" . $contact['country'] . ") for direct evaluation. Status updated to: In Progress.";
        
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, is_read) VALUES (?, ?, 0)");
        $notif_stmt->execute([$app['user_id'], $notif_msg]);
        
        $pdo->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Forwarding error: ' . $e->getMessage()]);
    }
} else { 
    echo json_encode(['success'=>false,'message'=>'Invalid action']); 
}
