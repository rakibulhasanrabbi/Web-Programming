<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $stmt = $pdo->prepare("INSERT INTO programs (name,university,country,degree_level,tuition,deadline,duration,description) VALUES (?,?,?,?,?,?,?,?)");
    $result = $stmt->execute([$_POST['name'],$_POST['university'],$_POST['country'],$_POST['degree_level'],$_POST['tuition'],$_POST['deadline'] ?: null,$_POST['duration'],$_POST['description']]);
    echo json_encode(['success'=>$result]);
} elseif ($action === 'edit') {
    $stmt = $pdo->prepare("UPDATE programs SET name=?,university=?,country=?,degree_level=?,tuition=?,deadline=?,duration=?,description=? WHERE id=?");
    $result = $stmt->execute([$_POST['name'],$_POST['university'],$_POST['country'],$_POST['degree_level'],$_POST['tuition'],$_POST['deadline'] ?: null,$_POST['duration'],$_POST['description'],$_POST['id']]);
    echo json_encode(['success'=>$result]);
} elseif ($action === 'delete') {
    $stmt = $pdo->prepare("DELETE FROM programs WHERE id=?");
    echo json_encode(['success'=>$stmt->execute([$_POST['id']])]);
} else {
    echo json_encode(['success'=>false,'message'=>'Invalid action']);
}
