<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';
if ($action === 'notify') {
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
    echo json_encode(['success'=>$stmt->execute([$_POST['user_id'], $_POST['message']])]);
} elseif ($action === 'delete') {
    echo json_encode(['success'=>$pdo->prepare("DELETE FROM users WHERE id=? AND role='user'")->execute([$_POST['id']])]);
} elseif ($action === 'suspend') {
    $stmt = $pdo->prepare("UPDATE users SET status='suspended' WHERE id=? AND role='user'");
    echo json_encode(['success'=>$stmt->execute([$_POST['id']])]);
} elseif ($action === 'resume') {
    $stmt = $pdo->prepare("UPDATE users SET status='active' WHERE id=? AND role='user'");
    echo json_encode(['success'=>$stmt->execute([$_POST['id']])]);
} else { echo json_encode(['success'=>false,'message'=>'Invalid action']); }
