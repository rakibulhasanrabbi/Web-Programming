<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';
if ($action === 'add') {
    $stmt = $pdo->prepare("INSERT INTO scholarships (title,provider,amount,deadline,description) VALUES (?,?,?,?,?)");
    echo json_encode(['success'=>$stmt->execute([$_POST['title'],$_POST['provider'],$_POST['amount'],$_POST['deadline'] ?: null,$_POST['description']])]);
} elseif ($action === 'edit') {
    $stmt = $pdo->prepare("UPDATE scholarships SET title=?,provider=?,amount=?,deadline=?,description=? WHERE id=?");
    echo json_encode(['success'=>$stmt->execute([$_POST['title'],$_POST['provider'],$_POST['amount'],$_POST['deadline'] ?: null,$_POST['description'],$_POST['id']])]);
} elseif ($action === 'delete') {
    echo json_encode(['success'=>$pdo->prepare("DELETE FROM scholarships WHERE id=?")->execute([$_POST['id']])]);
} else { echo json_encode(['success'=>false,'message'=>'Invalid action']); }
