<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');

$action = $_POST['action'] ?? '';
$adminId = $_SESSION['user_id'];

if (empty($action)) {
    echo json_encode(['success' => false, 'message' => 'No action specified.']);
    exit;
}

try {
    if ($action === 'update_status') {
        $appId = intval($_POST['id'] ?? 0);
        $newStatus = trim($_POST['status'] ?? '');
        $comments = trim($_POST['comments'] ?? '');

        if ($appId <= 0 || empty($newStatus)) {
            echo json_encode(['success' => false, 'message' => 'Invalid parameters.']);
            exit;
        }

        // Fetch application details to log previous status
        $stmt = $pdo->prepare("SELECT status, user_id, program_name, university_name FROM applications WHERE id = ?");
        $stmt->execute([$appId]);
        $app = $stmt->fetch();

        if (!$app) {
            echo json_encode(['success' => false, 'message' => 'Application not found.']);
            exit;
        }

        $oldStatus = $app['status'];

        $pdo->beginTransaction();

        // 1. Update status in database
        $up_stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ?");
        $up_stmt->execute([$newStatus, $appId]);

        // 2. Append audit trail in status_history
        $hist_stmt = $pdo->prepare("
            INSERT INTO status_history (application_id, old_status, new_status, changed_by, comments) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $hist_stmt->execute([
            $appId, 
            $oldStatus, 
            $newStatus, 
            $adminId, 
            !empty($comments) ? $comments : "Status updated by counselor/admin."
        ]);

        // 3. Dispatch user notification
        $notif_msg = "Your application for " . $app['program_name'] . " at " . $app['university_name'] . " has been updated from " . $oldStatus . " to " . $newStatus . ".";
        if (!empty($comments)) {
            $notif_msg .= " Comments: \"" . $comments . "\"";
        }
        
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $notif_stmt->execute([$app['user_id'], $notif_msg]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Application status successfully updated!']);
        exit;
    } 
    
    elseif ($action === 'assign_counselor') {
        $appId = intval($_POST['id'] ?? 0);
        $counselorId = intval($_POST['counselor_id'] ?? 0);

        if ($appId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid application ID.']);
            exit;
        }

        // Fetch application details
        $stmt = $pdo->prepare("SELECT user_id, program_name, university_name, counselor_id, status FROM applications WHERE id = ?");
        $stmt->execute([$appId]);
        $app = $stmt->fetch();

        if (!$app) {
            echo json_encode(['success' => false, 'message' => 'Application not found.']);
            exit;
        }

        $counselor_name = 'Unassigned';
        if ($counselorId > 0) {
            // Verify counselor exists
            $c_stmt = $pdo->prepare("SELECT full_name FROM users WHERE id = ? AND role IN ('counselor', 'admin')");
            $c_stmt->execute([$counselorId]);
            $counselor_name = $c_stmt->fetchColumn() ?: 'Unassigned';
            if ($counselor_name === 'Unassigned') {
                echo json_encode(['success' => false, 'message' => 'Selected counselor does not exist.']);
                exit;
            }
        }

        $pdo->beginTransaction();

        // 1. Update Counselor in database
        $up_stmt = $pdo->prepare("UPDATE applications SET counselor_id = ? WHERE id = ?");
        $up_stmt->execute([$counselorId ?: null, $appId]);

        // 2. Log in status history
        $log_comments = "Assigned Study Abroad Counselor: " . $counselor_name;
        $hist_stmt = $pdo->prepare("
            INSERT INTO status_history (application_id, old_status, new_status, changed_by, comments) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $hist_stmt->execute([$appId, $app['status'], $app['status'], $adminId, $log_comments]);

        // 3. Dispatch user notification
        $notif_msg = "A personal Study Abroad Counselor (" . $counselor_name . ") has been assigned to support your application for " . $app['program_name'] . " at " . $app['university_name'] . ".";
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $notif_stmt->execute([$app['user_id'], $notif_msg]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Counselor assigned successfully!']);
        exit;
    } 
    
    elseif ($action === 'add_note') {
        $appId = intval($_POST['id'] ?? 0);
        $noteText = trim($_POST['note_text'] ?? '');

        if ($appId <= 0 || empty($noteText)) {
            echo json_encode(['success' => false, 'message' => 'Missing note details.']);
            exit;
        }

        $stmt = $pdo->prepare("INSERT INTO notes (application_id, author_id, note_text) VALUES (?, ?, ?)");
        $stmt->execute([$appId, $adminId, $noteText]);

        echo json_encode(['success' => true, 'message' => 'Internal note added!']);
        exit;
    } 
    
    elseif ($action === 'request_doc') {
        $appId = intval($_POST['id'] ?? 0);
        $docName = trim($_POST['doc_name'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if ($appId <= 0 || empty($docName)) {
            echo json_encode(['success' => false, 'message' => 'Document name is required.']);
            exit;
        }

        // Fetch application to find user_id
        $stmt = $pdo->prepare("SELECT user_id, program_name, status FROM applications WHERE id = ?");
        $stmt->execute([$appId]);
        $app = $stmt->fetch();

        if (!$app) {
            echo json_encode(['success' => false, 'message' => 'Application not found.']);
            exit;
        }

        $pdo->beginTransaction();

        // 1. Create document request record in documents
        $doc_stmt = $pdo->prepare("
            INSERT INTO documents (application_id, name, file_path, status, admin_message) 
            VALUES (?, ?, '', 'pending_upload', ?)
        ");
        $doc_stmt->execute([$appId, $docName, $description]);

        // 2. Set application status to Documents Required automatically to notify student
        $up_stmt = $pdo->prepare("UPDATE applications SET status = 'Documents Required' WHERE id = ?");
        $up_stmt->execute([$appId]);

        // 3. Log this action in status_history
        $log_comment = "Requested Supporting Credential: " . $docName;
        if (!empty($description)) {
            $log_comment .= " (Instructions: " . $description . ")";
        }
        $hist_stmt = $pdo->prepare("
            INSERT INTO status_history (application_id, old_status, new_status, changed_by, comments) 
            VALUES (?, ?, 'Documents Required', ?, ?)
        ");
        $hist_stmt->execute([$appId, $app['status'], 'Documents Required', $adminId, $log_comment]);

        // 4. Send high-priority notification to the student
        $notif_msg = "Action Needed: Additional document '" . $docName . "' is required for your application for " . $app['program_name'] . ". Please log in to upload it.";
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $notif_stmt->execute([$app['user_id'], $notif_msg]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Additional document request dispatched successfully!']);
        exit;
    } 
    
    elseif ($action === 'update_doc_status') {
        $docId = intval($_POST['doc_id'] ?? 0);
        $docStatus = trim($_POST['status'] ?? '');
        $feedback = trim($_POST['feedback'] ?? '');

        if ($docId <= 0 || !in_array($docStatus, ['verified', 'rejected'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid parameters.']);
            exit;
        }

        // Fetch document info
        $d_stmt = $pdo->prepare("
            SELECT d.*, a.user_id, a.program_name, a.status as app_status 
            FROM documents d 
            JOIN applications a ON d.application_id = a.id 
            WHERE d.id = ?
        ");
        $d_stmt->execute([$docId]);
        $doc = $d_stmt->fetch();

        if (!$doc) {
            echo json_encode(['success' => false, 'message' => 'Document record not found.']);
            exit;
        }

        $pdo->beginTransaction();

        // 1. Update document status
        $up_stmt = $pdo->prepare("UPDATE documents SET status = ?, admin_message = ? WHERE id = ?");
        $up_stmt->execute([$docStatus, $feedback ?: null, $docId]);

        // 2. Log in status history
        $log_comment = "Reviewed Credential '" . $doc['name'] . "' ➔ Status: " . ucfirst($docStatus);
        if (!empty($feedback)) {
            $log_comment .= " (Notes: " . $feedback . ")";
        }
        $hist_stmt = $pdo->prepare("
            INSERT INTO status_history (application_id, old_status, new_status, changed_by, comments) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $hist_stmt->execute([$doc['application_id'], $doc['app_status'], $doc['app_status'], $adminId, $log_comment]);

        // 3. Notify student
        $notif_msg = "Your uploaded document '" . $doc['name'] . "' has been " . ($docStatus === 'verified' ? 'Verified ✓' : 'Rejected ✗') . ".";
        if (!empty($feedback) && $docStatus === 'rejected') {
            $notif_msg .= " Feedback: \"" . $feedback . "\"";
        }
        $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        $notif_stmt->execute([$doc['user_id'], $notif_msg]);

        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Document review saved successfully!']);
        exit;
    } 
    
    else {
        echo json_encode(['success' => false, 'message' => 'Action not implemented.']);
        exit;
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'API Database Error: ' . $e->getMessage()]);
    exit;
}
?>
