<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';
if ($action === 'update_status') {
    $stmt = $pdo->prepare("UPDATE event_requests SET status=? WHERE id=?");
    $result = $stmt->execute([$_POST['status'], $_POST['id']]);
    // Send notification to user
    if ($result && $_POST['status'] === 'approved') {
        $msg = "🎉 Your request to join '{$_POST['event_title']}' has been approved! Event Details: Date: {$_POST['event_date']}, Time: {$_POST['event_time']}, Location: {$_POST['event_location']}";
        $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)")->execute([$_POST['user_id'], $msg]);
    } elseif ($result && $_POST['status'] === 'rejected') {
        $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)")->execute([$_POST['user_id'], "Your event join request has been declined. Please contact support for more information."]);
    }
    echo json_encode(['success' => $result]);
} else { echo json_encode(['success'=>false,'message'=>'Invalid action']); }
