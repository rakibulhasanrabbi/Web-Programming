<?php
require_once '../includes/auth_check.php';
header('Content-Type: application/json');
$action = $_POST['action'] ?? '';
if ($action === 'add') {
    $stmt = $pdo->prepare("INSERT INTO events (title,event_type,event_date,event_time,location,max_participants,description,status) VALUES (?,?,?,?,?,?,?,?)");
    echo json_encode(['success'=>$stmt->execute([$_POST['title'],$_POST['event_type'],$_POST['event_date'],$_POST['event_time'],$_POST['location'],$_POST['max_participants'],$_POST['description'],$_POST['status']])]);
} elseif ($action === 'edit') {
    $stmt = $pdo->prepare("UPDATE events SET title=?,event_type=?,event_date=?,event_time=?,location=?,max_participants=?,description=?,status=? WHERE id=?");
    echo json_encode(['success'=>$stmt->execute([$_POST['title'],$_POST['event_type'],$_POST['event_date'],$_POST['event_time'],$_POST['location'],$_POST['max_participants'],$_POST['description'],$_POST['status'],$_POST['id']])]);
} elseif ($action === 'delete') {
    echo json_encode(['success'=>$pdo->prepare("DELETE FROM events WHERE id=?")->execute([$_POST['id']])]);
} else { echo json_encode(['success'=>false,'message'=>'Invalid action']); }
