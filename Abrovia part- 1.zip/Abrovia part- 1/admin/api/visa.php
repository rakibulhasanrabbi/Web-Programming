<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth_check.php';

$action = $_REQUEST['action'] ?? '';

if ($action === 'list') {
    try {
        $stmt = $pdo->query("
            SELECT vr.*, u.full_name as user_full_name, u.email as user_email 
            FROM visa_requests vr
            JOIN users u ON vr.user_id = u.id
            ORDER BY vr.created_at DESC
        ");
        $requests = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $requests]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'update_verification') {
    $id = intval($_POST['id'] ?? 0);
    $info_verified = intval($_POST['info_verified'] ?? 0);
    $docs_verified = intval($_POST['docs_verified'] ?? 0);

    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid Request ID.']);
        exit;
    }

    try {
        // Fetch current status
        $stmt = $pdo->prepare("SELECT status FROM visa_requests WHERE id = ?");
        $stmt->execute([$id]);
        $currStatus = $stmt->fetchColumn();

        // Auto-advance status if both verified
        $status = $currStatus;
        if ($currStatus === 'pending' && $info_verified === 1 && $docs_verified === 1) {
            $status = 'documents_verified';
        } else if ($currStatus === 'documents_verified' && ($info_verified === 0 || $docs_verified === 0)) {
            $status = 'pending';
        }

        $stmt = $pdo->prepare("
            UPDATE visa_requests 
            SET info_verified = ?, docs_verified = ?, status = ?
            WHERE id = ?
        ");
        $stmt->execute([$info_verified, $docs_verified, $status, $id]);

        echo json_encode(['success' => true, 'message' => 'Verification status updated!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'submit_embassy') {
    $id = intval($_POST['id'] ?? 0);

    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid Request ID.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            UPDATE visa_requests 
            SET embassy_submitted = 1, status = 'submitted_to_embassy'
            WHERE id = ?
        ");
        $stmt->execute([$id]);

        // Create notification
        $stmt_info = $pdo->prepare("SELECT user_id, country FROM visa_requests WHERE id = ?");
        $stmt_info->execute([$id]);
        $req = $stmt_info->fetch();

        if ($req) {
            $notif_msg = "Your final visa application for " . $req['country'] . " has been submitted to the Embassy. Status: Embassy Review.";
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
            $notif_stmt->execute([$req['user_id'], $notif_msg]);
        }

        echo json_encode(['success' => true, 'message' => 'Visa request status updated: Submitted to Embassy.']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'finalize') {
    $id = intval($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? ''; // approved or rejected

    if ($id <= 0 || !in_array($status, ['approved', 'rejected'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid parameters.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("UPDATE visa_requests SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);

        // Create notification
        $stmt_info = $pdo->prepare("SELECT user_id, country FROM visa_requests WHERE id = ?");
        $stmt_info->execute([$id]);
        $req = $stmt_info->fetch();

        if ($req) {
            $notif_msg = "Your visa request for " . $req['country'] . " has been " . strtoupper($status) . ". Check your visa center portal for details.";
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
            $notif_stmt->execute([$req['user_id'], $notif_msg]);
        }

        echo json_encode(['success' => true, 'message' => 'Visa request status finalized as: ' . $status]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;

} else if ($action === 'save_notes') {
    $id = intval($_POST['id'] ?? 0);
    $notes = $_POST['admin_notes'] ?? '';

    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid Request ID.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("UPDATE visa_requests SET admin_notes = ? WHERE id = ?");
        $stmt->execute([$notes, $id]);
        echo json_encode(['success' => true, 'message' => 'Counselor notes saved successfully.']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
