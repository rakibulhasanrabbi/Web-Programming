<?php
$current_admin_page = 'dashboard';
require_once 'includes/auth_check.php';

// Fetch real stats
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();
$totalApps = $pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn();
$totalPrograms = $pdo->query("SELECT COUNT(*) FROM programs")->fetchColumn();
$totalScholarships = $pdo->query("SELECT COUNT(*) FROM scholarships")->fetchColumn();
$totalEvents = $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
$pendingRequests = $pdo->query("SELECT COUNT(*) FROM event_requests WHERE status='pending'")->fetchColumn();
$totalEnrollments = $pdo->query("SELECT COUNT(*) FROM enrollments")->fetchColumn();
$courseRevenue = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE status='completed'")->fetchColumn();

// Recent applications
$recentApps = $pdo->query("SELECT a.*, u.full_name, u.email FROM applications a JOIN users u ON a.user_id = u.id ORDER BY a.applied_at DESC LIMIT 5")->fetchAll();

// Recent users
$recentUsers = $pdo->query("SELECT * FROM users WHERE role='user' ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Abrovia</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>

    <main class="admin-main">
        <div class="page-header">
            <h1 class="page-title">Dashboard</h1>
            <p class="page-subtitle">Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>. Here's your portal overview.</p>
        </div>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon blue"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></div>
                </div>
                <div class="stat-value"><?php echo number_format($totalUsers); ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon purple"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>
                </div>
                <div class="stat-value"><?php echo number_format($totalApps); ?></div>
                <div class="stat-label">Applications</div>
            </div>
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon teal"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg></div>
                </div>
                <div class="stat-value"><?php echo number_format($totalPrograms); ?></div>
                <div class="stat-label">Programs</div>
            </div>
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon green"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/></svg></div>
                </div>
                <div class="stat-value"><?php echo number_format($totalScholarships); ?></div>
                <div class="stat-label">Scholarships</div>
            </div>
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon orange"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/></svg></div>
                </div>
                <div class="stat-value"><?php echo number_format($totalEvents); ?></div>
                <div class="stat-label">Events</div>
            </div>
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon red"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></div>
                </div>
                <div class="stat-value"><?php echo number_format($pendingRequests); ?></div>
                <div class="stat-label">Pending Requests</div>
            </div>
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon purple"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg></div>
                </div>
                <div class="stat-value"><?php echo number_format($totalEnrollments); ?></div>
                <div class="stat-label">Course Enrollments</div>
            </div>
            <div class="stat-card">
                <div class="stat-top">
                    <div class="stat-icon green"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div>
                </div>
                <div class="stat-value">৳<?php echo number_format($courseRevenue); ?></div>
                <div class="stat-label">Course Revenue</div>
            </div>
        </div>

        <!-- Recent Applications -->
        <div class="data-table-wrap">
            <div class="table-header">
                <h2 class="table-title">Recent Applications</h2>
                <a href="manage-applications.php" class="btn btn-outline btn-sm">View All</a>
            </div>
            <table class="data-table">
                <thead><tr><th>Student</th><th>Program</th><th>University</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                    <?php if (empty($recentApps)): ?>
                        <tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:30px;">No applications yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recentApps as $app): ?>
                        <tr>
                            <td style="color:var(--text-primary);font-weight:500;"><?php echo htmlspecialchars($app['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($app['program_name']); ?></td>
                            <td><?php echo htmlspecialchars($app['university_name']); ?></td>
                            <td><span class="badge <?php echo $app['status']; ?>"><?php echo $app['status']; ?></span></td>
                            <td><?php echo date('M d, Y', strtotime($app['applied_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Recent Users -->
        <div class="data-table-wrap">
            <div class="table-header">
                <h2 class="table-title">Recent Signups</h2>
                <a href="manage-users.php" class="btn btn-outline btn-sm">View All</a>
            </div>
            <table class="data-table">
                <thead><tr><th>Name</th><th>Email</th><th>Joined</th></tr></thead>
                <tbody>
                    <?php if (empty($recentUsers)): ?>
                        <tr><td colspan="3" style="text-align:center;color:var(--text-muted);padding:30px;">No users yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($recentUsers as $u): ?>
                        <tr>
                            <td style="color:var(--text-primary);font-weight:500;"><?php echo htmlspecialchars($u['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($u['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
</body>
</html>
