<?php
// Admin auth check - include at top of every admin page
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'counselor'])) {
    header('Location: ../admin-login.php');
    exit;
}
require_once __DIR__ . '/../../config/database.php';
?>
