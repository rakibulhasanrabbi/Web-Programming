<?php
$current_admin_page = 'admins';
require_once 'includes/auth_check.php';
$admins = $pdo->query("SELECT * FROM users WHERE role='admin' ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admins - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;">
            <div><h1 class="page-title">Manage Admins</h1><p class="page-subtitle">Add new administrators or remove existing ones.</p></div>
            <button class="btn btn-primary" onclick="document.getElementById('modal').classList.add('show')">+ Add Admin</button>
        </div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>Name</th><th>Email</th><th>Joined</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach($admins as $a): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500;"><?= htmlspecialchars($a['full_name']) ?></td>
                        <td><?= htmlspecialchars($a['email']) ?></td>
                        <td><?= date('M d, Y', strtotime($a['created_at'])) ?></td>
                        <td>
                            <?php if($a['id'] !== $_SESSION['user_id']): ?>
                                <button class="btn btn-danger btn-sm" onclick="removeAdmin(<?= $a['id'] ?>)">Remove</button>
                            <?php else: ?>
                                <span class="badge green">You</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<div class="modal-overlay" id="modal">
    <div class="modal">
        <h3 class="modal-title">Add New Admin</h3>
        <form id="admin-form">
            <input type="hidden" name="action" value="add">
            <div class="form-group"><label class="form-label">Full Name</label><input class="form-input" name="full_name" required></div>
            <div class="form-group"><label class="form-label">Email</label><input type="email" class="form-input" name="email" required></div>
            <div class="form-group"><label class="form-label">Password</label><input type="password" class="form-input" name="password" required minlength="6"></div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="document.getElementById('modal').classList.remove('show')">Cancel</button><button type="submit" class="btn btn-primary">Create Admin</button></div>
        </form>
    </div>
</div>
<script>
document.getElementById('modal').addEventListener('click',function(e){if(e.target===this)this.classList.remove('show');});
document.getElementById('admin-form').addEventListener('submit',function(e){e.preventDefault();fetch('api/admins.php',{method:'POST',body:new FormData(this)}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else alert(d.message);});});
function removeAdmin(id){if(!confirm('Remove this admin?'))return;const fd=new FormData();fd.append('action','delete');fd.append('id',id);fetch('api/admins.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();});}
</script>
</body></html>
