<?php
$current_admin_page = 'courses';
require_once 'includes/auth_check.php';

// Fetch courses with enrollment & revenue stats
$coursesQuery = $pdo->query("
    SELECT c.*, 
        (SELECT COUNT(*) FROM enrollments WHERE course_id = c.id) as enrolled_count,
        (SELECT COALESCE(SUM(amount), 0) FROM payments WHERE course_id = c.id AND status = 'completed') as total_revenue
    FROM courses c 
    ORDER BY c.id ASC
");
$courses = $coursesQuery->fetchAll();

// Fetch enrollments
$enrollmentsQuery = $pdo->query("
    SELECT e.*, u.full_name, u.email, c.name as course_name, c.slug as course_slug, p.amount, p.status as payment_status, p.paid_at 
    FROM enrollments e 
    JOIN users u ON e.user_id = u.id 
    JOIN courses c ON e.course_id = c.id 
    LEFT JOIN payments p ON e.payment_id = p.id 
    ORDER BY e.enrolled_at DESC
");
$enrollments = $enrollmentsQuery->fetchAll();

// Fetch payments
$paymentsQuery = $pdo->query("
    SELECT p.*, u.full_name, u.email, c.name as course_name 
    FROM payments p 
    JOIN users u ON p.user_id = u.id 
    JOIN courses c ON p.course_id = c.id 
    ORDER BY p.paid_at DESC
");
$payments = $paymentsQuery->fetchAll();

// Calculate totals
$totalEnrollments = count($enrollments);
$totalRevenue = array_sum(array_column($payments, 'amount'));
$activeCourses = count(array_filter($courses, fn($c) => $c['status'] === 'active'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Prep Course Management - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Modern tabs styling */
        .admin-tabs {
            display: flex;
            gap: 12px;
            margin-bottom: 30px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 15px;
        }
        .tab-btn {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            color: var(--text-muted);
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        .tab-btn:hover {
            color: var(--text-white);
            background: rgba(255, 255, 255, 0.08);
        }
        .tab-btn.active {
            background: var(--accent);
            color: #fff;
            border-color: var(--accent);
            box-shadow: 0 4px 12px rgba(124, 58, 237, 0.25);
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
            animation: fadeIn 0.4s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Stat cards grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            position: relative;
        }
        .stat-card .stat-value {
            font-size: 2.2rem;
            font-weight: 800;
            color: #fff;
            margin-bottom: 4px;
        }
        .stat-card .stat-label {
            color: var(--text-muted);
            font-size: 0.85rem;
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        /* Dynamic form and panel style */
        .admin-form-group {
            margin-bottom: 20px;
        }
        .admin-form-group label {
            display: block;
            color: var(--text-white);
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 8px;
        }
        .admin-form-control {
            width: 100%;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            color: var(--text-white);
            padding: 12px;
            border-radius: 8px;
            font-family: inherit;
            font-size: 0.9rem;
        }
        .admin-form-control:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.15);
        }
        
        .content-manager-section {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 30px;
            margin-top: 40px;
        }

        .nested-form-box {
            background: rgba(255, 255, 255, 0.02);
            border: 1px dashed var(--border);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .filter-row {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }

        /* Course list layout */
        .courses-overview-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        .course-summary-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            display: flex;
            flex-direction: column;
        }
        .course-summary-title {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .course-summary-stat-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            border-bottom: 1px solid rgba(255,255,255,0.04);
            font-size: 0.88rem;
            color: var(--text-muted);
        }
        .course-summary-stat-row strong {
            color: var(--text-white);
        }
        .course-summary-actions {
            margin-top: auto;
            padding-top: 15px;
            display: flex;
            gap: 8px;
        }

        .badge-status {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: capitalize;
        }
        .badge-status.active { background: rgba(34, 197, 94, 0.15); color: #22c55e; }
        .badge-status.inactive { background: rgba(239, 68, 68, 0.15); color: #ef4444; }
        .badge-status.suspended { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
        .badge-status.removed { background: rgba(156, 163, 175, 0.15); color: #9ca3af; }

        .btn-panel-action {
            display: inline-block;
            text-decoration: none;
            padding: 8px 12px;
            font-size: 0.82rem;
            font-weight: 600;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .btn-panel-edit { background: var(--accent); color: white; }
        .btn-panel-edit:hover { background: #6d28d9; }
        .btn-panel-deactivate { background: rgba(239, 68, 68, 0.1); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
        .btn-panel-deactivate:hover { background: rgba(239, 68, 68, 0.2); }
        .btn-panel-activate { background: rgba(34, 197, 94, 0.1); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.3); }
        .btn-panel-activate:hover { background: rgba(34, 197, 94, 0.2); }

        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }

        .content-list-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.88rem;
        }
        .content-list-table th, .content-list-table td {
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        .content-list-table th {
            color: var(--text-muted);
            font-weight: 600;
        }
    </style>
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>

    <main class="admin-main">
        <div class="page-header">
            <h1 class="page-title">Test Prep Management</h1>
            <p class="page-subtitle">Configure courses, add prep center learning contents, manage user access, and track course sales payments.</p>
        </div>

        <!-- TABS BAR -->
        <div class="admin-tabs">
            <button class="tab-btn active" data-tab="tab-overview" onclick="switchTab('tab-overview')">Course Overview</button>
            <button class="tab-btn" data-tab="tab-enrollments" onclick="switchTab('tab-enrollments')">Enrolled Students</button>
            <button class="tab-btn" data-tab="tab-payments" onclick="switchTab('tab-payments')">Payment Transactions</button>
            <button class="tab-btn" data-tab="tab-creator" id="creatorTabBtn" onclick="prepareCreateMode()">Create Course</button>
        </div>

        <!-- TAB 1: COURSE OVERVIEW -->
        <div class="tab-content active" id="tab-overview">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?= $activeCourses ?></div>
                    <div class="stat-label">Active Courses</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?= $totalEnrollments ?></div>
                    <div class="stat-label">Total Student Enrollments</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">৳<?= number_format($totalRevenue, 2) ?></div>
                    <div class="stat-label">Course Revenues</div>
                </div>
            </div>

            <div class="courses-overview-grid">
                <?php foreach ($courses as $c): ?>
                    <div class="course-summary-card">
                        <div class="course-summary-title">
                            <?= htmlspecialchars($c['name']) ?>
                            <span class="badge-status <?= $c['status'] ?>" style="margin-left: 8px;"><?= $c['status'] ?></span>
                        </div>
                        <p style="font-size: 0.82rem; color: var(--text-muted); margin-bottom: 15px; flex-grow: 1;">
                            <?= htmlspecialchars(substr($c['description'], 0, 100)) ?>...
                        </p>
                        
                        <div class="course-summary-stat-row">
                            <span>Slug URL:</span>
                            <strong>/prep-center.php?course=<?= htmlspecialchars($c['slug']) ?></strong>
                        </div>
                        <div class="course-summary-stat-row">
                            <span>Course Fee:</span>
                            <strong>৳<?= number_format($c['price'], 2) ?></strong>
                        </div>
                        <div class="course-summary-stat-row">
                            <span>Duration:</span>
                            <strong><?= intval($c['duration_weeks']) ?> Weeks</strong>
                        </div>
                        <div class="course-summary-stat-row">
                            <span>Enrollments:</span>
                            <strong><?= intval($c['enrolled_count']) ?> Students</strong>
                        </div>
                        <div class="course-summary-stat-row">
                            <span>Revenues:</span>
                            <strong>৳<?= number_format($c['total_revenue'], 2) ?></strong>
                        </div>

                        <div class="course-summary-actions">
                            <button class="btn-panel-action btn-panel-edit" onclick="prepareEditMode(<?= htmlspecialchars(json_encode($c)) ?>)">Edit / Add Content</button>
                            <?php if ($c['status'] === 'active'): ?>
                                <button class="btn-panel-action btn-panel-deactivate" onclick="toggleCourseStatus(<?= $c['id'] ?>, 'inactive')">Deactivate</button>
                            <?php else: ?>
                                <button class="btn-panel-action btn-panel-activate" onclick="toggleCourseStatus(<?= $c['id'] ?>, 'active')">Activate</button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- TAB 2: ENROLLED STUDENTS -->
        <div class="tab-content" id="tab-enrollments">
            <div class="filter-row">
                <div class="admin-form-group" style="margin-bottom:0; flex-grow:1;">
                    <input type="text" id="searchEnrollments" class="admin-form-control" placeholder="Search by student name or email..." oninput="filterEnrollmentsTable()">
                </div>
                <div class="admin-form-group" style="margin-bottom:0; width: 220px;">
                    <select id="filterEnrollmentCourse" class="admin-form-control" onchange="filterEnrollmentsTable()">
                        <option value="">All Courses</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= htmlspecialchars($c['name']) ?>"><?= htmlspecialchars($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="data-table-wrap">
                <table class="data-table" id="enrollmentsTable">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Email</th>
                            <th>Enrolled Course</th>
                            <th>Enrolled Date</th>
                            <th>Payment Status</th>
                            <th>Access Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($enrollments)): ?>
                            <tr><td colspan="7" class="empty-state">No students enrolled yet.</td></tr>
                        <?php else: foreach ($enrollments as $e): ?>
                            <tr class="enrollment-row">
                                <td class="student-name" style="color:var(--text-primary); font-weight:600;"><?= htmlspecialchars($e['full_name']) ?></td>
                                <td class="student-email"><?= htmlspecialchars($e['email']) ?></td>
                                <td class="course-name" style="color:var(--accent); font-weight:600;"><?= htmlspecialchars($e['course_name']) ?></td>
                                <td><?= date('M d, Y', strtotime($e['enrolled_at'])) ?></td>
                                <td>
                                    <?php if ($e['payment_status'] === 'completed'): ?>
                                        <span class="badge completed">Completed (৳<?= number_format($e['amount']) ?>)</span>
                                    <?php else: ?>
                                        <span class="badge pending">Demo Free</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge-status <?= $e['status'] ?>"><?= $e['status'] ?></span>
                                </td>
                                <td>
                                    <?php if ($e['status'] === 'active'): ?>
                                        <button class="btn btn-danger btn-sm" onclick="updateEnrollmentAccess(<?= $e['id'] ?>, 'suspended')">Suspend Access</button>
                                    <?php else: ?>
                                        <button class="btn btn-success btn-sm" onclick="updateEnrollmentAccess(<?= $e['id'] ?>, 'active')">Restore Access</button>
                                    <?php endif; ?>
                                    <button class="btn btn-outline btn-sm" onclick="updateEnrollmentAccess(<?= $e['id'] ?>, 'removed')" style="border-color: rgba(239, 68, 68, 0.4); color: #f87171;">Revoke Enrollment</button>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TAB 3: PAYMENT TRANSACTIONS -->
        <div class="tab-content" id="tab-payments">
            <div class="filter-row" style="justify-content: flex-end;">
                <div class="admin-form-group" style="margin-bottom:0; width: 220px;">
                    <select id="filterPaymentsCourse" class="admin-form-control" onchange="filterPaymentsTable()">
                        <option value="">All Courses</option>
                        <?php foreach ($courses as $c): ?>
                            <option value="<?= htmlspecialchars($c['name']) ?>"><?= htmlspecialchars($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="data-table-wrap">
                <table class="data-table" id="paymentsTable">
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Student</th>
                            <th>Email</th>
                            <th>Course</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Status</th>
                            <th>Paid Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($payments)): ?>
                            <tr><td colspan="8" class="empty-state">No transactions recorded yet.</td></tr>
                        <?php else: foreach ($payments as $p): ?>
                            <tr class="payment-row">
                                <td style="font-family: monospace; font-weight: 600; color: #a78bfa;"><?= htmlspecialchars($p['transaction_id']) ?></td>
                                <td style="color:var(--text-primary); font-weight:600;"><?= htmlspecialchars($p['full_name']) ?></td>
                                <td><?= htmlspecialchars($p['email']) ?></td>
                                <td class="payment-course-name" style="color:var(--accent); font-weight:600;"><?= htmlspecialchars($p['course_name']) ?></td>
                                <td style="font-weight: 700; color: #fff;">৳<?= number_format($p['amount'], 2) ?></td>
                                <td><span style="text-transform: uppercase; font-size: 0.8rem;"><?= htmlspecialchars($p['payment_method']) ?></span></td>
                                <td><span class="badge completed"><?= htmlspecialchars($p['status']) ?></span></td>
                                <td><?= date('M d, Y H:i', strtotime($p['paid_at'])) ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- TAB 4: ADD/EDIT COURSE CREATOR -->
        <div class="tab-content" id="tab-creator">
            <div class="stats-card" style="display: block; width: 100%; border-radius: 12px; margin-bottom: 20px;">
                <h2 id="creatorTitle" style="margin-bottom: 20px; font-size: 1.4rem;">Create New Test Preparation Course</h2>
                
                <form id="courseForm">
                    <input type="hidden" id="courseIdInput" name="id" value="">
                    
                    <div class="form-row">
                        <div class="admin-form-group">
                            <label for="courseName">Course Name</label>
                            <input type="text" id="courseName" name="name" class="admin-form-control" required placeholder="e.g. TOEFL Preparation" oninput="generateSlug()">
                        </div>
                        <div class="admin-form-group">
                            <label for="courseSlug">URL Slug</label>
                            <input type="text" id="courseSlug" name="slug" class="admin-form-control" required placeholder="e.g. toefl">
                        </div>
                    </div>

                    <div class="admin-form-group">
                        <label for="courseDescription">Course Description</label>
                        <textarea id="courseDescription" name="description" class="admin-form-control" rows="4" required placeholder="Provide a detailed description of what the course covers..."></textarea>
                    </div>

                    <div class="form-row">
                        <div class="admin-form-group">
                            <label for="coursePrice">Price (BDT ৳)</label>
                            <input type="number" id="coursePrice" name="price" class="admin-form-control" min="0" required placeholder="e.g. 12000">
                        </div>
                        <div class="admin-form-group">
                            <label for="courseDuration">Duration (Weeks)</label>
                            <input type="number" id="courseDuration" name="duration_weeks" class="admin-form-control" min="1" required placeholder="e.g. 8">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="admin-form-group">
                            <label for="courseStatus">Visibility Status</label>
                            <select id="courseStatus" name="status" class="admin-form-control">
                                <option value="active">Active (Visible to Students)</option>
                                <option value="inactive">Inactive (Hidden)</option>
                            </select>
                        </div>
                    </div>

                    <div class="admin-form-group">
                        <label for="courseFeatures">Course Features / Bullet Points (One per line)</label>
                        <textarea id="courseFeatures" name="features" class="admin-form-control" rows="5" placeholder="Real Exam Interface Simulation&#10;Expert Graded Essays&#10;Integrated Task Strategies"></textarea>
                    </div>

                    <div style="display:flex; gap: 10px;">
                        <button type="submit" class="btn btn-primary" id="btnCourseFormSubmit">Create Course</button>
                        <button type="button" class="btn btn-outline" onclick="switchTab('tab-overview')">Cancel</button>
                    </div>
                </form>
            </div>

            <!-- CONTENT MANAGER (Only visible in edit mode) -->
            <div class="content-manager-section" id="contentManagerSection" style="display: none;">
                <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 8px;">Course Content Manager</h3>
                <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 25px;">Add videos, practice mocks, documents, and viva sessions to this course.</p>

                <!-- ADD CONTENT SUB-FORM -->
                <div class="nested-form-box">
                    <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 15px; color: var(--accent);">Add Content Resource</h4>
                    <form id="contentForm">
                        <input type="hidden" id="contentCourseId" name="course_id" value="">
                        <input type="hidden" id="contentId" name="id" value="">
                        
                        <div class="form-row">
                            <div class="admin-form-group">
                                <label for="contentType">Resource Category</label>
                                <select id="contentType" name="type" class="admin-form-control" required>
                                    <option value="material">Course Material / PDF Document</option>
                                    <option value="book">Book & Guide</option>
                                    <option value="practice_question">Practice Question Set</option>
                                    <option value="viva">Practice Viva Prep</option>
                                    <option value="recorded_class">Recorded Video Lecture</option>
                                    <option value="live_class">Live Class Scheduled</option>
                                    <option value="practice_exam">Practice Mock Exam</option>
                                </select>
                            </div>
                            <div class="admin-form-group">
                                <label for="contentTitle">Resource Title</label>
                                <input type="text" id="contentTitle" name="title" class="admin-form-control" required placeholder="e.g. Reading Section Diagnostic Mock">
                            </div>
                        </div>

                        <div class="admin-form-group">
                            <label for="contentDesc">Short Description</label>
                            <textarea id="contentDesc" name="description" class="admin-form-control" rows="2" placeholder="Describe the purpose, contents or requirements for this resource..."></textarea>
                        </div>

                        <div class="form-row">
                            <div class="admin-form-group">
                                <label for="contentUrl">Content URL / Download Link</label>
                                <input type="text" id="contentUrl" name="content_url" class="admin-form-control" placeholder="e.g. # or https://example.com/file.pdf" value="#">
                            </div>
                            <div class="admin-form-group">
                                <label for="contentDuration">Duration (Minutes, optional)</label>
                                <input type="number" id="contentDuration" name="duration_minutes" class="admin-form-control" min="1" placeholder="e.g. 60">
                            </div>
                        </div>

                        <div class="form-row" style="align-items: center;">
                            <div class="admin-form-group">
                                <label for="contentSortOrder">Sorting Order</label>
                                <input type="number" id="contentSortOrder" name="sort_order" class="admin-form-control" min="0" value="0">
                            </div>
                            <div class="admin-form-group" style="display: flex; align-items: center; padding-top: 25px;">
                                <label style="display: flex; align-items: center; cursor: pointer; gap: 8px; font-weight: normal; margin-bottom: 0;">
                                    <input type="checkbox" id="contentIsFree" name="is_free_preview" value="1" style="width: 18px; height: 18px;">
                                    <span>Enable Free Preview (Allowed for guest preview)</span>
                                </label>
                            </div>
                        </div>

                        <div style="display: flex; gap: 10px; margin-top: 15px;">
                            <button type="submit" class="btn btn-success" id="btnContentFormSubmit">Add Content Resource</button>
                            <button type="button" class="btn btn-outline" id="btnCancelContentEdit" style="display:none;" onclick="cancelContentEdit()">Cancel Edit</button>
                        </div>
                    </form>
                </div>

                <!-- TABLE OF CURRENT CONTENTS -->
                <div class="data-table-wrap">
                    <table class="content-list-table">
                        <thead>
                            <tr>
                                <th>Order</th>
                                <th>Category</th>
                                <th>Title</th>
                                <th>Duration</th>
                                <th>Preview</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="courseContentTableBody">
                            <!-- Populated dynamically via JS -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
// Switch tabs logic
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    
    document.getElementById(tabId).classList.add('active');
    const activeBtn = document.querySelector(`[data-tab="${tabId}"]`);
    if(activeBtn) {
        activeBtn.classList.add('active');
    }
}

// Generate URL slug from course title
function generateSlug() {
    const name = document.getElementById('courseName').value;
    const slug = name.toLowerCase()
        .replace(/[^a-z0-9 -]/g, '') // remove invalid chars
        .replace(/\s+/g, '-') // collapse whitespace and replace by -
        .replace(/-+/g, '-'); // collapse dashes
    document.getElementById('courseSlug').value = slug;
}

// Prepare Creator tab for course creation
function prepareCreateMode() {
    document.getElementById('creatorTitle').innerText = 'Create New Test Preparation Course';
    document.getElementById('courseIdInput').value = '';
    document.getElementById('courseForm').reset();
    document.getElementById('btnCourseFormSubmit').innerText = 'Create Course';
    
    document.getElementById('contentManagerSection').style.display = 'none';
    switchTab('tab-creator');
}

// Prepare Creator tab for course edits
function prepareEditMode(course) {
    document.getElementById('creatorTitle').innerText = 'Edit Course: ' + course.name;
    document.getElementById('courseIdInput').value = course.id;
    document.getElementById('courseName').value = course.name;
    document.getElementById('courseSlug').value = course.slug;
    document.getElementById('courseDescription').value = course.description;
    document.getElementById('coursePrice').value = course.price;
    document.getElementById('courseDuration').value = course.duration_weeks;
    document.getElementById('courseStatus').value = course.status;
    
    // Parse features JSON back to newline list
    try {
        const features = JSON.parse(course.features) || [];
        document.getElementById('courseFeatures').value = features.join('\n');
    } catch(e) {
        document.getElementById('courseFeatures').value = '';
    }
    
    document.getElementById('btnCourseFormSubmit').innerText = 'Save Changes';
    
    // Setup Content Manager
    document.getElementById('contentCourseId').value = course.id;
    loadCourseContentList(course.id);
    document.getElementById('contentManagerSection').style.display = 'block';
    
    // Switch to editor view tab
    const creatorTabBtn = document.getElementById('creatorTabBtn');
    creatorTabBtn.innerText = 'Edit Course Mode';
    switchTab('tab-creator');
}

// Update course status (toggle active/inactive)
function toggleCourseStatus(courseId, newStatus) {
    if(!confirm(`Are you sure you want to make this course ${newStatus}?`)) return;
    
    const fd = new FormData();
    fd.append('id', courseId);
    
    // Action will trigger delete API if set inactive, or we can use update action
    const apiAction = newStatus === 'inactive' ? 'delete' : 'update';
    
    // If reactivating, we fetch details first or just send a quick update endpoint.
    // Deactivating is simple: sets state to inactive.
    if(newStatus === 'inactive') {
        fetch('api/courses.php?action=delete', {
            method: 'POST',
            body: fd
        })
        .then(r => r.json())
        .then(d => {
            if(d.success) location.reload();
            else alert(d.message);
        });
    } else {
        // We will fetch the course details and push active status
        const coursesList = <?= json_encode($courses) ?>;
        const course = coursesList.find(c => c.id == courseId);
        if(course) {
            const formDataObj = new FormData();
            formDataObj.append('action', 'update');
            formDataObj.append('id', course.id);
            formDataObj.append('name', course.name);
            formDataObj.append('slug', course.slug);
            formDataObj.append('description', course.description);
            formDataObj.append('price', course.price);
            formDataObj.append('duration_weeks', course.duration_weeks);
            
            try {
                const parsed = JSON.parse(course.features);
                formDataObj.append('features', parsed.join('\n'));
            } catch(e) {
                formDataObj.append('features', '');
            }
            formDataObj.append('status', 'active');

            fetch('api/courses.php?action=update', {
                method: 'POST',
                body: formDataObj
            })
            .then(r => r.json())
            .then(d => {
                if(d.success) location.reload();
                else alert(d.message);
            });
        }
    }
}

// Submit course form (Create or Update)
document.getElementById('courseForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const courseId = document.getElementById('courseIdInput').value;
    const action = courseId ? 'update' : 'create';
    
    const fd = new FormData(this);
    
    fetch(`api/courses.php?action=${action}`, {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
            location.reload();
        } else {
            alert(d.message);
        }
    })
    .catch(err => {
        console.error(err);
        alert('An error occurred while saving the course.');
    });
});

// Update enrollment access status (Suspend/Restore/Remove)
function updateEnrollmentAccess(enrollmentId, actionStatus) {
    let msg = `Are you sure you want to set access status to ${actionStatus} for this enrollment?`;
    if(actionStatus === 'removed') {
        msg = "Are you sure you want to REVOKE this student's enrollment entirely? (They will need to purchase the course again to regain access).";
    }
    if(!confirm(msg)) return;
    
    const fd = new FormData();
    fd.append('enrollment_id', enrollmentId);
    fd.append('status', actionStatus);
    
    fetch('api/courses.php?action=update_enrollment', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
            location.reload();
        } else {
            alert(d.message);
        }
    });
}

// Load course content manager files
function loadCourseContentList(courseId) {
    const tbody = document.getElementById('courseContentTableBody');
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;">Loading content items...</td></tr>';
    
    fetch(`api/courses.php?action=list_content&course_id=${courseId}`)
    .then(r => r.json())
    .then(data => {
        if(data.success) {
            const list = data.data;
            if(list.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color: var(--text-muted);">No content items added to this course yet.</td></tr>';
                return;
            }
            
            let html = '';
            list.forEach(item => {
                const previewText = item.is_free_preview == 1 ? '<span style="color:#22c55e;">Yes</span>' : '<span style="color:var(--text-muted);">No</span>';
                const duration = item.duration_minutes ? `${item.duration_minutes} mins` : 'N/A';
                
                // Escape payload
                const cleanItem = JSON.stringify(item).replace(/'/g, "&apos;").replace(/"/g, "&quot;");
                
                html += `
                    <tr>
                        <td>${item.sort_order}</td>
                        <td style="font-weight:600; text-transform: capitalize; color: #a78bfa;">${item.type.replace('_', ' ')}</td>
                        <td style="font-weight:600;">${escapeHtml(item.title)}<br><span style="font-size:0.75rem; color:var(--text-muted); font-weight:normal;">${escapeHtml(item.description || '')}</span></td>
                        <td>${duration}</td>
                        <td>${previewText}</td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick="editContentItem(${cleanItem})">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteContentItem(${item.id})">Delete</button>
                        </td>
                    </tr>
                `;
            });
            tbody.innerHTML = html;
        } else {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: #f87171;">Error: ${data.message}</td></tr>`;
        }
    });
}

// Helper to escape HTML tags
function escapeHtml(text) {
    if (!text) return '';
    return text.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Edit Content Item click handler
function editContentItem(item) {
    document.getElementById('contentId').value = item.id;
    document.getElementById('contentType').value = item.type;
    document.getElementById('contentTitle').value = item.title;
    document.getElementById('contentDesc').value = item.description || '';
    document.getElementById('contentUrl').value = item.content_url || '#';
    document.getElementById('contentDuration').value = item.duration_minutes || '';
    document.getElementById('contentSortOrder').value = item.sort_order;
    document.getElementById('contentIsFree').checked = item.is_free_preview == 1;
    
    document.getElementById('btnContentFormSubmit').innerText = 'Save Content Changes';
    document.getElementById('btnContentFormSubmit').classList.remove('btn-success');
    document.getElementById('btnContentFormSubmit').classList.add('btn-primary');
    document.getElementById('btnCancelContentEdit').style.display = 'inline-block';
}

function cancelContentEdit() {
    document.getElementById('contentId').value = '';
    document.getElementById('contentForm').reset();
    document.getElementById('btnContentFormSubmit').innerText = 'Add Content Resource';
    document.getElementById('btnContentFormSubmit').classList.add('btn-success');
    document.getElementById('btnContentFormSubmit').classList.remove('btn-primary');
    document.getElementById('btnCancelContentEdit').style.display = 'none';
}

// Delete content item
function deleteContentItem(contentId) {
    if(!confirm("Are you sure you want to delete this course content item?")) return;
    
    const fd = new FormData();
    fd.append('id', contentId);
    
    fetch('api/courses.php?action=delete_content', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
            const courseId = document.getElementById('contentCourseId').value;
            loadCourseContentList(courseId);
        } else {
            alert(d.message);
        }
    });
}

// Submit course content resource form
document.getElementById('contentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const contentId = document.getElementById('contentId').value;
    const action = contentId ? 'update_content' : 'add_content';
    const courseId = document.getElementById('contentCourseId').value;
    
    const fd = new FormData(this);
    
    fetch(`api/courses.php?action=${action}`, {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
            cancelContentEdit();
            loadCourseContentList(courseId);
        } else {
            alert(d.message);
        }
    })
    .catch(err => {
        console.error(err);
        alert('An error occurred while saving the content item.');
    });
});

// Client side filtering for Enrollments
function filterEnrollmentsTable() {
    const searchVal = document.getElementById('searchEnrollments').value.toLowerCase();
    const courseVal = document.getElementById('filterEnrollmentCourse').value;
    const rows = document.querySelectorAll('.enrollment-row');
    
    rows.forEach(row => {
        const student = row.querySelector('.student-name').innerText.toLowerCase();
        const email = row.querySelector('.student-email').innerText.toLowerCase();
        const course = row.querySelector('.course-name').innerText;
        
        const matchSearch = student.includes(searchVal) || email.includes(searchVal);
        const matchCourse = !courseVal || course === courseVal;
        
        if(matchSearch && matchCourse) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Client side filtering for Payments
function filterPaymentsTable() {
    const courseVal = document.getElementById('filterPaymentsCourse').value;
    const rows = document.querySelectorAll('.payment-row');
    
    rows.forEach(row => {
        const course = row.querySelector('.payment-course-name').innerText;
        const matchCourse = !courseVal || course === courseVal;
        
        if(matchCourse) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}
</script>
</body>
</html>
