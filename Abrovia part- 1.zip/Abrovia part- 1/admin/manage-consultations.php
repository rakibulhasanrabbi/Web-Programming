<?php
$current_admin_page = 'consultations';
require_once 'includes/auth_check.php';
$requests = $pdo->query("SELECT cr.*, u.full_name, u.email FROM consultation_requests cr JOIN users u ON cr.user_id = u.id ORDER BY cr.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultation Requests - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header"><h1 class="page-title">Consultation Requests</h1><p class="page-subtitle">Review and respond to user consultation requests.</p></div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>Student</th><th>Subject</th><th>Message</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(empty($requests)): ?>
                    <tr><td colspan="6" class="empty-state">No consultation requests yet.</td></tr>
                <?php else: foreach($requests as $r): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500;"><?= htmlspecialchars($r['full_name']) ?><br><span style="font-size:0.75rem;color:var(--text-muted);"><?= htmlspecialchars($r['email']) ?></span></td>
                        <td><?= htmlspecialchars($r['subject']) ?></td>
                        <td style="max-width:250px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($r['message']) ?></td>
                        <td><span class="badge <?= $r['status'] ?>"><?= $r['status'] ?></span></td>
                        <td><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                        <td>
                            <?php if($r['status'] === 'pending'): ?>
                                <button class="btn btn-success btn-sm" onclick="respond(<?= $r['id'] ?>,<?= $r['user_id'] ?>,'accepted')">Accept</button>
                                <button class="btn btn-danger btn-sm" onclick="respond(<?= $r['id'] ?>,<?= $r['user_id'] ?>,'rejected')">Reject</button>
                            <?php elseif($r['status'] === 'accepted'): ?>
                                <button class="btn btn-outline btn-sm" onclick="respond(<?= $r['id'] ?>,<?= $r['user_id'] ?>,'completed')">Mark Complete</button>
                            <?php else: ?>
                                <span style="color:var(--text-muted);font-size:0.8rem;">Done</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<script>
function respond(id,userId,status){
    const fd=new FormData();fd.append('action','update_status');fd.append('id',id);fd.append('user_id',userId);fd.append('status',status);
    fetch('api/consultations.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else alert(d.message);});
}
</script>
</body></html>
