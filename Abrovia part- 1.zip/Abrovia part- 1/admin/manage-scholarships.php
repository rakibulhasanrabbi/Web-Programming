<?php
$current_admin_page = 'scholarships';
require_once 'includes/auth_check.php';
$scholarships = $pdo->query("SELECT * FROM scholarships ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Scholarships - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;">
            <div><h1 class="page-title">Manage Scholarships</h1><p class="page-subtitle">Add, edit, or remove scholarship listings.</p></div>
            <button class="btn btn-primary" onclick="openModal('add')">+ Add Scholarship</button>
        </div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>Title</th><th>Provider</th><th>Amount</th><th>Deadline</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(empty($scholarships)): ?>
                    <tr><td colspan="5" class="empty-state">No scholarships added yet.</td></tr>
                <?php else: foreach($scholarships as $s): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500;"><?= htmlspecialchars($s['title']) ?></td>
                        <td><?= htmlspecialchars($s['provider']) ?></td>
                        <td><?= htmlspecialchars($s['amount'] ?? '-') ?></td>
                        <td><?= $s['deadline'] ? date('M d, Y', strtotime($s['deadline'])) : '-' ?></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick='openModal("edit",<?= json_encode($s) ?>)'>Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteItem(<?= $s['id'] ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<div class="modal-overlay" id="modal">
    <div class="modal">
        <h3 class="modal-title" id="modal-title">Add Scholarship</h3>
        <form id="scholarship-form">
            <input type="hidden" name="id" id="f-id"><input type="hidden" name="action" id="f-action" value="add">
            <div class="form-group"><label class="form-label">Title</label><input class="form-input" name="title" id="f-title" required></div>
            <div class="form-group"><label class="form-label">Provider</label><input class="form-input" name="provider" id="f-provider" required></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group"><label class="form-label">Amount</label><input class="form-input" name="amount" id="f-amount" placeholder="e.g. $10,000"></div>
                <div class="form-group"><label class="form-label">Deadline</label><input type="date" class="form-input" name="deadline" id="f-deadline"></div>
            </div>
            <div class="form-group"><label class="form-label">Description</label><textarea class="form-textarea" name="description" id="f-description"></textarea></div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div>
        </form>
    </div>
</div>
<script>
function openModal(mode, data=null) {
    document.getElementById('modal').classList.add('show');
    document.getElementById('f-action').value = mode === 'edit' ? 'edit' : 'add';
    document.getElementById('modal-title').textContent = mode === 'edit' ? 'Edit Scholarship' : 'Add Scholarship';
    if (data) { document.getElementById('f-id').value=data.id; document.getElementById('f-title').value=data.title; document.getElementById('f-provider').value=data.provider; document.getElementById('f-amount').value=data.amount||''; document.getElementById('f-deadline').value=data.deadline||''; document.getElementById('f-description').value=data.description||''; }
    else { document.getElementById('scholarship-form').reset(); document.getElementById('f-id').value=''; }
}
function closeModal(){document.getElementById('modal').classList.remove('show');}
document.getElementById('modal').addEventListener('click',function(e){if(e.target===this)closeModal();});
document.getElementById('scholarship-form').addEventListener('submit',function(e){
    e.preventDefault();
    fetch('api/scholarships.php',{method:'POST',body:new FormData(this)}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else alert(d.message);});
});
function deleteItem(id){if(!confirm('Delete this scholarship?'))return;const fd=new FormData();fd.append('action','delete');fd.append('id',id);fetch('api/scholarships.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();});}
</script>
</body></html>
