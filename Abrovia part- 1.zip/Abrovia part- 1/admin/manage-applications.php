<?php
$current_admin_page = 'applications';
require_once 'includes/auth_check.php';

// Fetch unique universities and counselors for filter dropdowns
$filter_unis = $pdo->query("SELECT DISTINCT university_name FROM applications ORDER BY university_name ASC")->fetchAll(PDO::FETCH_COLUMN);
$counselors = $pdo->query("SELECT id, full_name FROM users WHERE role IN ('counselor', 'admin') ORDER BY full_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Handle Search and Filter logic
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$counselor_filter = trim($_GET['counselor'] ?? '');
$uni_filter = trim($_GET['university'] ?? '');

$query = "
    SELECT a.*, u.full_name as student_name, u.email as student_email, c.full_name as counselor_name 
    FROM applications a 
    JOIN users u ON a.user_id = u.id 
    LEFT JOIN users c ON a.counselor_id = c.id
    WHERE 1=1
";
$params = [];

if (!empty($search)) {
    $query .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR a.program_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if (!empty($status_filter)) {
    $query .= " AND a.status = ?";
    $params[] = $status_filter;
}
if (!empty($counselor_filter)) {
    if ($counselor_filter === 'unassigned') {
        $query .= " AND a.counselor_id IS NULL";
    } else {
        $query .= " AND a.counselor_id = ?";
        $params[] = intval($counselor_filter);
    }
}
if (!empty($uni_filter)) {
    $query .= " AND a.university_name = ?";
    $params[] = $uni_filter;
}

$query .= " ORDER BY a.applied_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$apps = $stmt->fetchAll(PDO::FETCH_ASSOC);

// If request is AJAX detail fetch, return JSON
if (isset($_GET['fetch_details'])) {
    header('Content-Type: application/json');
    $appId = intval($_GET['fetch_details']);
    
    // Fetch application details
    $dStmt = $pdo->prepare("
        SELECT a.*, u.full_name as student_name, u.email as student_email, c.full_name as counselor_name
        FROM applications a
        JOIN users u ON a.user_id = u.id
        LEFT JOIN users c ON a.counselor_id = c.id
        WHERE a.id = ?
    ");
    $dStmt->execute([$appId]);
    $appDetails = $dStmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$appDetails) {
        echo json_encode(['success' => false, 'message' => 'Not found']);
        exit;
    }
    
    // Fetch documents
    $docsStmt = $pdo->prepare("SELECT * FROM documents WHERE application_id = ? ORDER BY uploaded_at DESC");
    $docsStmt->execute([$appId]);
    $docs = $docsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Fetch notes
    $notesStmt = $pdo->prepare("
        SELECT n.*, u.full_name as author_name, u.role as author_role 
        FROM notes n 
        JOIN users u ON n.author_id = u.id 
        WHERE n.application_id = ? 
        ORDER BY n.created_at DESC
    ");
    $notesStmt->execute([$appId]);
    $notes = $notesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Fetch status history
    $histStmt = $pdo->prepare("
        SELECT sh.*, u.full_name as changer_name, u.role as changer_role
        FROM status_history sh
        JOIN users u ON sh.changed_by = u.id
        WHERE sh.application_id = ?
        ORDER BY sh.created_at DESC
    ");
    $histStmt->execute([$appId]);
    $history = $histStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'application' => $appDetails,
        'documents' => $docs,
        'notes' => $notes,
        'history' => $history
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Management - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Modern status badges */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 10px;
            font-size: 0.7rem;
            font-weight: 600;
            border-radius: 4px;
            text-transform: uppercase;
        }
        .badge-new { background: rgba(59, 130, 246, 0.12); color: #60a5fa; border: 1px solid rgba(59, 130, 246, 0.2); }
        .badge-processing { background: rgba(245, 158, 11, 0.12); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.2); }
        .badge-docs { background: rgba(239, 68, 68, 0.12); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.2); }
        .badge-uni { background: rgba(139, 92, 246, 0.12); color: #c084fc; border: 1px solid rgba(139, 92, 246, 0.2); }
        .badge-accepted { background: rgba(16, 185, 129, 0.12); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.2); }
        .badge-rejected { background: rgba(107, 114, 128, 0.12); color: #9ca3af; border: 1px solid rgba(107, 114, 128, 0.2); }
        .badge-waitlist { background: rgba(249, 115, 22, 0.12); color: #ff7a00; border: 1px solid rgba(249, 115, 22, 0.2); }
        .badge-completed { background: rgba(20, 184, 166, 0.12); color: #2dd4bf; border: 1px solid rgba(20, 184, 166, 0.2); }

        /* Filter bar */
        .admin-filters {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 24px;
            background: var(--bg-card);
            border: 1px solid var(--border);
            padding: 16px;
            border-radius: var(--radius-sm);
        }
        .filter-input {
            flex: 1;
            min-width: 200px;
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 4px;
            padding: 8px 12px;
            color: var(--text-primary);
            font-size: 0.85rem;
            outline: none;
        }
        .filter-select {
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 4px;
            padding: 8px 12px;
            color: var(--text-primary);
            font-size: 0.85rem;
            outline: none;
            min-width: 140px;
        }

        /* Detail Modal Side-Drawer */
        .drawer-overlay {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(4px);
            z-index: 1050;
            display: none;
            justify-content: flex-end;
            animation: fadeIn 0.3s ease;
        }
        .drawer-overlay.show { display: flex; }
        .drawer {
            width: 100%;
            max-width: 680px;
            background: #0d1226;
            border-left: 1px solid var(--border);
            height: 100%;
            display: flex;
            flex-direction: column;
            box-shadow: -10px 0 40px rgba(0,0,0,0.5);
            animation: slideLeft 0.3s ease;
            color: var(--text-primary);
        }
        @keyframes slideLeft {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
        }
        .drawer-header {
            padding: 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .drawer-body {
            flex: 1;
            overflow-y: auto;
            padding: 24px;
        }
        .drawer-section {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 20px;
            margin-bottom: 20px;
        }
        .section-title-mod {
            font-size: 0.95rem;
            font-weight: 700;
            color: #fff;
            margin-bottom: 14px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            padding-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        /* Notes item list styling */
        .note-item {
            background: rgba(255,255,255,0.02);
            border: 1px solid var(--border);
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 10px;
            font-size: 0.8rem;
        }
        
        /* Action buttons */
        .btn-action-small {
            padding: 4px 8px;
            font-size: 0.72rem;
            font-weight: 600;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-approve { background: rgba(16, 185, 129, 0.15); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.3); }
        .btn-approve:hover { background: #10b981; color: #fff; }
        .btn-reject { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); }
        .btn-reject:hover { background: #ef4444; color: #fff; }
    </style>
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header">
            <h1 class="page-title">Admissions & Visa Management</h1>
            <p class="page-subtitle">Review, assign, track documentation, and log transitions for student applications.</p>
        </div>

        <!-- Filter and Search controls -->
        <form action="" method="GET">
            <div class="admin-filters">
                <input type="text" name="search" class="filter-input" placeholder="Search by student, email, program..." value="<?= htmlspecialchars($search) ?>">
                
                <select name="status" class="filter-select">
                    <option value="">All Statuses</option>
                    <option value="New" <?= $status_filter==='New'?'selected':'' ?>>New</option>
                    <option value="Processing" <?= $status_filter==='Processing'?'selected':'' ?>>Processing</option>
                    <option value="Documents Required" <?= $status_filter==='Documents Required'?'selected':'' ?>>Documents Required</option>
                    <option value="Submitted to University" <?= $status_filter==='Submitted to University'?'selected':'' ?>>Submitted to University</option>
                    <option value="Accepted" <?= $status_filter==='Accepted'?'selected':'' ?>>Accepted</option>
                    <option value="Rejected" <?= $status_filter==='Rejected'?'selected':'' ?>>Rejected</option>
                    <option value="Waitlisted" <?= $status_filter==='Waitlisted'?'selected':'' ?>>Waitlisted</option>
                    <option value="Completed" <?= $status_filter==='Completed'?'selected':'' ?>>Completed</option>
                </select>

                <select name="counselor" class="filter-select">
                    <option value="">All Counselors</option>
                    <option value="unassigned" <?= $counselor_filter==='unassigned'?'selected':'' ?>>Unassigned Only</option>
                    <?php foreach($counselors as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $counselor_filter===strval($c['id'])?'selected':'' ?>><?= htmlspecialchars($c['full_name']) ?></option>
                    <?php endforeach; ?>
                </select>

                <select name="university" class="filter-select">
                    <option value="">All Universities</option>
                    <?php foreach($filter_unis as $uni): ?>
                        <option value="<?= htmlspecialchars($uni) ?>" <?= $uni_filter===$uni?'selected':'' ?>><?= htmlspecialchars($uni) ?></option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="btn btn-primary" style="padding:8px 20px;">Filter</button>
                <a href="manage-applications.php" class="btn btn-outline" style="padding:8px 20px; text-decoration:none; display:flex; align-items:center;">Reset</a>
            </div>
        </form>

        <!-- Applications List Table -->
        <div class="data-table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Program of Interest</th>
                        <th>Target University</th>
                        <th>Status</th>
                        <th>Assigned Counselor</th>
                        <th>Applied On</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(empty($apps)): ?>
                    <tr><td colspan="7" class="empty-state">No matching student applications found.</td></tr>
                <?php else: foreach($apps as $a): 
                    $badge_class = 'badge-new';
                    switch ($a['status']) {
                        case 'New': $badge_class = 'badge-new'; break;
                        case 'Processing': $badge_class = 'badge-processing'; break;
                        case 'Documents Required': $badge_class = 'badge-docs'; break;
                        case 'Submitted to University': $badge_class = 'badge-uni'; break;
                        case 'Accepted': $badge_class = 'badge-accepted'; break;
                        case 'Rejected': $badge_class = 'badge-rejected'; break;
                        case 'Waitlisted': $badge_class = 'badge-waitlist'; break;
                        case 'Completed': $badge_class = 'badge-completed'; break;
                    }
                ?>
                    <tr style="cursor:pointer;" onclick="location.href='manage-application.php?id=<?= $a['id'] ?>'">
                        <td>
                            <div style="font-weight:600; color:#fff;"><?= htmlspecialchars($a['student_name']) ?></div>
                            <div style="font-size:0.75rem; color:var(--text-muted);"><?= htmlspecialchars($a['student_email']) ?></div>
                        </td>
                        <td><?= htmlspecialchars($a['program_name']) ?></td>
                        <td><?= htmlspecialchars($a['university_name']) ?></td>
                        <td><span class="status-badge <?= $badge_class ?>"><?= htmlspecialchars($a['status']) ?></span></td>
                        <td style="font-weight:500; color:<?= $a['counselor_name'] ? '#c4b5fd' : 'var(--text-muted)' ?>;">
                            👤 <?= $a['counselor_name'] ? htmlspecialchars($a['counselor_name']) : 'Unassigned' ?>
                        </td>
                        <td><?= date('M d, Y', strtotime($a['applied_at'])) ?></td>
                        <td>
                            <a class="btn btn-outline btn-sm" href="manage-application.php?id=<?= $a['id'] ?>" onclick="event.stopPropagation();">Manage</a>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Dynamic Detail Drawer Panel -->
<div class="drawer-overlay" id="detail-drawer" onclick="closeDrawer(event)">
    <div class="drawer" onclick="event.stopPropagation()">
        <div class="drawer-header">
            <div>
                <h3 id="d-student-name" style="font-size:1.25rem; font-weight:700; color:#fff;">Student Details</h3>
                <p id="d-student-email" style="font-size:0.8rem; color:var(--text-secondary);"></p>
            </div>
            <button class="btn btn-outline btn-sm" onclick="closeDrawer(null)" style="border-radius:50%; width:30px; height:30px; display:flex; align-items:center; justify-content:center;">✕</button>
        </div>
        
        <div class="drawer-body">
            
            <!-- Context Banner -->
            <div class="drawer-section" style="background: rgba(108, 63, 255, 0.05); border-color: rgba(108, 63, 255, 0.2);">
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; font-size:0.85rem;">
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.7rem; text-transform:uppercase;">Program</span>
                        <strong id="d-program-name" style="color:#fff;"></strong>
                    </div>
                    <div>
                        <span style="color:var(--text-muted); display:block; font-size:0.7rem; text-transform:uppercase;">Target University</span>
                        <strong id="d-university-name" style="color:#fff;"></strong>
                    </div>
                    <div style="margin-top:10px;">
                        <span style="color:var(--text-muted); display:block; font-size:0.7rem; text-transform:uppercase;">Origin / Source</span>
                        <strong id="d-source" style="text-transform:capitalize;"></strong>
                    </div>
                    <div style="margin-top:10px;">
                        <span style="color:var(--text-muted); display:block; font-size:0.7rem; text-transform:uppercase;">Visa Phase status</span>
                        <strong id="d-visa-status" style="text-transform:uppercase; color:#2dd4bf;"></strong>
                    </div>
                </div>
            </div>

            <!-- Counselor Assignment -->
            <div class="drawer-section">
                <h4 class="section-title-mod">👤 Counselor Assignment</h4>
                <form id="form-counselor" onsubmit="submitCounselor(event)">
                    <input type="hidden" name="action" value="assign_counselor">
                    <input type="hidden" name="id" id="coun-app-id">
                    <div style="display:flex; gap:10px;">
                        <select name="counselor_id" id="d-counselor-select" class="form-select" style="flex:1;">
                            <option value="0">-- Assign Counselor --</option>
                            <?php foreach($counselors as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary">Assign</button>
                    </div>
                </form>
            </div>

            <!-- Status Transition Widget -->
            <div class="drawer-section">
                <h4 class="section-title-mod">⚙ Journey Stage Transition</h4>
                <form id="form-status" onsubmit="submitStatus(event)">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="id" id="status-app-id">
                    <div class="form-group" style="margin-bottom:12px;">
                        <label class="form-label" style="font-size:0.75rem;">Change Status To</label>
                        <select name="status" id="d-status-select" class="form-select">
                            <option value="New">New</option>
                            <option value="Processing">Processing</option>
                            <option value="Documents Required">Documents Required</option>
                            <option value="Submitted to University">Submitted to University</option>
                            <option value="Accepted">Accepted</option>
                            <option value="Rejected">Rejected</option>
                            <option value="Waitlisted">Waitlisted</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div class="form-group" style="margin-bottom:16px;">
                        <label class="form-label" style="font-size:0.75rem;">Transition Note / Student Comments</label>
                        <textarea name="comments" class="form-textarea" placeholder="e.g. Received official transcripts; application forwarded." style="min-height:70px; padding:10px; font-size:0.8rem;"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;">Save Transition & Notify Student</button>
                </form>
            </div>

            <!-- Dispatch Document Request -->
            <div class="drawer-section">
                <h4 class="section-title-mod">📨 Request Supporting Credentials</h4>
                <form id="form-req-doc" onsubmit="submitDocRequest(event)">
                    <input type="hidden" name="action" value="request_doc">
                    <input type="hidden" name="id" id="req-doc-app-id">
                    <div class="form-group" style="margin-bottom:10px;">
                        <label class="form-label" style="font-size:0.75rem;">Document Name</label>
                        <input type="text" name="doc_name" class="form-input" placeholder="e.g. Bank Solvency Certificate, CV" required style="padding:8px 12px; font-size:0.8rem;">
                    </div>
                    <div class="form-group" style="margin-bottom:12px;">
                        <label class="form-label" style="font-size:0.75rem;">Special Instructions / Checklist Criteria</label>
                        <textarea name="description" class="form-textarea" placeholder="e.g. Please upload bank solvency showing a minimum balance of $25,000 USD..." style="min-height:60px; padding:10px; font-size:0.8rem;"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width:100%;">Dispatch Request (Sets Status: Documents Required)</button>
                </form>
            </div>

            <!-- Supporting Credentials Review Panel -->
            <div class="drawer-section">
                <h4 class="section-title-mod">📄 Student Uploads Review</h4>
                <div id="d-docs-list" style="display:flex; flex-direction:column; gap:12px;">
                    <!-- Rendered dynamically -->
                </div>
            </div>

            <!-- Internal Counseling Notes -->
            <div class="drawer-section">
                <h4 class="section-title-mod">📝 Counseling Internal Notes (Admins & Counselors Only)</h4>
                <form id="form-note" onsubmit="submitNote(event)" style="margin-bottom:18px;">
                    <input type="hidden" name="action" value="add_note">
                    <input type="hidden" name="id" id="note-app-id">
                    <div style="display:flex; gap:10px;">
                        <textarea name="note_text" class="form-textarea" required placeholder="Add internal follow-up comment..." style="flex:1; min-height:50px; padding:10px; font-size:0.8rem;"></textarea>
                        <button type="submit" class="btn btn-primary" style="align-self:flex-end;">Add Note</button>
                    </div>
                </form>
                <div id="d-notes-list" style="display:flex; flex-direction:column; gap:10px;">
                    <!-- Rendered dynamically -->
                </div>
            </div>

            <!-- Audit trail history log -->
            <div class="drawer-section">
                <h4 class="section-title-mod">🕒 Transition Audit Trail History</h4>
                <div id="d-history-list" style="display:flex; flex-direction:column; gap:10px;">
                    <!-- Rendered dynamically -->
                </div>
            </div>

        </div>
    </div>
</div>

<script>
let currentAppId = null;

function openDetails(id) {
    currentAppId = id;
    document.getElementById('coun-app-id').value = id;
    document.getElementById('status-app-id').value = id;
    document.getElementById('req-doc-app-id').value = id;
    document.getElementById('note-app-id').value = id;
    
    fetch('manage-applications.php?fetch_details=' + id)
    .then(r => r.json())
    .then(data => {
        if (!data.success) {
            alert('Error loading details.');
            return;
        }
        
        const app = data.application;
        document.getElementById('d-student-name').innerText = app.student_name;
        document.getElementById('d-student-email').innerText = '✉ ' + app.student_email;
        document.getElementById('d-program-name').innerText = app.program_name;
        document.getElementById('d-university-name').innerText = app.university_name;
        document.getElementById('d-source').innerText = app.source_type + ' origin';
        document.getElementById('d-visa-status').innerText = app.visa_status;
        
        // Select elements
        document.getElementById('d-counselor-select').value = app.counselor_id || '0';
        document.getElementById('d-status-select').value = app.status;
        
        // Render documents
        const docsList = document.getElementById('d-docs-list');
        docsList.innerHTML = '';
        if (data.documents.length === 0) {
            docsList.innerHTML = '<div style="color:var(--text-muted); font-size:0.8rem; text-align:center;">No documents uploaded.</div>';
        } else {
            data.documents.forEach(doc => {
                let statusColor = '#f59e0b';
                let reviewControls = '';
                
                if (doc.status === 'verified') statusColor = '#10b981';
                else if (doc.status === 'rejected') statusColor = '#ef4444';
                
                if (doc.status === 'under_review') {
                    reviewControls = `
                        <div style="margin-top:8px; display:flex; gap:8px;">
                            <button type="button" class="btn-action-small btn-approve" onclick="reviewDoc(${doc.id}, 'verified')">Approve ✓</button>
                            <button type="button" class="btn-action-small btn-reject" onclick="reviewDoc(${doc.id}, 'rejected')">Reject ✗</button>
                        </div>
                    `;
                }
                
                let feedbackText = '';
                if (doc.status === 'rejected' && doc.admin_message) {
                    feedbackText = `<div style="font-size:0.72rem; color:#ef4444; margin-top:3px;">Reason: "${doc.admin_message}"</div>`;
                }
                
                let downloadBtn = '';
                if (doc.file_path) {
                    downloadBtn = `<a href="../${doc.file_path}" download class="btn btn-outline btn-sm" style="font-size:0.7rem; padding:3px 8px; text-decoration:none;">Download File</a>`;
                }
                
                const item = document.createElement('div');
                item.style.background = 'rgba(255,255,255,0.01)';
                item.style.border = '1px solid var(--border)';
                item.style.borderRadius = '6px';
                item.style.padding = '14px';
                item.innerHTML = `
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div>
                            <strong style="font-size:0.82rem; color:#fff; display:block;">📄 ${doc.name}</strong>
                            <span style="font-size:0.75rem; color:${statusColor}; font-weight:600;">● Status: ${doc.status.toUpperCase().replace('_', ' ')}</span>
                            ${feedbackText}
                        </div>
                        ${downloadBtn}
                    </div>
                    ${reviewControls}
                `;
                docsList.appendChild(item);
            });
        }
        
        // Render Notes
        const notesList = document.getElementById('d-notes-list');
        notesList.innerHTML = '';
        if (data.notes.length === 0) {
            notesList.innerHTML = '<div style="color:var(--text-muted); font-size:0.8rem; text-align:center;">No counseling logs added yet.</div>';
        } else {
            data.notes.forEach(n => {
                const noteItem = document.createElement('div');
                noteItem.className = 'note-item';
                noteItem.innerHTML = `
                    <p style="color:var(--text-secondary); line-height:1.5;">"${n.note_text}"</p>
                    <span style="font-size:0.68rem; color:var(--text-muted); display:block; margin-top:4px;">
                        By <strong>${n.author_name}</strong> (${n.author_role.toUpperCase()}) • ${new Date(n.created_at).toLocaleString()}
                    </span>
                `;
                notesList.appendChild(noteItem);
            });
        }
        
        // Render audit trail history
        const histList = document.getElementById('d-history-list');
        histList.innerHTML = '';
        if (data.history.length === 0) {
            histList.innerHTML = '<div style="color:var(--text-muted); font-size:0.8rem; text-align:center;">No transitions recorded.</div>';
        } else {
            data.history.forEach(h => {
                const hItem = document.createElement('div');
                hItem.style.background = 'rgba(255,255,255,0.01)';
                hItem.style.borderLeft = '2px solid var(--accent)';
                hItem.style.padding = '8px 12px';
                hItem.style.borderRadius = '0 4px 4px 0';
                hItem.style.fontSize = '0.75rem';
                
                hItem.innerHTML = `
                    <div style="font-weight:600; color:#fff;">Transition: ${h.old_status || 'New'} ➔ ${h.new_status}</div>
                    <p style="color:var(--text-muted); font-size:0.72rem; margin:2px 0 4px;">"${h.comments || ''}"</p>
                    <span style="font-size:0.65rem; color:var(--text-muted); display:block;">
                        By ${h.changer_name} (${h.changer_role}) • ${new Date(h.created_at).toLocaleString()}
                    </span>
                `;
                histList.appendChild(hItem);
            });
        }

        document.getElementById('detail-drawer').classList.add('show');
    });
}

function closeDrawer(e) {
    if (!e || e.target === document.getElementById('detail-drawer')) {
        document.getElementById('detail-drawer').classList.remove('show');
        currentAppId = null;
    }
}

// Form submits via AJAX
function submitCounselor(e) {
    e.preventDefault();
    const form = document.getElementById('form-counselor');
    fetch('api/applications.php', { method: 'POST', body: new FormData(form) })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert('Counselor assigned successfully!');
            openDetails(currentAppId);
        } else alert(d.message);
    });
}

function submitStatus(e) {
    e.preventDefault();
    const form = document.getElementById('form-status');
    fetch('api/applications.php', { method: 'POST', body: new FormData(form) })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert('Application status transition saved!');
            openDetails(currentAppId);
        } else alert(d.message);
    });
}

function submitDocRequest(e) {
    e.preventDefault();
    const form = document.getElementById('form-req-doc');
    fetch('api/applications.php', { method: 'POST', body: new FormData(form) })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert('Document request dispatched!');
            form.reset();
            openDetails(currentAppId);
        } else alert(d.message);
    });
}

function submitNote(e) {
    e.preventDefault();
    const form = document.getElementById('form-note');
    fetch('api/applications.php', { method: 'POST', body: new FormData(form) })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            form.reset();
            openDetails(currentAppId);
        } else alert(d.message);
    });
}

function reviewDoc(docId, docStatus) {
    let feedback = '';
    if (docStatus === 'rejected') {
        feedback = prompt('Please enter rejection feedback reason for the student:');
        if (feedback === null) return; // cancel
        if (feedback.trim() === '') {
            alert('Rejection feedback is required so the student knows what to fix.');
            return;
        }
    }
    
    const fd = new FormData();
    fd.append('action', 'update_doc_status');
    fd.append('doc_id', docId);
    fd.append('status', docStatus);
    fd.append('feedback', feedback);
    
    fetch('api/applications.php', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert('Credential review updated successfully!');
            openDetails(currentAppId);
        } else alert(d.message);
    });
}
</script>
</body>
</html>
