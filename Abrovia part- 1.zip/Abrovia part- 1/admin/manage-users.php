<?php
$current_admin_page = 'users';
require_once 'includes/auth_check.php';
$users = $pdo->query("SELECT * FROM users WHERE role='user' ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header"><h1 class="page-title">Manage Users</h1><p class="page-subtitle">View registered users, send warnings, or remove accounts.</p></div>
        <div class="data-table-wrap">
            <div class="table-header">
                <h2 class="table-title">All Users (<?= count($users) ?>)</h2>
            </div>
            <table class="data-table">
                <thead><tr><th>Name</th><th>Email</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(empty($users)): ?>
                    <tr><td colspan="5" class="empty-state">No users registered yet.</td></tr>
                <?php else: foreach($users as $u): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500;"><?= htmlspecialchars($u['full_name']) ?></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <span class="badge <?= $u['status'] === 'suspended' ? 'suspended' : 'active' ?>"><?= htmlspecialchars($u['status']) ?></span>
                        </td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="notifyUser(<?= $u['id'] ?>,'<?= htmlspecialchars($u['full_name'],ENT_QUOTES) ?>')">Notify</button>
                            <?php if ($u['status'] === 'suspended'): ?>
                                <button class="btn btn-success btn-sm" onclick="toggleStatus(<?= $u['id'] ?>, 'resume')">Resume</button>
                            <?php else: ?>
                                <button class="btn btn-danger btn-sm" onclick="toggleStatus(<?= $u['id'] ?>, 'suspend')">Suspend</button>
                            <?php endif; ?>
                            <button class="btn btn-danger btn-sm" onclick="deleteUser(<?= $u['id'] ?>)">Remove</button>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<!-- Notify Modal -->
<div class="modal-overlay" id="notify-modal">
    <div class="modal">
        <h3 class="modal-title">Send Notification to <span id="notify-name"></span></h3>
        <form id="notify-form">
            <input type="hidden" name="action" value="notify"><input type="hidden" name="user_id" id="notify-uid">
            <div class="form-group"><label class="form-label">Message</label><textarea class="form-textarea" name="message" required placeholder="Type your message to the user..."></textarea></div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="document.getElementById('notify-modal').classList.remove('show')">Cancel</button><button type="submit" class="btn btn-primary">Send</button></div>
        </form>
    </div>
</div>
<script>
function notifyUser(id,name){document.getElementById('notify-uid').value=id;document.getElementById('notify-name').textContent=name;document.getElementById('notify-modal').classList.add('show');}
document.getElementById('notify-modal').addEventListener('click',function(e){if(e.target===this)this.classList.remove('show');});
document.getElementById('notify-form').addEventListener('submit',function(e){
    e.preventDefault();
    fetch('api/users.php',{method:'POST',body:new FormData(this)}).then(r=>r.json()).then(d=>{if(d.success){alert('Notification sent!');location.reload();}else alert(d.message);});
});
function deleteUser(id){if(!confirm('Remove this user? This will delete all their data.'))return;const fd=new FormData();fd.append('action','delete');fd.append('id',id);fetch('api/users.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();});}
function toggleStatus(id,action){if(!confirm((action==='suspend'?'Suspend':'Resume')+' this user?'))return;const fd=new FormData();fd.append('action',action);fd.append('id',id);fetch('api/users.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else alert(d.message);});}
</script>
</body></html>
