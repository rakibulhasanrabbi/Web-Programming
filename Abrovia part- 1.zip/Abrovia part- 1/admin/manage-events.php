<?php
$current_admin_page = 'events';
require_once 'includes/auth_check.php';
$events = $pdo->query("SELECT * FROM events ORDER BY event_date DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Events - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;">
            <div><h1 class="page-title">Manage Events</h1><p class="page-subtitle">Create and manage study abroad events.</p></div>
            <button class="btn btn-primary" onclick="openModal('add')">+ Add Event</button>
        </div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>Title</th><th>Type</th><th>Date</th><th>Time</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(empty($events)): ?>
                    <tr><td colspan="7" class="empty-state">No events created yet.</td></tr>
                <?php else: foreach($events as $e): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500;"><?= htmlspecialchars($e['title']) ?></td>
                        <td><span class="badge <?= $e['event_type'] ?>"><?= $e['event_type'] ?></span></td>
                        <td><?= date('M d, Y', strtotime($e['event_date'])) ?></td>
                        <td><?= date('h:i A', strtotime($e['event_time'])) ?></td>
                        <td><?= htmlspecialchars($e['location'] ?: 'Online') ?></td>
                        <td><span class="badge <?= $e['status'] ?>"><?= $e['status'] ?></span></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick='openModal("edit",<?= json_encode($e) ?>)'>Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteItem(<?= $e['id'] ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<div class="modal-overlay" id="modal">
    <div class="modal">
        <h3 class="modal-title" id="modal-title">Add Event</h3>
        <form id="event-form">
            <input type="hidden" name="id" id="f-id"><input type="hidden" name="action" id="f-action" value="add">
            <div class="form-group"><label class="form-label">Event Title</label><input class="form-input" name="title" id="f-title" required></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group"><label class="form-label">Type</label><select class="form-select" name="event_type" id="f-type"><option value="online">Online</option><option value="offline">Offline</option></select></div>
                <div class="form-group"><label class="form-label">Status</label><select class="form-select" name="status" id="f-status"><option value="upcoming">Upcoming</option><option value="ongoing">Ongoing</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group"><label class="form-label">Date</label><input type="date" class="form-input" name="event_date" id="f-date" required></div>
                <div class="form-group"><label class="form-label">Time</label><input type="time" class="form-input" name="event_time" id="f-time" required></div>
            </div>
            <div class="form-group"><label class="form-label">Location</label><input class="form-input" name="location" id="f-location" placeholder="Venue or Online link"></div>
            <div class="form-group"><label class="form-label">Max Participants</label><input type="number" class="form-input" name="max_participants" id="f-max" value="100"></div>
            <div class="form-group"><label class="form-label">Description</label><textarea class="form-textarea" name="description" id="f-desc"></textarea></div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div>
        </form>
    </div>
</div>
<script>
function openModal(mode,data=null){
    document.getElementById('modal').classList.add('show');
    document.getElementById('f-action').value=mode==='edit'?'edit':'add';
    document.getElementById('modal-title').textContent=mode==='edit'?'Edit Event':'Add Event';
    if(data){document.getElementById('f-id').value=data.id;document.getElementById('f-title').value=data.title;document.getElementById('f-type').value=data.event_type;document.getElementById('f-status').value=data.status;document.getElementById('f-date').value=data.event_date;document.getElementById('f-time').value=data.event_time;document.getElementById('f-location').value=data.location||'';document.getElementById('f-max').value=data.max_participants;document.getElementById('f-desc').value=data.description||'';}
    else{document.getElementById('event-form').reset();document.getElementById('f-id').value='';}
}
function closeModal(){document.getElementById('modal').classList.remove('show');}
document.getElementById('modal').addEventListener('click',function(e){if(e.target===this)closeModal();});
document.getElementById('event-form').addEventListener('submit',function(e){e.preventDefault();fetch('api/events.php',{method:'POST',body:new FormData(this)}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else alert(d.message);});});
function deleteItem(id){if(!confirm('Delete this event?'))return;const fd=new FormData();fd.append('action','delete');fd.append('id',id);fetch('api/events.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();});}
</script>
</body></html>
