<?php
$current_admin_page = 'event-requests';
require_once 'includes/auth_check.php';
$requests = $pdo->query("SELECT er.*, u.full_name, u.email, e.title as event_title, e.event_date, e.event_time, e.location, e.event_type FROM event_requests er JOIN users u ON er.user_id = u.id JOIN events e ON er.event_id = e.id ORDER BY er.created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Requests - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header"><h1 class="page-title">Event Join Requests</h1><p class="page-subtitle">Approve or reject user requests to join events.</p></div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>Student</th><th>Event</th><th>Type</th><th>Date</th><th>Status</th><th>Requested</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(empty($requests)): ?>
                    <tr><td colspan="7" class="empty-state">No event requests yet.</td></tr>
                <?php else: foreach($requests as $r): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500; padding: 12px 16px;">
                            <?= htmlspecialchars($r['full_name']) ?><br>
                            <span style="font-size:0.8rem;color:var(--text-muted);font-weight:normal;"><?= htmlspecialchars($r['email']) ?></span>
                            <?php if(!empty($r['phone'])): ?>
                                <br><span style="font-size:0.78rem;color:#a78bfa;font-weight:500;display:inline-flex;align-items:center;gap:4px;margin-top:2px;">📞 <?= htmlspecialchars($r['phone']) ?></span>
                            <?php endif; ?>
                            <?php if(!empty($r['additional_info'])): ?>
                                <div style="font-size:0.75rem;color:var(--text-gray);font-weight:normal;margin-top:6px;max-width:260px;background:rgba(255,255,255,0.02);padding:6px 10px;border-radius:6px;border:1px solid rgba(255,255,255,0.06);line-height:1.4;">
                                    <strong style="color:var(--text-muted);">Notes:</strong> <?= htmlspecialchars($r['additional_info']) ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($r['event_title']) ?></td>
                        <td><span class="badge <?= $r['event_type'] ?>"><?= $r['event_type'] ?></span></td>
                        <td><?= date('M d, Y', strtotime($r['event_date'])) ?></td>
                        <td><span class="badge <?= $r['status'] ?>"><?= $r['status'] ?></span></td>
                        <td><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                        <td>
                            <?php if($r['status'] === 'pending'): ?>
                                <button class="btn btn-success btn-sm" onclick="handleRequest(<?= $r['id'] ?>,'approved',<?= $r['user_id'] ?>,'<?= htmlspecialchars($r['event_title'],ENT_QUOTES) ?>','<?= date('M d, Y', strtotime($r['event_date'])) ?>','<?= date('h:i A', strtotime($r['event_time'])) ?>','<?= htmlspecialchars($r['location'] ?: 'Online',ENT_QUOTES) ?>')">Approve</button>
                                <button class="btn btn-danger btn-sm" onclick="handleRequest(<?= $r['id'] ?>,'rejected',<?= $r['user_id'] ?>)">Reject</button>
                            <?php else: ?>
                                <span style="color:var(--text-muted);font-size:0.8rem;">Processed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>
<script>
function handleRequest(id,status,userId,eventTitle,eventDate,eventTime,eventLocation){
    const fd=new FormData();
    fd.append('action','update_status');fd.append('id',id);fd.append('status',status);fd.append('user_id',userId);
    if(status==='approved'){fd.append('event_title',eventTitle||'');fd.append('event_date',eventDate||'');fd.append('event_time',eventTime||'');fd.append('event_location',eventLocation||'');}
    fetch('api/event-requests.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else alert(d.message);});
}
</script>
</body></html>
