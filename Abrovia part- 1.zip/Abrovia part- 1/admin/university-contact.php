<?php
$current_admin_page = 'university-contact';
require_once 'includes/auth_check.php';
$contacts = $pdo->query("SELECT * FROM university_contacts ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Contact - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;">
            <div><h1 class="page-title">University Contact</h1><p class="page-subtitle">Manage university partnerships and send admission requests.</p></div>
            <button class="btn btn-primary" onclick="openModal('add')">+ Add University</button>
        </div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>University</th><th>Country</th><th>Email</th><th>Phone</th><th>Website</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(empty($contacts)): ?>
                    <tr><td colspan="6" class="empty-state">No university contacts added yet.</td></tr>
                <?php else: foreach($contacts as $c): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500;"><?= htmlspecialchars($c['university_name']) ?></td>
                        <td><?= htmlspecialchars($c['country']) ?></td>
                        <td><?= htmlspecialchars($c['contact_email'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($c['contact_phone'] ?? '-') ?></td>
                        <td><?php if($c['website'] && $c['website'] !== 'none'): ?><a href="<?= htmlspecialchars($c['website']) ?>" target="_blank" style="color:var(--accent);">Visit</a><?php else: ?>-<?php endif; ?></td>
                        <td>
                            <div style="display:flex;gap:6px;">
                                <button class="btn btn-primary btn-sm" onclick="openForwardModal(<?= $c['id'] ?>, <?= htmlspecialchars(json_encode($c['university_name'])) ?>)">Forward</button>
                                <button class="btn btn-outline btn-sm" onclick='openModal("edit",<?= json_encode($c) ?>)'>Edit</button>
                                <button class="btn btn-danger btn-sm" onclick="deleteItem(<?= $c['id'] ?>)">Delete</button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add/Edit Modal -->
<div class="modal-overlay" id="modal">
    <div class="modal">
        <h3 class="modal-title" id="modal-title">Add University Contact</h3>
        <form id="uni-form">
            <input type="hidden" name="id" id="f-id"><input type="hidden" name="action" id="f-action" value="add">
            <div class="form-group"><label class="form-label">University Name</label><input class="form-input" name="university_name" id="f-name" required></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group"><label class="form-label">Country</label><input class="form-input" name="country" id="f-country" required></div>
                <div class="form-group"><label class="form-label">Contact Email</label><input type="email" class="form-input" name="contact_email" id="f-email"></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group"><label class="form-label">Phone</label><input class="form-input" name="contact_phone" id="f-phone"></div>
                <div class="form-group"><label class="form-label">Website</label><input class="form-input" name="website" id="f-website" placeholder="https://..."></div>
            </div>
            <div class="form-group"><label class="form-label">Notes</label><textarea class="form-textarea" name="notes" id="f-notes"></textarea></div>
            <div class="modal-footer"><button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div>
        </form>
    </div>
</div>

<!-- Forward Application Modal -->
<div class="modal-overlay" id="forward-modal">
    <div class="modal">
        <h3 class="modal-title">Forward Student Application</h3>
        <form id="forward-form">
            <input type="hidden" name="action" value="send_application">
            <input type="hidden" name="university_contact_id" id="f-contact-id">
            
            <div class="form-group">
                <label class="form-label">Select Student Application</label>
                <select class="form-select" name="application_id" id="f-application-id" required style="width:100%;padding:10px;background:var(--bg-input);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-primary);outline:none;">
                    <option value="">-- Select Pending Application --</option>
                    <?php 
                    $apps = $pdo->query("SELECT a.*, u.full_name as student_name FROM applications a JOIN users u ON a.user_id = u.id WHERE a.status = 'pending' ORDER BY a.applied_at DESC")->fetchAll();
                    if (empty($apps)): ?>
                        <option value="" disabled>No pending student applications found</option>
                    <?php else: foreach ($apps as $app): ?>
                        <option value="<?= $app['id'] ?>">
                            <?= htmlspecialchars($app['student_name']) ?> - <?= htmlspecialchars($app['program_name']) ?> (<?= htmlspecialchars($app['university_name']) ?>)
                        </option>
                    <?php endforeach; endif; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Cover Message to Partner University</label>
                <textarea class="form-textarea" name="cover_letter" id="f-cover-letter" required style="height:120px;"></textarea>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeForwardModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Forward Now</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(mode,data=null){
    document.getElementById('modal').classList.add('show');
    document.getElementById('f-action').value=mode==='edit'?'edit':'add';
    document.getElementById('modal-title').textContent=mode==='edit'?'Edit University Contact':'Add University Contact';
    if(data){document.getElementById('f-id').value=data.id;document.getElementById('f-name').value=data.university_name;document.getElementById('f-country').value=data.country;document.getElementById('f-email').value=data.contact_email||'';document.getElementById('f-phone').value=data.contact_phone||'';document.getElementById('f-website').value=data.website||'';document.getElementById('f-notes').value=data.notes||'';}
    else{document.getElementById('uni-form').reset();document.getElementById('f-id').value='';}
}
function closeModal(){document.getElementById('modal').classList.remove('show');}
document.getElementById('modal').addEventListener('click',function(e){if(e.target===this)closeModal();});
document.getElementById('uni-form').addEventListener('submit',function(e){e.preventDefault();fetch('api/university-contact.php',{method:'POST',body:new FormData(this)}).then(r=>r.json()).then(d=>{if(d.success)location.reload();else alert(d.message);});});
function deleteItem(id){if(!confirm('Delete this contact?'))return;const fd=new FormData();fd.append('action','delete');fd.append('id',id);fetch('api/university-contact.php',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{if(d.success)location.reload();});}

function openForwardModal(contactId, universityName) {
    document.getElementById('forward-modal').classList.add('show');
    document.getElementById('f-contact-id').value = contactId;
    document.getElementById('f-cover-letter').value = "Dear Admission Team at " + universityName + ",\n\nWe are pleased to forward the student academic application for your review and processing. Please let us know if any further documents are needed.\n\nBest regards,\nAbrovia Administration";
}
function closeForwardModal() {
    document.getElementById('forward-modal').classList.remove('show');
    document.getElementById('forward-form').reset();
}
document.getElementById('forward-modal').addEventListener('click', function(e) {
    if (e.target === this) closeForwardModal();
});
document.getElementById('forward-form').addEventListener('submit', function(e) {
    e.preventDefault();
    fetch('api/university-contact.php', {
        method: 'POST',
        body: new FormData(this)
    })
    .then(r => r.json())
    .then(d => {
        if (d.success) {
            alert('Application successfully forwarded to university contacts!');
            closeForwardModal();
            location.reload();
        } else {
            alert(d.message || 'An error occurred.');
        }
    });
});
</script>
</body></html>
