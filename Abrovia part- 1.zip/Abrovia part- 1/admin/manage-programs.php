<?php
$current_admin_page = 'programs';
require_once 'includes/auth_check.php';
$programs = $pdo->query("SELECT * FROM programs ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Programs - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>
    <main class="admin-main">
        <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;">
            <div><h1 class="page-title">Manage Programs</h1><p class="page-subtitle">Add, edit, or remove academic programs.</p></div>
            <button class="btn btn-primary" onclick="openModal('add')">+ Add Program</button>
        </div>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead><tr><th>Program</th><th>University</th><th>Country</th><th>Degree</th><th>Deadline</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if(empty($programs)): ?>
                    <tr><td colspan="7" class="empty-state">No programs added yet.</td></tr>
                <?php else: foreach($programs as $p): ?>
                    <tr>
                        <td style="color:var(--text-primary);font-weight:500;"><?= htmlspecialchars($p['name']) ?></td>
                        <td><?= htmlspecialchars($p['university']) ?></td>
                        <td><?= htmlspecialchars($p['country']) ?></td>
                        <td><span class="badge blue"><?= htmlspecialchars($p['degree_level']) ?></span></td>
                        <td><?= $p['deadline'] ? date('M d, Y', strtotime($p['deadline'])) : '-' ?></td>
                        <td><span class="badge <?= $p['status'] ?>"><?= $p['status'] ?></span></td>
                        <td>
                            <button class="btn btn-outline btn-sm" onclick='openModal("edit",<?= json_encode($p) ?>)'>Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteItem(<?= $p['id'] ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Modal -->
<div class="modal-overlay" id="modal">
    <div class="modal">
        <h3 class="modal-title" id="modal-title">Add Program</h3>
        <form id="program-form">
            <input type="hidden" name="id" id="f-id">
            <input type="hidden" name="action" id="f-action" value="add">
            <div class="form-group"><label class="form-label">Program Name</label><input class="form-input" name="name" id="f-name" required></div>
            <div class="form-group"><label class="form-label">University</label><input class="form-input" name="university" id="f-university" required></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group"><label class="form-label">Country</label><input class="form-input" name="country" id="f-country" required></div>
                <div class="form-group"><label class="form-label">Degree Level</label>
                    <select class="form-select" name="degree_level" id="f-degree"><option value="Bachelor">Bachelor</option><option value="Master">Master</option><option value="PhD">PhD</option><option value="Diploma">Diploma</option></select>
                </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                <div class="form-group"><label class="form-label">Tuition</label><input class="form-input" name="tuition" id="f-tuition" placeholder="e.g. $25,000/year"></div>
                <div class="form-group"><label class="form-label">Deadline</label><input type="date" class="form-input" name="deadline" id="f-deadline"></div>
            </div>
            <div class="form-group"><label class="form-label">Duration</label><input class="form-input" name="duration" id="f-duration" placeholder="e.g. 2 years"></div>
            <div class="form-group"><label class="form-label">Description</label><textarea class="form-textarea" name="description" id="f-description"></textarea></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(mode, data=null) {
    document.getElementById('modal').classList.add('show');
    document.getElementById('f-action').value = mode === 'edit' ? 'edit' : 'add';
    document.getElementById('modal-title').textContent = mode === 'edit' ? 'Edit Program' : 'Add Program';
    if (data) {
        document.getElementById('f-id').value = data.id;
        document.getElementById('f-name').value = data.name;
        document.getElementById('f-university').value = data.university;
        document.getElementById('f-country').value = data.country;
        document.getElementById('f-degree').value = data.degree_level;
        document.getElementById('f-tuition').value = data.tuition || '';
        document.getElementById('f-deadline').value = data.deadline || '';
        document.getElementById('f-duration').value = data.duration || '';
        document.getElementById('f-description').value = data.description || '';
    } else {
        document.getElementById('program-form').reset();
        document.getElementById('f-id').value = '';
    }
}
function closeModal() { document.getElementById('modal').classList.remove('show'); }
document.getElementById('modal').addEventListener('click', function(e) { if (e.target === this) closeModal(); });

document.getElementById('program-form').addEventListener('submit', function(e) {
    e.preventDefault();
    fetch('api/programs.php', { method:'POST', body: new FormData(this) })
    .then(r=>r.json()).then(d=>{ if(d.success) location.reload(); else alert(d.message); });
});
function deleteItem(id) {
    if (!confirm('Delete this program?')) return;
    const fd = new FormData(); fd.append('action','delete'); fd.append('id', id);
    fetch('api/programs.php', { method:'POST', body: fd })
    .then(r=>r.json()).then(d=>{ if(d.success) location.reload(); else alert(d.message); });
}
</script>
</body>
</html>
