<?php
$current_admin_page = 'visa';
require_once 'includes/auth_check.php';

// Fetch all visa requests
$stmt = $pdo->query("
    SELECT vr.*, u.full_name as user_full_name, u.email as user_email 
    FROM visa_requests vr
    JOIN users u ON vr.user_id = u.id
    ORDER BY vr.created_at DESC
");
$requests = $stmt->fetchAll();

// Stats calculation
$totalRequests = count($requests);
$pendingRequests = count(array_filter($requests, fn($r) => $r['status'] === 'pending'));
$embassyRequests = count(array_filter($requests, fn($r) => $r['status'] === 'submitted_to_embassy'));
$approvedRequests = count(array_filter($requests, fn($r) => $r['status'] === 'approved'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visa Application Processing - Abrovia Admin</title>
    <link rel="stylesheet" href="../assets/css/admin-panel.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
        }
        .stat-card .stat-value {
            font-size: 2.2rem;
            font-weight: 800;
            color: #fff;
            margin-bottom: 4px;
        }
        .stat-card .stat-label {
            color: var(--text-muted);
            font-size: 0.85rem;
            text-transform: uppercase;
            font-weight: 600;
        }
        .filter-row {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }
        .admin-form-control {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            color: var(--text-white);
            padding: 12px;
            border-radius: 8px;
            font-family: inherit;
            font-size: 0.9rem;
            width: 100%;
        }
        .admin-form-control:focus {
            outline: none;
            border-color: var(--accent);
        }
        .badge-status {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: capitalize;
        }
        .badge-status.pending { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
        .badge-status.documents_verified { background: rgba(59, 130, 246, 0.15); color: #3b82f6; }
        .badge-status.submitted_to_embassy { background: rgba(139, 92, 246, 0.15); color: #8b5cf6; }
        .badge-status.approved { background: rgba(34, 197, 94, 0.15); color: #22c55e; }
        .badge-status.rejected { background: rgba(239, 68, 68, 0.15); color: #ef4444; }

        /* Document download layout */
        .doc-link-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--border);
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 10px;
            font-size: 0.88rem;
        }
        .doc-link-item a {
            color: var(--accent);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }
        .doc-link-item a:hover {
            color: #8b5cf6;
        }

        /* Verification Checkboxes */
        .verification-checklist {
            background: rgba(255,255,255,0.01);
            border: 1px dashed var(--border);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .verify-checkbox-label {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 8px 0;
            color: var(--text-white);
            font-weight: 500;
            font-size: 0.92rem;
        }
        .verify-checkbox-label input {
            width: 18px;
            height: 18px;
        }

        /* Modal specific layout */
        .modal {
            max-width: 600px !important;
        }
        .modal-body-split {
            display: grid;
            grid-template-columns: 1.2fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .info-label {
            font-size: 0.78rem;
            color: var(--text-muted);
            text-transform: uppercase;
            font-weight: 600;
        }
        .info-value {
            font-size: 0.92rem;
            color: var(--text-white);
            margin-bottom: 12px;
            font-weight: 500;
        }
        .btn-decision-row {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            border-top: 1px solid var(--border);
            padding-top: 15px;
        }
    </style>
</head>
<body>
<div class="admin-wrapper">
    <?php require_once 'includes/sidebar.php'; ?>

    <main class="admin-main">
        <div class="page-header">
            <h1 class="page-title">Process Visas</h1>
            <p class="page-subtitle">Verify user details, review uploaded papers, manage embassy submissions, and issue final approvals.</p>
        </div>

        <!-- STATS GRID -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?= $totalRequests ?></div>
                <div class="stat-label">Total Requests</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $pendingRequests ?></div>
                <div class="stat-label">Pending Review</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $embassyRequests ?></div>
                <div class="stat-label">Embassy Evaluated</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $approvedRequests ?></div>
                <div class="stat-label">Visas Issued</div>
            </div>
        </div>

        <!-- FILTER ROW -->
        <div class="filter-row">
            <div style="flex-grow:1;">
                <input type="text" id="searchVal" class="admin-form-control" placeholder="Search by student name, email, or passport..." oninput="filterTable()">
            </div>
            <div style="width: 200px;">
                <select id="filterCountry" class="admin-form-control" onchange="filterTable()">
                    <option value="">All Countries</option>
                    <?php 
                    $countries = array_unique(array_column($requests, 'country'));
                    foreach ($countries as $c):
                    ?>
                        <option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($c) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="width: 200px;">
                <select id="filterStatus" class="admin-form-control" onchange="filterTable()">
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="documents_verified">Documents Verified</option>
                    <option value="submitted_to_embassy">Submitted to Embassy</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                </select>
            </div>
        </div>

        <!-- APPLICATIONS TABLE -->
        <div class="data-table-wrap">
            <table class="data-table" id="visaTable">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Target Country</th>
                        <th>Passport Number</th>
                        <th>University / Program</th>
                        <th>Status</th>
                        <th>Applied Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($requests)): ?>
                        <tr><td colspan="7" class="empty-state">No visa processing requests found.</td></tr>
                    <?php else: foreach ($requests as $r): ?>
                        <tr class="visa-row">
                            <td class="student-info" style="color:var(--text-white); font-weight:600;">
                                <?= htmlspecialchars($r['user_full_name']) ?>
                                <br><span class="student-email" style="font-size:0.75rem; color:var(--text-muted); font-weight:normal;"><?= htmlspecialchars($r['user_email']) ?></span>
                            </td>
                            <td class="country-info" style="font-weight: 600;"><?= htmlspecialchars($r['country']) ?></td>
                            <td class="passport-info" style="font-family: monospace; font-size: 0.9rem;"><?= htmlspecialchars($r['passport_number']) ?></td>
                            <td>
                                <?= htmlspecialchars($r['university_name']) ?>
                                <br><span style="font-size: 0.78rem; color: var(--text-muted);"><?= htmlspecialchars($r['program_name']) ?></span>
                            </td>
                            <td>
                                <span class="badge-status <?= $r['status'] ?>"><?= str_replace('_', ' ', $r['status']) ?></span>
                            </td>
                            <td><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                            <td>
                                <button class="btn btn-primary btn-sm" onclick='openProcessModal(<?= json_encode($r) ?>)'>Process Visa</button>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- PROCESS VISA MODAL -->
<div class="modal-overlay" id="processModal">
    <div class="modal">
        <h3 class="modal-title">Process Visa Request</h3>
        <button class="modal-close" onclick="closeProcessModal()">&times;</button>
        
        <form id="verificationForm">
            <input type="hidden" id="requestId" name="id" value="">
            
            <div class="modal-body-split" style="margin-top: 15px;">
                <!-- User Profile Info -->
                <div>
                    <h4 style="font-size: 0.9rem; color: var(--accent); margin-bottom: 12px; font-weight: 700;">Student Passport Info</h4>
                    
                    <div class="info-label">Full Name</div>
                    <div class="info-value" id="mName"></div>
                    
                    <div class="info-label">Passport Number</div>
                    <div class="info-value" id="mPassport" style="font-family: monospace;"></div>
                    
                    <div class="info-label">Phone Number</div>
                    <div class="info-value" id="mPhone"></div>

                    <div class="info-label">Destination Country</div>
                    <div class="info-value" id="mCountry"></div>

                    <div class="info-label">University / Program</div>
                    <div class="info-value" id="mAcademic"></div>
                </div>

                <!-- Attached Papers -->
                <div>
                    <h4 style="font-size: 0.9rem; color: var(--accent); margin-bottom: 12px; font-weight: 700;">Uploaded Documents</h4>
                    
                    <div id="attachmentsContainer">
                        <!-- Populated dynamically -->
                    </div>
                </div>
            </div>

            <!-- Verification Stepper Checkboxes -->
            <div class="verification-checklist">
                <h4 style="font-size: 0.9rem; color: var(--text-white); margin-bottom: 10px; font-weight: 700;">Embassy Processing Checklists</h4>
                
                <label class="verify-checkbox-label">
                    <input type="checkbox" id="checkInfo" name="info_verified" value="1" onchange="toggleSaveVerificationBtn()">
                    <span>Student Profile & Passport Info Verified</span>
                </label>
                <label class="verify-checkbox-label">
                    <input type="checkbox" id="checkDocs" name="docs_verified" value="1" onchange="toggleSaveVerificationBtn()">
                    <span>Financial Solvency & Academic Documents Verified</span>
                </label>

                <div style="margin-top: 10px;">
                    <button type="button" class="btn btn-primary btn-sm" id="btnSaveVerification" onclick="saveVerifications()">Save Verifications</button>
                </div>
            </div>

            <!-- Counselor Notes -->
            <div class="form-group">
                <label class="form-label" style="font-weight: 600;">Counselor Advice & Review Feedback</label>
                <textarea class="form-textarea" id="mAdminNotes" name="admin_notes" style="min-height: 80px;" placeholder="Notes are visible to the student..."></textarea>
                <button type="button" class="btn btn-outline btn-sm" style="margin-top: 8px;" onclick="saveNotes()">Save Notes</button>
            </div>

            <!-- Embassy Action Block -->
            <div class="btn-decision-row">
                <button type="button" class="btn btn-outline" id="btnEmbassy" style="background: rgba(139, 92, 246, 0.1); color: #c084fc; border-color: rgba(139, 92, 246, 0.3);" onclick="submitToEmbassy()">Give Final Application to Embassy</button>
                <button type="button" class="btn btn-success" style="margin-left: auto;" onclick="finalizeDecision('approved')">Approve Visa</button>
                <button type="button" class="btn btn-danger" onclick="finalizeDecision('rejected')">Reject Visa</button>
            </div>
        </form>
    </div>
</div>

<script>
let activeRequest = null;

function openProcessModal(req) {
    activeRequest = req;
    
    document.getElementById('requestId').value = req.id;
    document.getElementById('mName').innerText = req.user_full_name;
    document.getElementById('mPassport').innerText = req.passport_number;
    document.getElementById('mPhone').innerText = req.phone;
    document.getElementById('mCountry').innerText = req.country;
    document.getElementById('mAcademic').innerHTML = `${req.university_name}<br><span style="font-size:0.8rem; color:var(--text-muted);">${req.program_name}</span>`;
    document.getElementById('mAdminNotes').value = req.admin_notes || '';

    // Checkboxes
    document.getElementById('checkInfo').checked = req.info_verified == 1;
    document.getElementById('checkDocs').checked = req.docs_verified == 1;

    // Documents download
    const docs = [
        { label: 'Passport Scan', file: req.passport_file },
        { label: 'Admission Letter', file: req.admission_letter_file },
        { label: 'Bank Statement', file: req.bank_statement_file },
        { label: 'Language Score Sheet', file: req.language_score_file }
    ];

    let docsHtml = '';
    docs.forEach(d => {
        if (d.file) {
            docsHtml += `
                <div class="doc-link-item">
                    <span>${d.label}</span>
                    <a href="../${d.file}" target="_blank">View File</a>
                </div>
            `;
        } else {
            docsHtml += `
                <div class="doc-link-item" style="opacity: 0.5;">
                    <span>${d.label}</span>
                    <span style="color: var(--text-muted);">Not Provided</span>
                </div>
            `;
        }
    });
    document.getElementById('attachmentsContainer').innerHTML = docsHtml;

    // Enable/disable embassy button depending on verifications
    toggleEmbassyBtnState();

    document.getElementById('processModal').classList.add('show');
}

function closeProcessModal() {
    document.getElementById('processModal').classList.remove('show');
    activeRequest = null;
}

function toggleSaveVerificationBtn() {
    document.getElementById('btnSaveVerification').disabled = false;
}

function toggleEmbassyBtnState() {
    const isInfoChecked = document.getElementById('checkInfo').checked;
    const isDocsChecked = document.getElementById('checkDocs').checked;
    const btn = document.getElementById('btnEmbassy');
    
    // Status tracking check
    if (isInfoChecked && isDocsChecked && activeRequest.status !== 'submitted_to_embassy' && activeRequest.status !== 'approved' && activeRequest.status !== 'rejected') {
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
    } else {
        btn.disabled = true;
        btn.style.opacity = '0.5';
        btn.style.cursor = 'not-allowed';
    }
}

// AJAX verifications save
function saveVerifications() {
    const id = document.getElementById('requestId').value;
    const info = document.getElementById('checkInfo').checked ? 1 : 0;
    const docs = document.getElementById('checkDocs').checked ? 1 : 0;

    const fd = new FormData();
    fd.append('action', 'update_verification');
    fd.append('id', id);
    fd.append('info_verified', info);
    fd.append('docs_verified', docs);

    fetch('api/visa.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
            location.reload();
        } else {
            alert(d.message);
        }
    });
}

// AJAX Embassy submit
function submitToEmbassy() {
    if (!confirm("Are you sure you want to submit the final application to the Embassy? This will change status to 'Submitted to Embassy'.")) return;
    
    const id = document.getElementById('requestId').value;
    const fd = new FormData();
    fd.append('action', 'submit_embassy');
    fd.append('id', id);

    fetch('api/visa.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
            location.reload();
        } else {
            alert(d.message);
        }
    });
}

// AJAX Decision finalization
function finalizeDecision(status) {
    if (!confirm(`Are you sure you want to finalize the visa request status as '${status.toUpperCase()}'?`)) return;

    const id = document.getElementById('requestId').value;
    const fd = new FormData();
    fd.append('action', 'finalize');
    fd.append('id', id);
    fd.append('status', status);

    fetch('api/visa.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
            location.reload();
        } else {
            alert(d.message);
        }
    });
}

// AJAX Save Notes
function saveNotes() {
    const id = document.getElementById('requestId').value;
    const notes = document.getElementById('mAdminNotes').value;

    const fd = new FormData();
    fd.append('action', 'save_notes');
    fd.append('id', id);
    fd.append('admin_notes', notes);

    fetch('api/visa.php', {
        method: 'POST',
        body: fd
    })
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            alert(d.message);
        } else {
            alert(d.message);
        }
    });
}

// Search & filter matching logic
function filterTable() {
    const search = document.getElementById('searchVal').value.toLowerCase();
    const country = document.getElementById('filterCountry').value;
    const status = document.getElementById('filterStatus').value;
    
    const rows = document.querySelectorAll('.visa-row');
    rows.forEach(row => {
        const student = row.querySelector('.student-info').innerText.toLowerCase();
        const passport = row.querySelector('.passport-info').innerText.toLowerCase();
        const rowCountry = row.querySelector('.country-info').innerText;
        const statusBadge = row.querySelector('.badge-status');
        const rowStatus = statusBadge ? statusBadge.classList[1] : '';

        const matchSearch = student.includes(search) || passport.includes(search);
        const matchCountry = !country || rowCountry === country;
        const matchStatus = !status || rowStatus === status;

        if (matchSearch && matchCountry && matchStatus) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Close modal on background click
document.getElementById('processModal').addEventListener('click', function(e) {
    if(e.target === this) closeProcessModal();
});
</script>
</body>
</html>
