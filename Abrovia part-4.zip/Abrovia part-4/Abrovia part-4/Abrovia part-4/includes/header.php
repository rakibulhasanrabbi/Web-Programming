<?php
$current_page = basename($_SERVER['PHP_SELF']);
$is_logged_in = isset($_SESSION['user_id']);
$unread_count = 0;
if ($is_logged_in) {
    try {
        global $pdo;
        if (!isset($pdo)) {
            require_once dirname(__DIR__) . '/config/database.php';
        }
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $countStmt->execute([$_SESSION['user_id']]);
        $unread_count = (int)$countStmt->fetchColumn();
    } catch (Exception $e) {
        // Silently catch in case db is not loaded
    }
}
?>
    <style>
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
        background: rgba(10, 14, 28, 0.85);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-bottom: 1px solid rgba(255, 255, 255, 0.06);
        padding: 0 40px;
        height: 64px;
        display: flex;
        align-items: center;
        font-family: 'Inter', sans-serif;
    }
    .nav-container {
        max-width: 100% !important;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        height: 100%;
    }
    .nav-logo-wrap {
        display: flex;
        align-items: center;
        gap: 12px;
        text-decoration: none;
    }
    .nav-logo-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 34px;
        height: 34px;
        color: #7c3aed; /* Purple from image */
    }
    .nav-logo-text {
        font-size: 1.35rem;
        font-weight: 700;
        color: #ffffff;
        letter-spacing: -0.5px;
    }
    .nav-links {
        display: flex;
        gap: 8px;
        list-style: none;
        margin: 0;
        padding: 0;
    }
    .nav-link {
        padding: 8px 14px;
        font-size: 0.85rem;
        font-weight: 400;
        color: #a0a7c4;
        border-radius: 8px;
        transition: all 0.3s ease;
        text-decoration: none;
    }
    .nav-link:hover, .nav-link.active {
        color: #ffffff;
    }
    .nav-link.active {
        background: rgba(108, 63, 255, 0.12);
        color: #c4b5fd;
    }
    .nav-actions {
        display: flex;
        align-items: center;
        gap: 24px;
    }
    .nav-login-link {
        font-size: 0.9rem;
        color: #a0a7c4;
        transition: color 0.3s ease;
        text-decoration: none;
        font-weight: 400;
    }
    .nav-login-link:hover, .nav-login-link.active {
        color: #ffffff;
    }
    .nav-notification-icon:hover, .nav-notification-icon.active {
        color: #ffffff !important;
    }
    .nav-apply-btn {
        padding: 10px 24px;
        font-size: 0.9rem;
        font-weight: 500;
        background: #7c3aed; /* Purple from image */
        color: #fff;
        border-radius: 10px;
        transition: all 0.3s ease;
        text-decoration: none;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .nav-apply-btn:hover {
        background: #8b5cf6;
        transform: translateY(-1px);
        box-shadow: 0 4px 15px rgba(124, 58, 237, 0.4);
    }
    @media (max-width: 1024px) {
        .nav-links { display: none; }
    }
    </style>
    <nav class="navbar" id="navbar">
        <div class="nav-container">
            <a href="index.php" class="nav-logo-wrap" id="nav-logo">
                <div class="nav-logo-icon" style="display: flex; align-items: center; justify-content: center; width: 28px; height: 28px; color: #7c3aed;"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" transform="rotate(45 12 12)"/><rect x="4" y="19" width="16" height="2" rx="1"/></svg></div>
                <span class="nav-logo-text">Abrovia</span>
            </a>
            <ul class="nav-links" id="nav-links">
                <li><a href="index.php" class="nav-link <?= $current_page == 'index.php' ? 'active' : '' ?>">Home</a></li>
                <li><a href="programs.php" class="nav-link <?= $current_page == 'programs.php' || $current_page == 'program-details.php' ? 'active' : '' ?>">Programs</a></li>
                <li><a href="scholarships.php" class="nav-link <?= $current_page == 'scholarships.php' || $current_page == 'scholarships-personalized.php' ? 'active' : '' ?>">Scholarships</a></li>
                <li><a href="university.php" class="nav-link <?= $current_page == 'university.php' || $current_page == 'university-details.php' ? 'active' : '' ?>">Universities</a></li>
                <li><a href="events.php" class="nav-link <?= $current_page == 'events.php' || $current_page == 'event-details.php' ? 'active' : '' ?>">Event</a></li>
                <li><a href="test-prep.php" class="nav-link <?= $current_page == 'test-prep.php' || $current_page == 'prep-center.php' ? 'active' : '' ?>">Test Prep</a></li>
                <li><a href="visa-guide.php" class="nav-link <?= $current_page == 'visa-guide.php' || $current_page == 'visa-guide.php' ? 'active' : '' ?>">Visa Guidance</a></li>
                <?php if (!$is_logged_in): ?>
                    <li><a href="ai-evaluation.php" class="nav-link <?= $current_page == 'ai-evaluation.php' ? 'active' : '' ?>">AI Evaluation</a></li>
                <?php endif; ?>
            </ul>
            <div class="nav-actions">
                <?php if ($is_logged_in): ?>
                    <a href="notifications.php" class="nav-notification-icon <?= $current_page == 'notifications.php' ? 'active' : '' ?>" id="nav-notifications" style="position: relative; display: flex; align-items: center; color: #a0a7c4; transition: color 0.3s; margin-right: 8px;" title="Notifications">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                        </svg>
                        <?php if ($unread_count > 0): ?>
                            <span style="position: absolute; top: 1px; right: 1px; width: 7px; height: 7px; background: #ef4444; border-radius: 50%;"></span>
                        <?php endif; ?>
                    </a>
                    <a href="dashboard.php" class="nav-login-link <?= $current_page == 'dashboard.php' ? 'active' : '' ?>" id="nav-dashboard">Dashboard</a>
                    <a href="application-form.php" class="nav-apply-btn" id="nav-apply-btn">Apply Now</a>
                <?php else: ?>
                    <a href="login.php" class="nav-login-link" id="nav-login">Login</a>
                    <a href="login.php" class="nav-apply-btn" id="nav-apply-btn">Apply Now</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
