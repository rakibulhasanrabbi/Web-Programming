    <style>
    .footer {
        padding: 60px 40px 30px;
        background: #080c18;
        border-top: 1px solid rgba(255, 255, 255, 0.06);
        color: #ffffff;
        font-family: 'Inter', sans-serif;
    }
    .footer-container {
        max-width: 1200px;
        margin: 0 auto;
    }
    .footer-top {
        display: flex;
        justify-content: space-between;
        gap: 60px;
        margin-bottom: 48px;
    }
    .footer-brand {
        max-width: 320px;
    }
    .footer-logo {
        font-size: 1.3rem;
        font-weight: 700;
        color: #ffffff !important;
        display: inline-block;
        margin-bottom: 14px;
        text-decoration: none;
    }
    .footer-brand-desc {
        font-size: 0.82rem;
        color: #6b7194;
        line-height: 1.7;
        margin: 0;
    }
    .footer-links-group {
        display: flex;
        gap: 60px;
    }
    .footer-col-title {
        font-size: 0.85rem;
        font-weight: 600;
        color: #ffffff;
        margin-bottom: 16px;
        margin-top: 0;
    }
    .footer-links {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    .footer-links li {
        margin-bottom: 10px;
    }
    .footer-links a {
        font-size: 0.82rem;
        color: #6b7194;
        transition: color 0.3s ease;
        text-decoration: none;
    }
    .footer-links a:hover {
        color: #a0a7c4;
    }
    .footer-bottom {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 28px;
        border-top: 1px solid rgba(255, 255, 255, 0.06);
    }
    .footer-social {
        display: flex;
        gap: 12px;
    }
    .social-icon {
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 8px;
        color: #6b7194;
        transition: all 0.3s ease;
        text-decoration: none;
    }
    .social-icon:hover {
        color: #ffffff;
        border-color: rgba(108, 63, 255, 0.3);
        background: rgba(108, 63, 255, 0.08);
    }
    .footer-copyright {
        font-size: 0.78rem;
        color: #6b7194;
        margin: 0;
    }
    @media (max-width: 768px) {
        .footer { padding: 40px 20px 24px; }
        .footer-top { flex-direction: column; gap: 36px; }
        .footer-links-group { gap: 36px; flex-wrap: wrap; }
        .footer-bottom { flex-direction: column-reverse; gap: 16px; text-align: center; }
    }
    </style>
    <footer class="footer" id="footer">
        <div class="footer-container">
            <div class="footer-top">
                <div class="footer-brand">
                    <a href="index.php" class="footer-logo-wrap" style="display: flex; align-items: center; gap: 10px; text-decoration: none; margin-bottom: 14px;">
                        <div class="footer-logo-icon" style="display: flex; align-items: center; justify-content: center; width: 28px; height: 28px; color: #7c3aed;"><svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" transform="rotate(45 12 12)"/><rect x="4" y="19" width="16" height="2" rx="1"/></svg></div>
                        <span class="footer-logo-text" style="font-size: 1.3rem; font-weight: 700; color: #ffffff;">Abrovia</span>
                    </a>
                    <p class="footer-brand-desc">Empowering students worldwide to achieve their global education dreams through excellent guidance and expert support.</p>
                </div>
                <div class="footer-links-group">
                    <div class="footer-links-col">
                        <h4 class="footer-col-title">Programs</h4>
                        <ul class="footer-links">
                            <li><a href="scholarships.php">Scholarships</a></li>
                            <li><a href="university.php">Universities</a></li>
                        </ul>
                    </div>
                    <div class="footer-links-col">
                        <h4 class="footer-col-title">App Guide</h4>
                        <ul class="footer-links">
                            <li><a href="test-prep.php">Test Prep</a></li>
                        </ul>
                    </div>
                    <div class="footer-links-col">
                        <h4 class="footer-col-title">Privacy Policy</h4>
                        <ul class="footer-links">
                            <li><a href="#">Terms of Service</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="footer-social">
                    <a href="#" class="social-icon" id="social-twitter" aria-label="Twitter">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                    </a>
                    <a href="#" class="social-icon" id="social-instagram" aria-label="Instagram">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                    </a>
                </div>
                <p class="footer-copyright">© 2026 Abrovia Global Education. Empowering students worldwide.</p>
            </div>
        </div>
    </footer>
