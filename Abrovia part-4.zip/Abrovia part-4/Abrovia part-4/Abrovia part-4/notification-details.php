<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
require_once 'config/database.php';

$notif_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE id = ? AND user_id = ?");
$stmt->execute([$notif_id, $_SESSION['user_id']]);
$notification = $stmt->fetch();

if (!$notification) {
    header('Location: notifications.php');
    exit;
}

// Mark as read
$update = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
$update->execute([$notif_id]);

// Categorize message for visual styling
$msg_lower = strtolower($notification['message']);
$notif_bg = 'blue-bg';
$notif_title = 'Notification Update';
$notif_svg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>';

if (strpos($msg_lower, 'scholarship') !== false) {
    $notif_bg = 'purple-bg';
    $notif_title = 'Scholarship Announcement';
    $notif_svg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>';
} elseif (strpos($msg_lower, 'application') !== false || strpos($msg_lower, 'apply') !== false || strpos($msg_lower, 'approved') !== false || strpos($msg_lower, 'declined') !== false || strpos($msg_lower, 'accepted') !== false || strpos($msg_lower, 'rejected') !== false || strpos($msg_lower, 'status') !== false) {
    $notif_bg = 'yellow-bg';
    $notif_title = 'Application Status Update';
    $notif_svg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>';
} elseif (strpos($msg_lower, 'event') !== false) {
    $notif_bg = 'purple-bg';
    $notif_title = 'Event Booking Confirmation';
    $notif_svg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>';
} elseif (strpos($msg_lower, 'consultation') !== false || strpos($msg_lower, 'advisor') !== false || strpos($msg_lower, 'session') !== false) {
    $notif_bg = 'blue-bg';
    $notif_title = 'Consultation Update';
    $notif_svg = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification Details - Abrovia</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
        :root{--bg:#0b0f1e;--card:#131836;--border:rgba(255,255,255,0.07);--accent:#7c3aed;--text:#fff;--text2:#a0a7c4;--text3:#5c6490;}
        body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased;}
        a{text-decoration:none;color:inherit;}
        .page-container{max-width:700px;margin:0 auto;padding:120px 24px 60px;}
        .back-link{display:inline-flex;align-items:center;gap:6px;color:var(--accent);font-size:0.9rem;font-weight:500;margin-bottom:24px;transition:color 0.3s;}
        .back-link:hover{color:#8b5cf6;}
        
        .detail-card{background:var(--card);border:1px solid var(--border);border-radius:16px;padding:40px;box-shadow:0 10px 30px rgba(0,0,0,0.3);}
        
        .detail-header{display:flex;align-items:center;gap:20px;margin-bottom:32px;}
        .detail-icon{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
        .purple-bg{background:rgba(124,58,237,0.12);color:#c084fc;}
        .yellow-bg{background:rgba(245,158,11,0.12);color:#fbbf24;}
        .blue-bg{background:rgba(59,130,246,0.12);color:#60a5fa;}
        
        .detail-header-text{flex:1;}
        .detail-title{font-size:1.4rem;font-weight:800;margin-bottom:4px;letter-spacing:-0.5px;}
        .detail-time{font-size:0.8rem;color:var(--text3);font-weight:500;}
        
        .detail-body{font-size:1.05rem;color:var(--text2);line-height:1.8;padding:24px 0 32px;border-top:1px solid var(--border);border-bottom:1px solid var(--border);margin-bottom:32px;white-space:pre-wrap;}
        
        .btn-action{display:inline-block;padding:12px 28px;font-size:0.9rem;font-weight:600;background:var(--accent);color:#fff;border-radius:10px;transition:all 0.3s;}
        .btn-action:hover{background:#8b5cf6;transform:translateY(-1px);box-shadow:0 4px 15px rgba(124,58,237,0.4);}
    </style>
</head>
<body>
    <?php require_once 'includes/header.php'; ?>

    <div class="page-container">
        <a href="notifications.php" class="back-link">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            Back to Notifications
        </a>

        <div class="detail-card">
            <div class="detail-header">
                <div class="detail-icon <?= $notif_bg ?>">
                    <?= $notif_svg ?>
                </div>
                <div class="detail-header-text">
                    <h1 class="detail-title"><?= htmlspecialchars($notif_title) ?></h1>
                    <span class="detail-time"><?= date('F d, Y \a\t h:i A', strtotime($notification['created_at'])) ?></span>
                </div>
            </div>
            
            <div class="detail-body">
                <?= htmlspecialchars($notification['message']) ?>
            </div>
            
            <a href="notifications.php" class="btn-action">Return to Notifications</a>
        </div>
    </div>

    <?php require_once 'includes/footer.php'; ?>
</body>
</html>
