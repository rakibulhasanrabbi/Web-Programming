<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$program = null;

if ($id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM programs WHERE id = ?");
    $stmt->execute([$id]);
    $program = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fallback to beautiful standard program if no matching found
if (!$program) {
    $program = [
        'id' => 0,
        'name' => 'MSc Computer Science',
        'university' => 'Imperial College London',
        'country' => 'UK',
        'degree_level' => 'Master',
        'tuition' => '£28,500/year',
        'deadline' => '2026-08-31',
        'duration' => '1 Year',
        'description' => 'This advanced program provides deep theoretical knowledge and practical engineering experience in artificial intelligence, software design, and distributed systems. It is aimed at graduates with a solid computer science background wishing to specialise or fast-track their careers in technology.'
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($program['name']) ?> - Abrovia</title>
    <!-- Reuse premium university-details styles for flawless layout consistency -->
    <link rel="stylesheet" href="assets/css/university-details.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .detail-badge-group {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 24px;
        }
        .detail-badge-item {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 14px 20px;
            flex: 1;
            min-width: 140px;
            text-align: center;
        }
        .detail-badge-label {
            display: block;
            font-size: 0.68rem;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 4px;
        }
        .detail-badge-value {
            display: block;
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--text-primary);
        }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <?php require_once 'includes/header.php'; ?>

    <!-- HERO BANNER -->
    <section class="hero-banner" id="hero-banner">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <div class="hero-badges">
                <span class="hero-badge">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                        <circle cx="12" cy="10" r="3"/>
                    </svg> 
                    <?= htmlspecialchars($program['country']) ?>
                </span>
                <span class="hero-badge">★ <?= htmlspecialchars($program['degree_level']) ?> Degree</span>
            </div>
            <h1 class="hero-title"><?= htmlspecialchars($program['name']) ?></h1>
            <p class="hero-desc"><?= htmlspecialchars($program['university']) ?></p>
            <a href="application-form.php?source=program&id=<?= $program['id'] ?>" class="btn-apply" id="btn-apply-now">Apply Now <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
    </section>

    <!-- ABOUT & KEY HIGHLIGHTS -->
    <section class="about-section" id="about-section">
        <div class="about-container">
            <div class="about-left">
                <h2 class="section-title">Program Description</h2>
                <p class="about-text" style="font-size: 0.95rem; line-height: 1.7; color: var(--text-secondary); margin-bottom: 24px;">
                    <?= nl2br(htmlspecialchars($program['description'])) ?>
                </p>

                <h3 class="section-title" style="font-size: 1.25rem; margin-top: 32px; margin-bottom: 16px;">Core Details</h3>
                <div class="detail-badge-group">
                    <div class="detail-badge-item">
                        <span class="detail-badge-label">Tuition Fee</span>
                        <span class="detail-badge-value"><?= htmlspecialchars($program['tuition'] ?: 'N/A') ?></span>
                    </div>
                    <div class="detail-badge-item">
                        <span class="detail-badge-label">Duration</span>
                        <span class="detail-badge-value"><?= htmlspecialchars($program['duration'] ?: 'N/A') ?></span>
                    </div>
                    <div class="detail-badge-item">
                        <span class="detail-badge-label">Deadline</span>
                        <span class="detail-badge-value"><?= $program['deadline'] ? date('M d, Y', strtotime($program['deadline'])) : 'Rolling' ?></span>
                    </div>
                </div>
            </div>
            
            <div class="about-right">
                <div class="highlights-card">
                    <h3 class="highlights-title">Academic Environment</h3>
                    <div class="highlight-item">
                        <div class="highlight-icon purple">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5"/></svg>
                        </div>
                        <div>
                            <h4 class="highlight-name">World Class Degree</h4>
                            <p class="highlight-desc">Accredited qualification recognized globally by industry leaders.</p>
                        </div>
                    </div>
                    <div class="highlight-item">
                        <div class="highlight-icon blue">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                        </div>
                        <div>
                            <h4 class="highlight-name">Flexible Study Options</h4>
                            <p class="highlight-desc">Designed to accommodate interactive, modern learning methods.</p>
                        </div>
                    </div>
                    <div class="highlight-item">
                        <div class="highlight-icon green">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                        </div>
                        <div>
                            <h4 class="highlight-name">Elite Networking</h4>
                            <p class="highlight-desc">Join alumni networks spanning tech, engineering, and corporate domains.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <?php require_once 'includes/footer.php'; ?>

<script>
// Ready for search integrations if needed
</script>
</body>
</html>
