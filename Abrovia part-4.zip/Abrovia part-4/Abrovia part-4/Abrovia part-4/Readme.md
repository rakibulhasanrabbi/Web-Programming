# Abrovia - Study Abroad Management System
 
## 📖 Overview
 
Abrovia is a web-based Study Abroad Management System designed to simplify the entire overseas admission process for students, counselors, and administrators. The platform allows students to explore universities, programs, scholarships, submit applications, track their application status, and request visa assistance from a single dashboard.
 
The system also provides an admin panel for managing users, applications, universities, scholarships, events, consultations, and visa requests.
  
## ✨ Features
 
### Student Features
 
 
- User registration and login
 
- Browse universities and programs
 
- View scholarship opportunities
 
- Apply for universities online
 
- Track application progress
 
- Upload required documents
 
- Request visa assistance
 
- Book consultation sessions
 
- Participate in events
 
- AI-based application evaluation
 
- Save favorite items
 

 
### Admin Features
 
 
- Secure admin authentication
 
- Dashboard with application overview
 
- Manage students and administrators
 
- Manage universities and programs
 
- Manage scholarships
 
- Review and process applications
 
- Handle consultation requests
 
- Manage events
 
- Process visa requests
 
- Manage university contact information
 

  
## 🛠️ Technologies Used
 
### Frontend
 
 
- HTML5
 
- CSS3
 
- JavaScript
 

 
### Backend
 
 
- PHP
 

 
### Database
 
 
- MySQL
 

 
### Server
 
 
- XAMPP / Apache
 

  
## 📂 Project Structure
 `Project_2/ │ ├── admin/                 # Admin panel ├── api/                   # Backend API endpoints ├── assets/ │   ├── css/ │   ├── js/ │   └── images/ ├── database.sql           # Database schema ├── index.php ├── login.php ├── register.php └── ... `  
## ⚙️ Installation
 
### 1. Clone the repository
 `git clone https://github.com/your-username/abrovia.git ` 
### 2. Move the project
 
Copy the project folder into your XAMPP `htdocs` directory.
 
Example:
 `C:\xampp\htdocs\abrovia ` 
### 3. Import the database
 
 
- Open phpMyAdmin
 
- Create a new database
 
- Import `database.sql`
 

 
The default database name is:
 `abrovia_db_2 ` 
### 4. Configure database connection
 
Update your database credentials in the PHP configuration file if necessary.
 
Example:
 `Host: localhost Username: root Password: Database: abrovia_db_2 ` 
### 5. Start the server
 
Start:
 
 
- Apache
 
- MySQL
 

 
from the XAMPP Control Panel.
 
### 6. Run the project
 
Open your browser and visit:
 `http://localhost/abrovia `  
## 🗄️ Database
 
The project uses MySQL with relational tables for:
 
 
- Users
 
- Applications
 
- Documents
 
- Universities
 
- Programs
 
- Scholarships
 
- Events
 
- Consultations
 
- Visa Requests
 
- Administrators
 

 
The complete database schema is included in:
 `database.sql `  
## 🔒 Security Features
 
 
- Password hashing
 
- Role-based authentication
 
- Admin authorization
 
- Input validation
 
- Session management
 
- Secure database relationships using foreign keys
 

  
## 🚀 Future Improvements
 
 
- Email notifications
 
- Real-time application tracking
 
- Payment gateway integration
 
- Chat support
 
- AI-powered university recommendations
 
- Document verification using OCR
 
- Mobile application
 
- Multi-language support
 

  
## 📸 Screenshots
 
Add screenshots of:
 
 
- Home Page
 
- Student Dashboard
 
- Admin Dashboard
 
- Application Form
 
- Scholarship Page
 
- AI Evaluation Page
 

  
## 👨‍💻 Developers
 
Developed as a university project for learning full-stack web development using PHP and MySQL.
  
## 📄 License
 
This project is intended for educational purposes only.
