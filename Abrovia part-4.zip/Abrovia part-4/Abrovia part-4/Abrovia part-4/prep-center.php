<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=test-prep.php');
    exit;
}

require_once 'config/database.php';

$courseSlug = $_GET['course'] ?? '';
if (empty($courseSlug)) {
    header('Location: test-prep.php');
    exit;
}

// Fetch course
$stmt = $pdo->prepare("SELECT * FROM courses WHERE slug = ? AND status = 'active'");
$stmt->execute([$courseSlug]);
$course = $stmt->fetch();

if (!$course) {
    header('Location: test-prep.php');
    exit;
}

// Check enrollment
$stmt = $pdo->prepare("SELECT * FROM enrollments WHERE user_id = ? AND course_id = ?");
$stmt->execute([$_SESSION['user_id'], $course['id']]);
$enrollment = $stmt->fetch();

if (!$enrollment || $enrollment['status'] !== 'active') {
    header('Location: test-prep.php?error=not_enrolled');
    exit;
}

// Fetch course content
$stmt = $pdo->prepare("SELECT * FROM course_content WHERE course_id = ? AND status = 'active' ORDER BY sort_order ASC");
$stmt->execute([$course['id']]);
$allContent = $stmt->fetchAll();

// Group content by type
$contentByType = [
    'material' => [],
    'book' => [],
    'practice_question' => [],
    'viva' => [],
    'recorded_class' => [],
    'live_class' => [],
    'practice_exam' => []
];

foreach ($allContent as $item) {
    if (isset($contentByType[$item['type']])) {
        $contentByType[$item['type']][] = $item;
    }
}

$activeTab = $_GET['tab'] ?? 'overview';
$typeLabels = [
    'overview' => 'Overview',
    'material' => 'Course Materials',
    'book' => 'Books & Guides',
    'practice_question' => 'Practice Questions',
    'viva' => 'Practice Viva',
    'recorded_class' => 'Recorded Classes',
    'live_class' => 'Live Classes',
    'practice_exam' => 'Practice Exams'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($course['name']) ?> - Prep Center - Abrovia</title>
    <link rel="stylesheet" href="assets/css/prep-center.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <!-- NAVBAR -->
    <?php require_once 'includes/header.php'; ?>

    <div class="page-layout">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <h2 class="sidebar-title"><?= htmlspecialchars($course['name']) ?></h2>
                <p class="sidebar-subtitle">Student Prep Center</p>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="prep-center.php?course=<?= urlencode($courseSlug) ?>&tab=overview" class="sidebar-link <?= $activeTab === 'overview' ? 'active' : '' ?>">
                            <span class="nav-icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg></span>
                            Overview
                        </a>
                    </li>
                    <?php foreach ($typeLabels as $type => $label): 
                        if ($type === 'overview') continue;
                        $count = count($contentByType[$type]);
                    ?>
                        <li>
                            <a href="prep-center.php?course=<?= urlencode($courseSlug) ?>&tab=<?= $type ?>" class="sidebar-link <?= $activeTab === $type ? 'active' : '' ?>">
                                <span class="nav-icon">
                                    <?php if ($type === 'material'): ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                                    <?php elseif ($type === 'book'): ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                                    <?php elseif ($type === 'practice_question'): ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                    <?php elseif ($type === 'viva'): ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
                                    <?php elseif ($type === 'recorded_class'): ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
                                    <?php elseif ($type === 'live_class'): ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: #ef4444;"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3" fill="#ef4444"/></svg>
                                    <?php elseif ($type === 'practice_exam'): ?>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
                                    <?php endif; ?>
                                </span>
                                <?= $label ?>
                                <span class="tab-badge"><?= $count ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">
            <?php if ($activeTab === 'overview'): ?>
                <!-- OVERVIEW TAB -->
                <header class="content-header">
                    <h1 class="page-title">Welcome to <?= htmlspecialchars($course['name']) ?></h1>
                    <p class="page-subtitle"><?= htmlspecialchars($course['description']) ?></p>
                </header>

                <div class="overview-grid">
                    <!-- Progress Card -->
                    <div class="overview-card progress-card">
                        <div class="progress-ring-container">
                            <svg class="progress-ring" width="120" height="120">
                                <circle class="progress-ring-circle-bg" stroke="rgba(255,255,255,0.05)" stroke-width="8" fill="transparent" r="50" cx="60" cy="60"/>
                                <circle class="progress-ring-circle" stroke="var(--accent)" stroke-width="8" fill="transparent" r="50" cx="60" cy="60" 
                                    style="stroke-dasharray: 314.16; stroke-dashoffset: <?= 314.16 - (314.16 * $enrollment['progress_percent'] / 100) ?>;"/>
                            </svg>
                            <span class="progress-text"><?= intval($enrollment['progress_percent']) ?>%</span>
                        </div>
                        <div>
                            <h3 class="card-headline">Course Progress</h3>
                            <p class="card-subtext">Enrolled on <?= date('d M, Y', strtotime($enrollment['enrolled_at'])) ?></p>
                            <p class="card-subtext">Suggested duration: <?= intval($course['duration_weeks']) ?> weeks</p>
                        </div>
                    </div>

                    <!-- Stats Card -->
                    <div class="overview-card stats-card">
                        <h3 class="card-headline" style="margin-bottom: 20px;">Learning Materials Summary</h3>
                        <div class="stats-mini-grid">
                            <div class="stat-mini-item">
                                <span class="stat-val"><?= count($contentByType['material']) ?></span>
                                <span class="stat-lbl">Guides</span>
                            </div>
                            <div class="stat-mini-item">
                                <span class="stat-val"><?= count($contentByType['book']) ?></span>
                                <span class="stat-lbl">Books</span>
                            </div>
                            <div class="stat-mini-item">
                                <span class="stat-val"><?= count($contentByType['recorded_class']) ?></span>
                                <span class="stat-lbl">Videos</span>
                            </div>
                            <div class="stat-mini-item">
                                <span class="stat-val"><?= count($contentByType['practice_exam']) ?></span>
                                <span class="stat-lbl">Exams</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="quick-links-section">
                    <h3 class="section-title-sm">Quick Jump to Topics</h3>
                    <div class="quick-links-grid">
                        <?php foreach ($typeLabels as $type => $label): 
                            if ($type === 'overview') continue;
                        ?>
                            <a href="prep-center.php?course=<?= urlencode($courseSlug) ?>&tab=<?= $type ?>" class="quick-link-box">
                                <span class="quick-link-label"><?= $label ?></span>
                                <span class="quick-link-count"><?= count($contentByType[$type]) ?> items</span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>

            <?php else: ?>
                <!-- CONTENT TABS -->
                <header class="content-header">
                    <h1 class="page-title"><?= $typeLabels[$activeTab] ?></h1>
                    <p class="page-subtitle">Access your dynamic <?= strtolower($typeLabels[$activeTab]) ?> below.</p>
                </header>

                <?php 
                $items = $contentByType[$activeTab] ?? [];
                if (empty($items)): 
                ?>
                    <div class="empty-state">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/><path d="M12 8v8"/></svg>
                        <h3>No Materials Found</h3>
                        <p>No active <?= strtolower($typeLabels[$activeTab]) ?> have been uploaded for this course yet.</p>
                    </div>
                <?php else: ?>
                    <div class="content-grid">
                        <?php foreach ($items as $item): ?>
                            <div class="content-card">
                                <div class="card-icon-header">
                                    <div class="card-item-icon <?= $activeTab ?>-theme">
                                        <?php if ($activeTab === 'material'): ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                                        <?php elseif ($activeTab === 'book'): ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                                        <?php elseif ($activeTab === 'practice_question'): ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                        <?php elseif ($activeTab === 'viva'): ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>
                                        <?php elseif ($activeTab === 'recorded_class'): ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
                                        <?php elseif ($activeTab === 'live_class'): ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/></svg>
                                        <?php elseif ($activeTab === 'practice_exam'): ?>
                                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="card-meta-badges">
                                        <?php if ($item['is_free_preview']): ?>
                                            <span class="preview-badge">Free Preview</span>
                                        <?php endif; ?>
                                        <?php if ($item['duration_minutes']): ?>
                                            <span class="duration-badge"><?= intval($item['duration_minutes']) ?> mins</span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <h3 class="item-title"><?= htmlspecialchars($item['title']) ?></h3>
                                <p class="item-desc"><?= htmlspecialchars($item['description']) ?></p>

                                <div class="card-footer">
                                    <button class="btn-item-action" onclick="alert('Demo: This content resource is loading... In production, this will display the course video/doc directly.')">
                                        <?php if ($activeTab === 'material'): ?>
                                            View Document
                                        <?php elseif ($activeTab === 'book'): ?>
                                            Read Book
                                        <?php elseif ($activeTab === 'practice_question'): ?>
                                            Solve Practice Set
                                        <?php elseif ($activeTab === 'viva'): ?>
                                            Start Viva Session
                                        <?php elseif ($activeTab === 'recorded_class'): ?>
                                            Watch Video Lecture
                                        <?php elseif ($activeTab === 'live_class'): ?>
                                            Join Live Stream
                                        <?php elseif ($activeTab === 'practice_exam'): ?>
                                            Begin Mock Exam
                                        <?php endif; ?>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <!-- FOOTER -->
        <?php require_once 'includes/footer.php'; ?>
        </main>
    </div>

</body>
</html>
