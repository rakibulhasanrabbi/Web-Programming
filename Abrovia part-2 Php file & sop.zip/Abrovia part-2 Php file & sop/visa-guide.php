<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

$error = '';
$success = isset($_GET['success']) && $_GET['success'] == 1;

// Handle Visa Processing Request Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_visa_request'])) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php?redirect=visa-guide.php');
        exit;
    }

    $userId = $_SESSION['user_id'];
    $country = trim($_POST['country'] ?? '');
    $passport_number = trim($_POST['passport_number'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $university_name = trim($_POST['university_name'] ?? '');
    $program_name = trim($_POST['program_name'] ?? '');

    if (empty($country) || empty($passport_number) || empty($full_name) || empty($phone) || empty($university_name) || empty($program_name)) {
        $error = 'All fields are required.';
    } else {
        try {
            $upload_dir = 'uploads/visa/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $passport_file_path = null;
            $admission_letter_file_path = null;
            $bank_statement_file_path = null;
            $language_score_file_path = null;

            // Handle uploads
            $files_map = [
                'passport_file' => &$passport_file_path,
                'admission_letter_file' => &$admission_letter_file_path,
                'bank_statement_file' => &$bank_statement_file_path,
                'language_score_file' => &$language_score_file_path
            ];

            foreach ($files_map as $input_name => &$file_var) {
                if (isset($_FILES[$input_name]) && $_FILES[$input_name]['error'] === UPLOAD_ERR_OK) {
                    $tmpName = $_FILES[$input_name]['tmp_name'];
                    $orig_name = $_FILES[$input_name]['name'];
                    $clean_name = preg_replace("/[^a-zA-Z0-9\._-]/", "_", $orig_name);
                    $fileName = $input_name . '_' . $userId . '_' . time() . '_' . $clean_name;
                    $destPath = $upload_dir . $fileName;

                    if (move_uploaded_file($tmpName, $destPath)) {
                        $file_var = $destPath;
                    }
                }
            }

            // Insert request
            $stmt = $pdo->prepare("
                INSERT INTO visa_requests 
                (user_id, country, passport_number, full_name, phone, university_name, program_name, status, passport_file, admission_letter_file, bank_statement_file, language_score_file)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?)
            ");
            $stmt->execute([
                $userId,
                $country,
                $passport_number,
                $full_name,
                $phone,
                $university_name,
                $program_name,
                $passport_file_path,
                $admission_letter_file_path,
                $bank_statement_file_path,
                $language_score_file_path
            ]);

            // Notification
            $notif_msg = "Your study visa processing request for " . htmlspecialchars($country) . " has been submitted successfully (Status: Pending Review).";
            $notif_stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
            $notif_stmt->execute([$userId, $notif_msg]);

            header('Location: visa-guide.php?success=1');
            exit;

        } catch (Exception $e) {
            $error = 'Failed to submit visa request: ' . $e->getMessage();
        }
    }
}

// Fetch user latest visa request
$visaRequest = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM visa_requests WHERE user_id = ? ORDER BY id DESC LIMIT 1");
    $stmt->execute([$_SESSION['user_id']]);
    $visaRequest = $stmt->fetch();
}

$defaultTab = 'overview';
if ($success || $error || ($visaRequest && $visaRequest['status'] !== 'rejected')) {
    $defaultTab = 'tracking';
}
if ($visaRequest && isset($_GET['reapply'])) {
    $defaultTab = 'application';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visa Assistance & Guidance - Abrovia</title>
    <link rel="stylesheet" href="assets/css/visa-guide.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        .tab-panel {
            display: none;
        }
        .tab-panel.active {
            display: block;
            animation: fadeIn 0.4s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Glassmorphic Visa Form */
        .visa-form-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 40px;
            margin-bottom: 40px;
        }
        .form-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .form-desc {
            color: var(--text-gray);
            font-size: 0.9rem;
            margin-bottom: 30px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .form-group label {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-white);
        }
        .form-control {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            color: var(--text-white);
            padding: 12px 16px;
            border-radius: var(--radius-sm);
            font-family: inherit;
            font-size: 0.9rem;
            transition: var(--transition);
        }
        .form-control:focus {
            outline: none;
            border-color: var(--accent);
            background: rgba(255, 255, 255, 0.05);
        }
        .file-upload-box {
            border: 1px dashed var(--border);
            padding: 12px;
            border-radius: var(--radius-sm);
            background: rgba(255,255,255,0.01);
            color: var(--text-gray);
            font-size: 0.85rem;
            cursor: pointer;
            text-align: center;
            transition: var(--transition);
        }
        .file-upload-box:hover {
            border-color: var(--accent);
            background: rgba(108,63,255,0.03);
        }
        .btn-submit {
            background: linear-gradient(135deg, var(--accent), #8b5cf6);
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: var(--radius-sm);
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: var(--transition);
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(108,63,255,0.4);
        }

        /* Stepper Visual Timeline */
        .stepper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            position: relative;
            background: rgba(255,255,255,0.01);
            border: 1px solid var(--border);
            padding: 24px;
            border-radius: var(--radius-md);
        }
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            z-index: 2;
            flex: 1;
            text-align: center;
        }
        .step-circle {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #1c233d;
            border: 2px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-bottom: 8px;
            transition: var(--transition);
        }
        .step-lbl {
            font-size: 0.78rem;
            font-weight: 600;
            color: var(--text-muted);
            transition: var(--transition);
        }
        .step.active .step-circle {
            background: var(--accent);
            border-color: var(--accent);
            color: white;
            box-shadow: 0 0 15px rgba(108,63,255,0.4);
        }
        .step.active .step-lbl {
            color: white;
        }
        .step.done .step-circle {
            background: #10b981;
            border-color: #10b981;
            color: white;
        }
        .step.done .step-lbl {
            color: #34d399;
        }

        /* Status alerts and data details */
        .tracking-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 30px;
        }
        .badge-visa {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 15px;
        }
        .badge-visa.pending { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
        .badge-visa.documents_verified { background: rgba(59, 130, 246, 0.15); color: #3b82f6; }
        .badge-visa.submitted_to_embassy { background: rgba(139, 92, 246, 0.15); color: #8b5cf6; }
        .badge-visa.approved { background: rgba(34, 197, 94, 0.15); color: #22c55e; }
        .badge-visa.rejected { background: rgba(239, 68, 68, 0.15); color: #ef4444; }

        .tracking-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 30px;
            margin-top: 20px;
        }
        .tracking-info-item {
            border-bottom: 1px solid var(--border);
            padding: 8px 0;
        }
        .tracking-lbl {
            font-size: 0.75rem;
            color: var(--text-muted);
            text-transform: uppercase;
            font-weight: 600;
        }
        .tracking-val {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--text-white);
            margin-top: 4px;
        }

        .feedback-bubble {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid var(--border);
            padding: 20px;
            border-radius: 12px;
            margin-top: 25px;
        }
        .feedback-title {
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--accent);
            text-transform: uppercase;
            margin-bottom: 8px;
        }
        .feedback-text {
            font-size: 0.9rem;
            color: var(--text-gray);
            line-height: 1.6;
        }
        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #f87171;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 500;
        }
        .alert-success {
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.4);
            color: #34d399;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-weight: 500;
        }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <?php require_once 'includes/header.php'; ?>

    <!-- SIDEBAR + MAIN CONTENT -->
    <div class="page-layout">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2 class="sidebar-title">Visa Center</h2>
                <p class="sidebar-subtitle">Global Guidance</p>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="#" class="sidebar-link <?= $defaultTab === 'overview' ? 'active' : '' ?>" data-target="overview"><span class="nav-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg></span> Overview</a></li>
                    <li><a href="#" class="sidebar-link <?= $defaultTab === 'documents' ? 'active' : '' ?>" data-target="documents"><span class="nav-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></span> Documents</a></li>
                    <li><a href="#" class="sidebar-link <?= $defaultTab === 'application' ? 'active' : '' ?>" data-target="application"><span class="nav-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg></span> Application</a></li>
                    <li><a href="#" class="sidebar-link <?= $defaultTab === 'tracking' ? 'active' : '' ?>" data-target="tracking"><span class="nav-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/></svg></span> Tracking</a></li>
                    <li><a href="#" class="sidebar-link" data-target="interview"><span class="nav-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></span> Interview</a></li>
                </ul>
            </nav>
            <button class="btn-consultation" onclick="alert('Demo: Requesting an expert consultation. A counselor will contact you shortly.')">Expert Consultation</button>
        </aside>

        <!-- MAIN AREA -->
        <main class="main-content">
            <!-- ALERTS -->
            <?php if (!empty($error)): ?>
                <div class="alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert-success">Visa processing request submitted successfully! Monitor updates under the Tracking tab.</div>
            <?php endif; ?>

            <!-- OVERVIEW PANEL -->
            <div id="panel-overview" class="tab-panel <?= $defaultTab === 'overview' ? 'active' : '' ?>">
                <header class="hero">
                    <h1 class="hero-title">Global Visa Assistance</h1>
                    <p class="hero-subtitle">Get structural assistance for student visa processing. Apply directly to our admin team, submit files for verification, and track embassy final submissions.</p>
                </header>

                <section class="process-section">
                    <h2 class="section-title">Embassy Processing Journey</h2>
                    <div class="process-grid">
                        <div class="process-card">
                            <div class="card-icon-wrap purple-glow">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                            </div>
                            <h3 class="step-title">Step 1:<br>Assistance Request</h3>
                            <p class="step-desc">Provide target academic details, passport identification, and initial files in the Application tab.</p>
                        </div>
                        <div class="process-card">
                            <div class="card-icon-wrap pink-glow">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                            </div>
                            <h3 class="step-title">Step 2:<br>Verification review</h3>
                            <p class="step-desc">Our counselors review user profiles and verify solvency papers against destination rules.</p>
                        </div>
                        <div class="process-card">
                            <div class="card-icon-wrap blue-glow">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>
                            </div>
                            <h3 class="step-title">Step 3:<br>Embassy Dispatch</h3>
                            <p class="step-desc">Once verified, our team dispatches your final application docket to the respective embassy.</p>
                        </div>
                        <div class="process-card">
                            <div class="card-icon-wrap green-glow">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                            </div>
                            <h3 class="step-title">Step 4:<br>Final Decision</h3>
                            <p class="step-desc">Complete consulate interviews and track final visa stamp issuance.</p>
                        </div>
                    </div>
                </section>
            </div>

            <!-- DOCUMENTS PANEL -->
            <div id="panel-documents" class="tab-panel <?= $defaultTab === 'documents' ? 'active' : '' ?>">
                <section class="documents-section" style="max-width: 800px; margin: 0 auto;">
                    <div class="documents-header">
                        <h2 class="section-title" style="margin-bottom:0;">Required Standard Documents</h2>
                        <span class="badge-prep">Embassy Checklist</span>
                    </div>
                    <p style="color: var(--text-gray); font-size: 0.9rem; margin-bottom: 25px;">You must upload scanned copies of these documents during application to start processing:</p>
                    <div class="checklist">
                        <div class="checklist-item checked">
                            <div class="check-box"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
                            <p class="item-text">Valid Passport Photo Page (Minimum 6 months validity)</p>
                        </div>
                        <div class="checklist-item checked">
                            <div class="check-box"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
                            <p class="item-text">Unconditional Offer Letter from a Partner University</p>
                        </div>
                        <div class="checklist-item checked">
                            <div class="check-box"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
                            <p class="item-text">Proof of Funds (Valid bank solvency statement with matching sponsor details)</p>
                        </div>
                        <div class="checklist-item checked">
                            <div class="check-box"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
                            <p class="item-text">English Competency Score Report (IELTS, TOEFL, or GRE scores)</p>
                        </div>
                    </div>
                </section>
            </div>

            <!-- APPLICATION PANEL -->
            <div id="panel-application" class="tab-panel <?= $defaultTab === 'application' ? 'active' : '' ?>">
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <div class="visa-form-card" style="text-align: center; max-width: 600px; margin: 0 auto;">
                        <h3 class="form-title">Start Visa Processing Assistance</h3>
                        <p class="form-desc">Please log in to your Abrovia account to submit your visa files and track progress.</p>
                        <button class="btn-submit" onclick="location.href='login.php?redirect=visa-guide.php'">Log In Now</button>
                    </div>
                <?php elseif ($visaRequest && $visaRequest['status'] !== 'rejected' && !isset($_GET['reapply'])): ?>
                    <div class="visa-form-card" style="text-align: center; max-width: 600px; margin: 0 auto;">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2" style="margin-bottom: 20px;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <h3 class="form-title">Active Request In Progress</h3>
                        <p class="form-desc">You have already submitted a visa processing request. You can check timelines and reviewer updates in the Tracking tab.</p>
                        <button class="btn-submit" onclick="switchTabDirect('tracking')">Go to Tracking</button>
                    </div>
                <?php else: ?>
                    <div class="visa-form-card" style="max-width: 800px; margin: 0 auto;">
                        <h3 class="form-title">Apply for Visa Processing</h3>
                        <p class="form-desc">Fill in your profile details and upload the required embassy documents. Our administrative counselors will review, verify, and dispatch your file to the embassy.</p>
                        
                        <form action="visa-guide.php" method="POST" enctype="multipart/form-data">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="f_name">Full Name (As in Passport)</label>
                                    <input type="text" id="f_name" name="full_name" class="form-control" required placeholder="e.g. John Doe">
                                </div>
                                <div class="form-group">
                                    <label for="f_phone">Phone Number</label>
                                    <input type="text" id="f_phone" name="phone" class="form-control" required placeholder="e.g. +880 1712345678">
                                </div>
                            </div>

                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="f_country">Destination Country</label>
                                    <select id="f_country" name="country" class="form-control" required>
                                        <option value="">Select Country...</option>
                                        <option value="United States">United States</option>
                                        <option value="United Kingdom">United Kingdom</option>
                                        <option value="Canada">Canada</option>
                                        <option value="Australia">Australia</option>
                                        <option value="Germany">Germany</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="f_passport">Passport Number</label>
                                    <input type="text" id="f_passport" name="passport_number" class="form-control" required placeholder="e.g. A01234567">
                                </div>
                            </div>

                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="f_uni">Admitted University</label>
                                    <input type="text" id="f_uni" name="university_name" class="form-control" required placeholder="e.g. Massachusetts Institute of Technology">
                                </div>
                                <div class="form-group">
                                    <label for="f_prog">Program Name</label>
                                    <input type="text" id="f_prog" name="program_name" class="form-control" required placeholder="e.g. MSc in Computer Science">
                                </div>
                            </div>

                            <h4 style="font-size: 0.95rem; color: var(--accent); margin-top: 30px; margin-bottom: 15px; font-weight: 700;">Embassy Documents Upload</h4>
                            
                            <div class="form-grid">
                                <div class="form-group">
                                    <label>Passport Photo Page (PDF/Image)</label>
                                    <input type="file" name="passport_file" required class="form-control file-upload-box">
                                </div>
                                <div class="form-group">
                                    <label>University Offer Letter (PDF/Image)</label>
                                    <input type="file" name="admission_letter_file" required class="form-control file-upload-box">
                                </div>
                            </div>

                            <div class="form-grid">
                                <div class="form-group">
                                    <label>Bank Solvency Statement (PDF/Image)</label>
                                    <input type="file" name="bank_statement_file" required class="form-control file-upload-box">
                                </div>
                                <div class="form-group">
                                    <label>English Competency Report (PDF/Image)</label>
                                    <input type="file" name="language_score_file" required class="form-control file-upload-box">
                                </div>
                            </div>

                            <div style="margin-top: 30px;">
                                <button type="submit" name="submit_visa_request" class="btn-submit">Submit Visa Request</button>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>

            <!-- TRACKING PANEL -->
            <div id="panel-tracking" class="tab-panel <?= $defaultTab === 'tracking' ? 'active' : '' ?>">
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <div class="tracking-card" style="text-align: center; max-width: 600px; margin: 0 auto;">
                        <h3 class="form-title">Track Visa Application</h3>
                        <p class="form-desc">Please log in to track your visa milestones and counselor remarks.</p>
                        <button class="btn-submit" onclick="location.href='login.php?redirect=visa-guide.php'">Log In Now</button>
                    </div>
                <?php elseif (!$visaRequest): ?>
                    <div class="tracking-card" style="text-align: center; max-width: 600px; margin: 0 auto;">
                        <h3 class="form-title">No Application Records</h3>
                        <p class="form-desc">You haven't requested visa processing assistance yet. Go to the Application tab to get started.</p>
                        <button class="btn-submit" onclick="switchTabDirect('application')">Submit Request</button>
                    </div>
                <?php else: 
                    $status = $visaRequest['status'];
                    
                    // Stepper status mapping helper
                    $stepClass = ['s1' => '', 's2' => '', 's3' => '', 's4' => ''];
                    if ($status === 'pending') {
                        $stepClass['s1'] = 'active';
                    } elseif ($status === 'documents_verified') {
                        $stepClass['s1'] = 'done';
                        $stepClass['s2'] = 'active';
                    } elseif ($status === 'submitted_to_embassy') {
                        $stepClass['s1'] = 'done';
                        $stepClass['s2'] = 'done';
                        $stepClass['s3'] = 'active';
                    } elseif ($status === 'approved') {
                        $stepClass['s1'] = 'done';
                        $stepClass['s2'] = 'done';
                        $stepClass['s3'] = 'done';
                        $stepClass['s4'] = 'done';
                    } elseif ($status === 'rejected') {
                        $stepClass['s1'] = 'done';
                        $stepClass['s2'] = 'done';
                        $stepClass['s3'] = 'done';
                        $stepClass['s4'] = 'active'; // Rejected visual
                    }
                ?>
                    <div class="tracking-card" style="max-width: 800px; margin: 0 auto;">
                        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 25px;">
                            <div>
                                <h3 class="form-title" style="margin-bottom: 4px;">Visa Status Tracker</h3>
                                <p style="color: var(--text-gray); font-size: 0.85rem;">Request submitted on <?= date('d M, Y', strtotime($visaRequest['created_at'])) ?></p>
                            </div>
                            <span class="badge-visa <?= $status ?>"><?= str_replace('_', ' ', $status) ?></span>
                        </div>

                        <!-- VISUAL STEPPER -->
                        <div class="stepper">
                            <div class="step <?= $stepClass['s1'] ?>">
                                <div class="step-circle"><?= ($status === 'pending') ? '•' : '✓' ?></div>
                                <span class="step-lbl">Request Submitted</span>
                            </div>
                            <div class="step <?= $stepClass['s2'] ?>">
                                <div class="step-circle"><?= ($status === 'documents_verified' || $status === 'pending') ? '2' : '✓' ?></div>
                                <span class="step-lbl">Papers Verified</span>
                            </div>
                            <div class="step <?= $stepClass['s3'] ?>">
                                <div class="step-circle"><?= ($status === 'submitted_to_embassy' || $status === 'documents_verified' || $status === 'pending') ? '3' : '✓' ?></div>
                                <span class="step-lbl">Sent to Embassy</span>
                            </div>
                            <div class="step <?= $stepClass['s4'] ?>">
                                <div class="step-circle" style="<?= ($status === 'rejected') ? 'background:#ef4444; border-color:#ef4444; color:white;' : '' ?>">
                                    <?php 
                                    if ($status === 'approved') echo '✓';
                                    elseif ($status === 'rejected') echo '✗';
                                    else echo '4';
                                    ?>
                                </div>
                                <span class="step-lbl"><?= ($status === 'rejected') ? 'Visa Rejected' : 'Visa Issued' ?></span>
                            </div>
                        </div>

                        <!-- DECISION PANELS -->
                        <?php if ($status === 'approved'): ?>
                            <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); padding: 25px; border-radius: 12px; text-align: center; margin-bottom: 25px;">
                                <h4 style="color:#4ade80; font-size: 1.25rem; font-weight:700; margin-bottom:8px;">Congratulations! Your Visa Has Been Approved 🎉</h4>
                                <p style="color:var(--text-gray); font-size:0.9rem;">Your study visa application has been approved by the consulate embassy. Please get in touch with our counseling center to plan your pre-departure session.</p>
                            </div>
                        <?php elseif ($status === 'rejected'): ?>
                            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); padding: 25px; border-radius: 12px; text-align: center; margin-bottom: 25px;">
                                <h4 style="color:#f87171; font-size: 1.25rem; font-weight:700; margin-bottom:8px;">Application Rejected by Embassy ✗</h4>
                                <p style="color:var(--text-gray); font-size:0.9rem; margin-bottom: 15px;">We regret to inform you that your application has been rejected. You can review the feedback comments below, update your details, and reapply.</p>
                                <a href="visa-guide.php?reapply=1" class="btn-submit" style="display:inline-block; text-decoration:none; padding:10px 20px; font-size:0.85rem;">Modify & Reapply</a>
                            </div>
                        <?php endif; ?>

                        <!-- USER APPLICATION DETAILS -->
                        <h4 style="font-size: 1rem; font-weight: 700; border-bottom: 1px solid var(--border); padding-bottom: 8px; margin-bottom: 15px;">Application Information</h4>
                        
                        <div class="tracking-grid">
                            <div class="tracking-info-item">
                                <span class="tracking-lbl">Applicant Name</span>
                                <div class="tracking-val"><?= htmlspecialchars($visaRequest['full_name']) ?></div>
                            </div>
                            <div class="tracking-info-item">
                                <span class="tracking-lbl">Passport Number</span>
                                <div class="tracking-val" style="font-family: monospace;"><?= htmlspecialchars($visaRequest['passport_number']) ?></div>
                            </div>
                            <div class="tracking-info-item">
                                <span class="tracking-lbl">Contact Phone</span>
                                <div class="tracking-val"><?= htmlspecialchars($visaRequest['phone']) ?></div>
                            </div>
                            <div class="tracking-info-item">
                                <span class="tracking-lbl">Destination Country</span>
                                <div class="tracking-val"><?= htmlspecialchars($visaRequest['country']) ?></div>
                            </div>
                            <div class="tracking-info-item" style="grid-column: span 2;">
                                <span class="tracking-lbl">Admitted University & Program</span>
                                <div class="tracking-val"><?= htmlspecialchars($visaRequest['university_name']) ?> — <span style="font-weight: normal; color: var(--text-gray);"><?= htmlspecialchars($visaRequest['program_name']) ?></span></div>
                            </div>
                        </div>

                        <!-- CHECKLISTS -->
                        <h4 style="font-size: 1rem; font-weight: 700; border-bottom: 1px solid var(--border); padding-bottom: 8px; margin-top: 30px; margin-bottom: 15px;">Verification Checklist</h4>
                        <div class="checklist">
                            <div class="checklist-item <?= ($visaRequest['info_verified'] == 1) ? 'checked' : 'active' ?>" style="padding:10px 15px; margin-bottom:4px;">
                                <div class="check-box"><?php if ($visaRequest['info_verified'] == 1) echo '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>'; ?></div>
                                <p class="item-text" style="font-size: 0.88rem;">Passport & Information Authenticity Check</p>
                            </div>
                            <div class="checklist-item <?= ($visaRequest['docs_verified'] == 1) ? 'checked' : 'active' ?>" style="padding:10px 15px; margin-bottom:4px;">
                                <div class="check-box"><?php if ($visaRequest['docs_verified'] == 1) echo '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>'; ?></div>
                                <p class="item-text" style="font-size: 0.88rem;">Financial Solvency & Acceptance Documentation Verification</p>
                            </div>
                            <div class="checklist-item <?= ($visaRequest['embassy_submitted'] == 1) ? 'checked' : 'active' ?>" style="padding:10px 15px; margin-bottom:4px;">
                                <div class="check-box"><?php if ($visaRequest['embassy_submitted'] == 1) echo '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>'; ?></div>
                                <p class="item-text" style="font-size: 0.88rem;">Final Dossier Submissions to Target Consulate Embassy</p>
                            </div>
                        </div>

                        <!-- FEEDBACK BUBBLE -->
                        <?php if (!empty($visaRequest['admin_notes'])): ?>
                            <div class="feedback-bubble">
                                <div class="feedback-title">Counselor Review Remark</div>
                                <div class="feedback-text"><?= nl2br(htmlspecialchars($visaRequest['admin_notes'])) ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- INTERVIEW PANEL -->
            <div id="panel-interview" class="tab-panel">
                <section class="documents-section" style="max-width: 800px; margin: 0 auto; background: var(--bg-card);">
                    <h2 class="section-title">Visa Interview Preparation Guide</h2>
                    <p style="color: var(--text-gray); font-size: 0.9rem; margin-bottom: 25px;">Consulate interviews are critical. Focus on these sample questions and structured guidance:</p>
                    
                    <div style="display:flex; flex-direction:column; gap: 20px;">
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); padding: 15px; border-radius: 8px;">
                            <h4 style="color:var(--accent); font-size:0.95rem; font-weight:700; margin-bottom: 8px;">Q1: Why do you want to study in this specific country?</h4>
                            <p style="color:var(--text-gray); font-size:0.85rem; line-height: 1.5;"><strong>Tip:</strong> Don't give generic answers. Explain the high educational standard, global recognition, and specialized research facilities available in the country compared to your home country.</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); padding: 15px; border-radius: 8px;">
                            <h4 style="color:var(--accent); font-size:0.95rem; font-weight:700; margin-bottom: 8px;">Q2: Why did you choose this university and program?</h4>
                            <p style="color:var(--text-gray); font-size:0.85rem; line-height: 1.5;"><strong>Tip:</strong> Focus on core modules, faculty expertise, specific curriculum elements, and how the program aligns directly with your future career plans.</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); padding: 15px; border-radius: 8px;">
                            <h4 style="color:var(--accent); font-size:0.95rem; font-weight:700; margin-bottom: 8px;">Q3: How are you planning to fund your education and living expenses?</h4>
                            <p style="color:var(--text-gray); font-size:0.85rem; line-height: 1.5;"><strong>Tip:</strong> Clearly name your sponsor (e.g. parents/self), explain their business/salary, and refer back to your submitted bank solvency statement. Be confident about your numbers.</p>
                        </div>
                    </div>
                </section>
            </div>
        <!-- FOOTER -->
        <?php require_once 'includes/footer.php'; ?>
        </main>
    </div>

    <script>
    function switchTabDirect(target) {
        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
        
        const panel = document.getElementById('panel-' + target);
        if (panel) panel.classList.add('active');

        const link = document.querySelector(`.sidebar-link[data-target="${target}"]`);
        if (link) link.classList.add('active');
    }

    document.addEventListener('DOMContentLoaded', function() {
        const sidebarLinks = document.querySelectorAll('.sidebar-link');
        sidebarLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const target = this.getAttribute('data-target');
                switchTabDirect(target);
            });
        });
    });
    </script>
</body>
</html>
