<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

// Fetch all active courses
$stmt = $pdo->prepare("SELECT * FROM courses WHERE status = 'active' ORDER BY id ASC");
$stmt->execute();
$courses = $stmt->fetchAll();

// Fetch current user enrollments
$enrollments = [];
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT course_id, status FROM enrollments WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    while ($row = $stmt->fetch()) {
        $enrollments[$row['course_id']] = $row['status'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Prep - Abrovia</title>
    <link rel="stylesheet" href="assets/css/test-prep.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <!-- NAVBAR -->
    <?php require_once 'includes/header.php'; ?>

    <!-- HERO -->
    <header class="hero" style="background-image: linear-gradient(180deg, rgba(10, 14, 28, 0.4) 0%, rgba(10, 14, 28, 0.9) 100%), url('assets/images/test_prep.png'); background-size: cover; background-position: center; padding: 180px 0 80px;">
        <div class="hero-content">
            <h1 class="hero-title">Master Your Tests</h1>
            <p class="hero-subtitle">
                Achieve your dream score with our comprehensive preparation courses for IELTS, GRE, and TOEFL. Expert guidance, realistic mock exams, and personalized study plans tailored for global scholars.
            </p>
        </div>
    </header>

    <!-- TEST CARDS -->
    <section class="test-cards-section">
        <div class="container">
            <?php if (isset($_GET['error']) && $_GET['error'] === 'not_enrolled'): ?>
                <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); color: #f87171; padding: 15px; border-radius: 8px; text-align: center; margin-bottom: 30px;">
                    You must enroll in this course to access the Prep Center. Please complete the purchase below.
                </div>
            <?php endif; ?>

            <div class="test-grid">
                <?php foreach ($courses as $course): 
                    $slug = $course['slug'];
                    $courseId = $course['id'];
                    $price = number_format($course['price']);
                    $features = json_decode($course['features'], true) ?: [];
                    $enrollStatus = $enrollments[$courseId] ?? null;
                    
                    // Determine SVG icon based on slug
                    $svgIcon = '';
                    if ($slug === 'ielts') {
                        $svgIcon = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>';
                    } else if ($slug === 'gre') {
                        $svgIcon = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>';
                    } else if ($slug === 'toefl') {
                        $svgIcon = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3z"/><path d="M3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>';
                    } else {
                        $svgIcon = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 20V4H20v16H6.5z"/></svg>';
                    }
                ?>
                    <div class="test-card" style="position: relative;">
                        <!-- Badges -->
                        <?php if ($enrollStatus === 'active'): ?>
                            <div class="enrolled-badge">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                Enrolled
                            </div>
                        <?php else: ?>
                            <div class="price-badge">৳<?= $price ?></div>
                        <?php endif; ?>

                        <div class="test-header">
                            <div class="test-icon purple-bg">
                                <?= $svgIcon ?>
                            </div>
                            <h2 class="test-name"><?= htmlspecialchars($course['name']) ?></h2>
                        </div>
                        <p class="test-desc"><?= htmlspecialchars($course['description']) ?></p>
                        
                        <ul class="test-features">
                            <?php foreach ($features as $feature): ?>
                                <li>
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;color:#6c3fff;">
                                        <polyline points="20 6 9 17 4 12"></polyline>
                                    </svg> 
                                    <?= htmlspecialchars($feature) ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>

                        <?php if (!isset($_SESSION['user_id'])): ?>
                            <button class="btn-start" onclick="location.href='login.php?redirect=test-prep.php'">Start Preparation</button>
                        <?php elseif ($enrollStatus === 'active'): ?>
                            <button class="btn-continue" onclick="location.href='prep-center.php?course=<?= urlencode($slug) ?>'">Continue Learning</button>
                        <?php elseif ($enrollStatus === 'suspended'): ?>
                            <button class="btn-start" style="opacity: 0.6; cursor: not-allowed;" disabled>Access Suspended</button>
                        <?php else: ?>
                            <button class="btn-start" onclick="openPurchaseModal(<?= $courseId ?>, '<?= htmlspecialchars($course['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($course['description'], ENT_QUOTES) ?>', <?= htmlspecialchars(json_encode($features), ENT_QUOTES) ?>, <?= $course['price'] ?>)">Start Preparation</button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- WHY PREPARE -->
    <section class="why-prepare-section">
        <div class="container glass-card">
            <h2 class="section-title">Why Prepare With Us?</h2>
            <p class="section-subtitle">Our structured approach ensures you reach your target score efficiently.</p>
            
            <div class="features-grid">
                <div class="feature-item">
                    <div class="feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </div>
                    <h3 class="feature-title">Flexible Scheduling</h3>
                    <p class="feature-desc">Access recorded lectures and practice materials 24/7. Study at your own pace from anywhere in the world.</p>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
                    </div>
                    <h3 class="feature-title">Certified Instructors</h3>
                    <p class="feature-desc">Learn from top-percentile scorers and certified examiners who know the tests inside and out.</p>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                    </div>
                    <h3 class="feature-title">Score Improvement Guarantee</h3>
                    <p class="feature-desc">We are confident in our methods. If your score doesn't improve, get access to additional coaching for free.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- PURCHASE MODAL -->
    <div class="purchase-overlay" id="purchaseOverlay">
        <div class="purchase-modal">
            <button class="modal-close" id="modalClose">&times;</button>
            <div class="modal-header">
                <div class="modal-icon" id="modalIcon"></div>
                <h2 class="modal-title" id="modalTitle"></h2>
            </div>
            <p class="modal-desc" id="modalDesc"></p>
            <div class="modal-features" id="modalFeatures"></div>
            <div class="fee-summary">
                <div class="fee-row">
                    <span>Course Fee</span>
                    <span id="feeAmount"></span>
                </div>
                <div class="fee-row">
                    <span>Platform Service Charge</span>
                    <span>৳0.00</span>
                </div>
                <div class="fee-divider"></div>
                <div class="fee-row fee-total">
                    <span>Total Amount</span>
                    <span id="feeTotal"></span>
                </div>
            </div>
            <button class="btn-purchase" id="btnPurchase">
                <span id="btnPurchaseText">Complete Payment</span>
            </button>
            <p class="modal-note">Demo mode &mdash; no real money will be charged.</p>
        </div>
    </div>

    <!-- FOOTER -->
    <?php require_once 'includes/footer.php'; ?>

    <script>
    let activeCourseId = null;

    function openPurchaseModal(courseId, name, desc, features, price) {
        activeCourseId = courseId;
        
        document.getElementById('modalTitle').innerText = name;
        document.getElementById('modalDesc').innerText = desc;
        
        // Render icon inside modal based on name
        let iconHtml = '';
        if (name.toLowerCase().includes('ielts')) {
            iconHtml = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:#6c3fff;"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>';
        } else if (name.toLowerCase().includes('gre')) {
            iconHtml = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:#6c3fff;"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>';
        } else {
            iconHtml = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:#6c3fff;"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3z"/><path d="M3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>';
        }
        document.getElementById('modalIcon').innerHTML = iconHtml;

        // Render features tags
        let featuresHtml = '';
        features.forEach(f => {
            featuresHtml += `<span class="modal-feature-tag">${f}</span>`;
        });
        document.getElementById('modalFeatures').innerHTML = featuresHtml;

        // Format price
        const formattedPrice = '৳' + Number(price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        document.getElementById('feeAmount').innerText = formattedPrice;
        document.getElementById('feeTotal').innerText = formattedPrice;

        // Show overlay
        const overlay = document.getElementById('purchaseOverlay');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closePurchaseModal() {
        const overlay = document.getElementById('purchaseOverlay');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
        activeCourseId = null;
        
        // Reset purchase button
        const btn = document.getElementById('btnPurchase');
        btn.disabled = false;
        btn.classList.remove('success');
        document.getElementById('btnPurchaseText').innerText = 'Complete Payment';
    }

    document.addEventListener('DOMContentLoaded', function() {
        const overlay = document.getElementById('purchaseOverlay');
        const closeBtn = document.getElementById('modalClose');
        const purchaseBtn = document.getElementById('btnPurchase');

        closeBtn.addEventListener('click', closePurchaseModal);
        
        overlay.addEventListener('click', function(e) {
            if (e.target === overlay) {
                closePurchaseModal();
            }
        });

        purchaseBtn.addEventListener('click', function() {
            if (!activeCourseId) return;

            purchaseBtn.disabled = true;
            document.getElementById('btnPurchaseText').innerText = 'Processing Payment...';

            const formData = new FormData();
            formData.append('course_id', activeCourseId);

            fetch('api/purchase.php?action=purchase', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    purchaseBtn.classList.add('success');
                    document.getElementById('btnPurchaseText').innerText = 'Payment Complete ✓';
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 1200);
                } else {
                    alert(data.message);
                    purchaseBtn.disabled = false;
                    document.getElementById('btnPurchaseText').innerText = 'Complete Payment';
                }
            })
            .catch(err => {
                console.error(err);
                alert('Payment verification failed. Please try again.');
                purchaseBtn.disabled = false;
                document.getElementById('btnPurchaseText').innerText = 'Complete Payment';
            });
        });
    });
    </script>
</body>
</html>
